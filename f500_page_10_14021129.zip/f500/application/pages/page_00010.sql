prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1379074910136873
,p_default_application_id=>500
,p_default_id_offset=>0
,p_default_owner=>'FARA'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>'copy_500_278_ebrahimi_orginal_richtext'
,p_alias=>'COPY-500-278-EBRAHIMI-ORGINAL-RICHTEXT'
,p_step_title=>'&P0_B5FORMREF_TITLE.'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#WORKSPACE_IMAGES#ckeditor5Config.js'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_upd_yyyymmddhh24miss=>'20231118200829'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36604542982581270)
,p_plug_name=>'G5SITECONTENT_FORM'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(32273317843728805)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'TABLE'
,p_query_table=>'G5SITECONTENT'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36610518201581274)
,p_plug_name=>'Buttons'
,p_parent_plug_id=>wwv_flow_imp.id(36604542982581270)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(32273729395728805)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(31858537885745760)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(36610518201581274)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(32322885630728823)
,p_button_image_alt=>'Cancel'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(31858981396745762)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(36610518201581274)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(32322885630728823)
,p_button_image_alt=>'Delete'
,p_button_position=>'BELOW_BOX'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_button_condition=>'P10_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(31859393350745762)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(36610518201581274)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(32322885630728823)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'BELOW_BOX'
,p_button_condition=>'P10_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(31859709521745763)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(36610518201581274)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(32322885630728823)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_condition=>'P10_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(36605541904581301)
,p_name=>'P10_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(36604542982581270)
,p_item_source_plug_id=>wwv_flow_imp.id(36604542982581270)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(36605964753581301)
,p_name=>'P10_B5IDREF_ID_ORG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(36604542982581270)
,p_item_source_plug_id=>wwv_flow_imp.id(36604542982581270)
,p_item_default=>'APP_C5COMPANY_ID'
,p_item_default_type=>'ITEM'
,p_source=>'B5IDREF_ID_ORG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(36606346871581302)
,p_name=>'P10_SEQUENCE'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(36604542982581270)
,p_item_source_plug_id=>wwv_flow_imp.id(36604542982581270)
,p_prompt=>'Sequence'
,p_source=>'SEQUENCE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(36607146645581302)
,p_name=>'P10_TOPIC'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(36604542982581270)
,p_item_source_plug_id=>wwv_flow_imp.id(36604542982581270)
,p_prompt=>'Topic'
,p_source=>'TOPIC'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>500
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(36607520772581303)
,p_name=>'P10_CONTENT'
,p_source_data_type=>'CLOB'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(36604542982581270)
,p_item_source_plug_id=>wwv_flow_imp.id(36604542982581270)
,p_prompt=>'Content'
,p_source=>'CONTENT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_encrypt_session_state_yn=>'N'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options){',
'',
'    function findViewChild( viewElement, viewElementName, conversionApi ) {',
'        const viewChildren = Array.from( conversionApi.writer.createRangeIn( viewElement ).getItems() );',
'        return viewChildren.find( item => item.is( ''element'', viewElementName ) );',
'    } ',
'  ',
'    function AddClassToAllTable( editor ) {',
'        editor.conversion.for( ''downcast'' ).add( dispatcher => {',
'        dispatcher.on( ''insert:table'', ( evt, data, conversionApi ) => {',
'        const viewWriter = conversionApi.writer;',
'        const viewFigure = conversionApi.mapper.toViewElement( data.item );',
'        viewWriter.setAttribute( ''style'', ''margin:1em auto;'', viewFigure ); //***********test',
'        const viewElementtable = findViewChild( viewFigure, ''table'', conversionApi );',
'        viewWriter.setAttribute( ''style'', ''border-collapse:collapse;width:100%;'', viewElementtable );',
'        /*',
'          Array.from( conversionApi.writer.createRangeIn( viewFigure ).getItems(),item=> {',
'               if(item.name=="td"){',
'                    viewWriter.setAttribute( ''style'', ''border:1px solid gray;'', item ) ;',
'               }',
'                ',
'          });',
'          */',
'        }, { priority: ''low'' } );',
'    } );',
'    ',
'}',
'',
'',
'    class InsertImageByURLButton extends ClassicEditor.libraryClasses.Plugin {',
'        init(){',
'            const editor = this.editor;',
'            editor.ui.componentFactory.add(''insertImageByUrl'', locale => {',
'                const view = new ClassicEditor.libraryClasses.ButtonView(locale);',
'                view.set({',
'                    icon: ''<svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M6.91 10.54c.26-.23.64-.21.88.03l3.36 3.14 2.23-2.06a.64.64 0 0 1 .87 0l2.52 2.97V4.5H3.2v10.12l3.71-4.08zm10.27-7.51c.6 0 1.09.47 1.09 1.05v11.84c0 .59-.'
||'49 1.06-1.09 1.06H2.79c-.6 0-1.09-.47-1.09-1.06V4.08c0-.58.49-1.05 1.1-1.05h14.38zm-5.22 5.56a1.96 1.96 0 1 1 3.4-1.96 1.96 1.96 0 0 1-3.4 1.96z"/></svg>'',',
'                    label: ''Custom Button'',',
'                    withText: false,',
'                    tooltip: true',
'                });',
'                view.on(''execute'', () => {',
'                    const imageUrl = prompt( ''Image URL'' );',
'',
'                    if(imageUrl){',
'                        editor.model.change( writer => {',
'                            const imageElement = writer.createElement(''image'', {',
'                                src: imageUrl',
'                            });',
'                            editor.model.insertContent( imageElement, editor.model.document.selection );',
'                        });',
'                    }',
'                });',
'                return view;',
'            });',
'        }',
'    }',
'',
'    options.editorOptions.extraPlugins.push(InsertImageByURLButton);',
'    options.editorOptions.extraPlugins.push(AddClassToAllTable);',
'    options.editorOptions.toolbar.push(''insertImageByUrl'');',
'options.editorOptions.table = {',
'        contentToolbar: [',
'            ''tableColumn'', ''tableRow'', ''mergeTableCells'',',
'            ''tableProperties'', ''tableCellProperties''',
'        ]',
'}',
'',
'options.editorOptions.fontSize = {',
'	options: [',
'		{',
'		 	title: ''9'',',
'		 	model: ''12px''',
'		},',
'        {',
'		 	title: ''11'',',
'		 	model: ''14.5px''',
'		},{',
'            title: ''12'',',
'            model: ''16px''',
'        },',
'        {',
'		 	title: ''13'',',
'		 	model: ''17px''',
'		},',
'        {',
'		 	title: ''14'',',
'		 	model: ''18.5px''',
'		},',
'		{',
'		 	title: ''17'',',
'		 	model: ''22.5px''',
'		},',
'        {',
'		 	title: ''19'',',
'		 	model: ''25px''',
'		},',
'        {',
'		 	title: ''21'',',
'		 	model: ''28px''',
'		}',
'	]',
'}',
'    return options;',
'}'))
,p_attribute_01=>'HTML'
,p_attribute_02=>'FULL'
,p_attribute_03=>'OVERFLOW'
,p_attribute_04=>'180'
,p_attribute_07=>'N'
,p_attribute_25=>'CKEDITOR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(36607925397581303)
,p_name=>'P10_LANGUAGE'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(36604542982581270)
,p_item_source_plug_id=>wwv_flow_imp.id(36604542982581270)
,p_prompt=>'Language'
,p_source=>'LANGUAGE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'B5_LANG_LOV'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(36608294644581303)
,p_name=>'P10_B5HCSTATUS_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(36604542982581270)
,p_item_source_plug_id=>wwv_flow_imp.id(36604542982581270)
,p_source=>'B5HCSTATUS_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46191799727857364)
,p_name=>'P10_B5FORMREF_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(36604542982581270)
,p_item_source_plug_id=>wwv_flow_imp.id(36604542982581270)
,p_prompt=>'form'
,p_source=>'B5FORMREF_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'B5FORMREF_TITLE_CODE_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'   code ||'' - '' || Title as d,id as r',
'from',
'    b5formref_v',
'order by code'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(207252727667379637)
,p_name=>'P10_B5HC_CONTENT_TYPE_ID'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(36604542982581270)
,p_item_source_plug_id=>wwv_flow_imp.id(36604542982581270)
,p_prompt=>'position'
,p_source=>'B5HC_CONTENT_TYPE_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select hc.name , hc.id from b5hc_v hc join hcbase hcb on hcb.id=hc.hcbase_id where hcb.code=''SCP'''
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(207252820175379638)
,p_name=>'P10_URL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(36604542982581270)
,p_item_source_plug_id=>wwv_flow_imp.id(36604542982581270)
,p_prompt=>'Url'
,p_source=>'URL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>800
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(31860732399745771)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(31858537885745760)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31861250753745774)
,p_event_id=>wwv_flow_imp.id(31860732399745771)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(31857892744745758)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(36604542982581270)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form G5SITECONTENT_FORM'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>31857892744745758
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(31860311792745769)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>31860311792745769
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(31857443483745756)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(36604542982581270)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form G5SITECONTENT_FORM'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>31857443483745756
);
wwv_flow_imp.component_end;
end;
/
