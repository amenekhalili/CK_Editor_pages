prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1379074910136873
,p_default_application_id=>500
,p_default_id_offset=>0
,p_default_owner=>'FARA'
);
wwv_flow_imp_page.create_page(
 p_id=>11
,p_name=>'copy_500_680_ebrahimi_richtext'
,p_alias=>'COPY-500-680-EBRAHIMI-RICHTEXT'
,p_step_title=>'&P0_B5FORMREF_TITLE.'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(68234327446132701)
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_upd_yyyymmddhh24miss=>'20231118200829'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(347914374977776453)
,p_plug_name=>'Event&News Form'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--noUI:t-Region--scrollBody:t-Form--noPadding'
,p_plug_template=>wwv_flow_imp.id(32284354317728808)
,p_plug_display_sequence=>10
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(70160494359665515)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_imp.id(347914374977776453)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--noBorder:t-Region--scrollBody:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(32284354317728808)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(341677082342246453)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_imp.id(347914374977776453)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(32284354317728808)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'TABLE'
,p_query_table=>'G5EVENTNEWS'
,p_include_rowid_column=>true
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(341677118182246454)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_imp.id(347914374977776453)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--scrollBody:margin-top-none:margin-bottom-none'
,p_plug_template=>wwv_flow_imp.id(32284354317728808)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(32346810528426122)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(347914374977776453)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(32322885630728823)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'CHANGE'
,p_button_condition=>'P11_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(32347230755426122)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(347914374977776453)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(32322885630728823)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:681:&SESSION.::&DEBUG.::P0_B5FORMREF_CODE:681'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(32347667454426123)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(347914374977776453)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(32322885630728823)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_button_condition=>'P11_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(32348075652426123)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(347914374977776453)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(32322885630728823)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'TOP'
,p_button_condition=>'P11_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(32362234666426152)
,p_branch_name=>'Go To Page 681'
,p_branch_action=>'f?p=&APP_ID.:681:&SESSION.::&DEBUG.::P0_B5FORMREF_CODE:681&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(32347667454426123)
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(347919285771776494)
,p_name=>'P11_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(347914374977776453)
,p_item_source_plug_id=>wwv_flow_imp.id(341677082342246453)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(347922446741776505)
,p_name=>'P11_INSERTDATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(347914374977776453)
,p_item_source_plug_id=>wwv_flow_imp.id(341677082342246453)
,p_use_cache_before_default=>'NO'
,p_source=>'INSERTDATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(347923306892776506)
,p_name=>'P11_COUNTSEEN'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(347914374977776453)
,p_item_source_plug_id=>wwv_flow_imp.id(341677082342246453)
,p_use_cache_before_default=>'NO'
,p_source=>'COUNTSEEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(347924068779776506)
,p_name=>'P11_U5USER_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(347914374977776453)
,p_item_source_plug_id=>wwv_flow_imp.id(341677082342246453)
,p_use_cache_before_default=>'NO'
,p_source=>'U5USER_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(347924414906776506)
,p_name=>'P11_B5HCSTATUS_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(347914374977776453)
,p_item_source_plug_id=>wwv_flow_imp.id(341677082342246453)
,p_use_cache_before_default=>'NO'
,p_source=>'B5HCSTATUS_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(347925106692776517)
,p_name=>'P11_SUMMERYCONTENT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(70160494359665515)
,p_item_source_plug_id=>wwv_flow_imp.id(341677082342246453)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Summery Content'
,p_source=>'SUMMERYCONTENT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_field_template=>wwv_flow_imp.id(32322374895728822)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:margin-bottom-md:margin-left-sm'
,p_is_persistent=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options){',
'',
'    function findViewChild( viewElement, viewElementName, conversionApi ) {',
'        const viewChildren = Array.from( conversionApi.writer.createRangeIn( viewElement ).getItems() );',
'        return viewChildren.find( item => item.is( ''element'', viewElementName ) );',
'    } ',
'  ',
'    function AddClassToAllTable( editor ) {',
'        editor.conversion.for( ''downcast'' ).add( dispatcher => {',
'        dispatcher.on( ''insert:table'', ( evt, data, conversionApi ) => {',
'        const viewWriter = conversionApi.writer;',
'        const viewFigure = conversionApi.mapper.toViewElement( data.item );',
'        viewWriter.setAttribute( ''style'', ''margin:1em auto;'', viewFigure ); //***********test',
'        const viewElementtable = findViewChild( viewFigure, ''table'', conversionApi );',
'        viewWriter.setAttribute( ''style'', ''border-collapse:collapse;width:100%;'', viewElementtable );',
'        /*',
'          Array.from( conversionApi.writer.createRangeIn( viewFigure ).getItems(),item=> {',
'               if(item.name=="td"){',
'                    viewWriter.setAttribute( ''style'', ''border:1px solid gray;'', item ) ;',
'               }',
'                ',
'          });',
'          */',
'        }, { priority: ''low'' } );',
'    } );',
'    ',
'}',
'',
'',
'    class InsertImageByURLButton extends ClassicEditor.libraryClasses.Plugin {',
'        init(){',
'            const editor = this.editor;',
'            editor.ui.componentFactory.add(''insertImageByUrl'', locale => {',
'                const view = new ClassicEditor.libraryClasses.ButtonView(locale);',
'                view.set({',
'                    icon: ''<svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M6.91 10.54c.26-.23.64-.21.88.03l3.36 3.14 2.23-2.06a.64.64 0 0 1 .87 0l2.52 2.97V4.5H3.2v10.12l3.71-4.08zm10.27-7.51c.6 0 1.09.47 1.09 1.05v11.84c0 .59-.'
||'49 1.06-1.09 1.06H2.79c-.6 0-1.09-.47-1.09-1.06V4.08c0-.58.49-1.05 1.1-1.05h14.38zm-5.22 5.56a1.96 1.96 0 1 1 3.4-1.96 1.96 1.96 0 0 1-3.4 1.96z"/></svg>'',',
'                    label: ''Custom Button'',',
'                    withText: false,',
'                    tooltip: true',
'                });',
'                view.on(''execute'', () => {',
'                    const imageUrl = prompt( ''Image URL'' );',
'',
'                    if(imageUrl){',
'                        editor.model.change( writer => {',
'                            const imageElement = writer.createElement(''image'', {',
'                                src: imageUrl',
'                            });',
'                            editor.model.insertContent( imageElement, editor.model.document.selection );',
'                        });',
'                    }',
'                });',
'                return view;',
'            });',
'        }',
'    }',
'',
'    options.editorOptions.extraPlugins.push(InsertImageByURLButton);',
'    options.editorOptions.extraPlugins.push(AddClassToAllTable);',
'    options.editorOptions.toolbar.push(''insertImageByUrl'');',
'options.editorOptions.table = {',
'        contentToolbar: [',
'            ''tableColumn'', ''tableRow'', ''mergeTableCells'',',
'            ''tableProperties'', ''tableCellProperties''',
'        ]',
'}',
'',
'options.editorOptions.fontSize = {',
'	options: [',
'		{',
'		 	title: ''9'',',
'		 	model: ''12px''',
'		},',
'        {',
'		 	title: ''11'',',
'		 	model: ''14.5px''',
'		},{',
'            title: ''12'',',
'            model: ''16px''',
'        },',
'        {',
'		 	title: ''13'',',
'		 	model: ''17px''',
'		},',
'        {',
'		 	title: ''14'',',
'		 	model: ''18.5px''',
'		},',
'		{',
'		 	title: ''17'',',
'		 	model: ''22.5px''',
'		},',
'        {',
'		 	title: ''19'',',
'		 	model: ''25px''',
'		},',
'        {',
'		 	title: ''21'',',
'		 	model: ''28px''',
'		}',
'	]',
'}',
'    return options;',
'}'))
,p_attribute_01=>'HTML'
,p_attribute_02=>'FULL'
,p_attribute_03=>'OVERFLOW'
,p_attribute_04=>'180'
,p_attribute_07=>'N'
,p_attribute_25=>'CKEDITOR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(347925587751776520)
,p_name=>'P11_REFERENCE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(341677082342246453)
,p_item_source_plug_id=>wwv_flow_imp.id(341677082342246453)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Reference'
,p_source=>'REFERENCE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:margin-bottom-md'
,p_is_persistent=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(347925950357776522)
,p_name=>'P11_GOOGLEKEYWORD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(341677082342246453)
,p_item_source_plug_id=>wwv_flow_imp.id(341677082342246453)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Google Keyword'
,p_source=>'GOOGLEKEYWORD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>82
,p_cMaxlength=>500
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(347926398514776522)
,p_name=>'P11_G5EVENTNEWSGROUP_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(341677082342246453)
,p_item_source_plug_id=>wwv_flow_imp.id(341677082342246453)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Event&News Group'
,p_source=>'G5EVENTNEWSGROUP_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select name , id from G5EVENTNEWSGROUP',
'where B5IDREF_ID_ORG = :APP_C5COMPANY_ID ;'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:margin-bottom-md'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(347926781686776522)
,p_name=>'P11_TOPIC'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(341677082342246453)
,p_item_source_plug_id=>wwv_flow_imp.id(341677082342246453)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Topic'
,p_source=>'TOPIC'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:margin-bottom-md'
,p_is_persistent=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(347927941423776522)
,p_name=>'P11_FORMDATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(341677082342246453)
,p_item_source_plug_id=>wwv_flow_imp.id(341677082342246453)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Date'
,p_source=>'FORMDATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_tag_css_classes=>'date-picker'
,p_colspan=>6
,p_grid_column=>1
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:margin-bottom-md'
,p_is_persistent=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(347928812125776523)
,p_name=>'P11_B5HCPERIORITY_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(341677082342246453)
,p_item_source_plug_id=>wwv_flow_imp.id(341677082342246453)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Priority'
,p_source=>'B5HCPERIORITY_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov_language=>'PLSQL'
,p_lov=>'RETURN B5UTIL.hardcode_lov(''B'',1,''NEL'');'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:margin-bottom-md'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(347933808223776532)
,p_name=>'P11_CONTENT'
,p_source_data_type=>'CLOB'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(341677118182246454)
,p_item_source_plug_id=>wwv_flow_imp.id(341677082342246453)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Content'
,p_source=>'CONTENT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_field_template=>wwv_flow_imp.id(32322374895728822)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:margin-bottom-md:margin-right-sm'
,p_is_persistent=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options){',
'',
'    function findViewChild( viewElement, viewElementName, conversionApi ) {',
'        const viewChildren = Array.from( conversionApi.writer.createRangeIn( viewElement ).getItems() );',
'        return viewChildren.find( item => item.is( ''element'', viewElementName ) );',
'    } ',
'  ',
'    function AddClassToAllTable( editor ) {',
'        editor.conversion.for( ''downcast'' ).add( dispatcher => {',
'        dispatcher.on( ''insert:table'', ( evt, data, conversionApi ) => {',
'        const viewWriter = conversionApi.writer;',
'        const viewFigure = conversionApi.mapper.toViewElement( data.item );',
'        viewWriter.setAttribute( ''style'', ''margin:1em auto;'', viewFigure ); //***********test',
'        const viewElementtable = findViewChild( viewFigure, ''table'', conversionApi );',
'        viewWriter.setAttribute( ''style'', ''border-collapse:collapse;width:100%;'', viewElementtable );',
'        /*',
'          Array.from( conversionApi.writer.createRangeIn( viewFigure ).getItems(),item=> {',
'               if(item.name=="td"){',
'                    viewWriter.setAttribute( ''style'', ''border:1px solid gray;'', item ) ;',
'               }',
'                ',
'          });',
'          */',
'        }, { priority: ''low'' } );',
'    } );',
'    ',
'}',
'',
'',
'    class InsertImageByURLButton extends ClassicEditor.libraryClasses.Plugin {',
'        init(){',
'            const editor = this.editor;',
'            editor.ui.componentFactory.add(''insertImageByUrl'', locale => {',
'                const view = new ClassicEditor.libraryClasses.ButtonView(locale);',
'                view.set({',
'                    icon: ''<svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M6.91 10.54c.26-.23.64-.21.88.03l3.36 3.14 2.23-2.06a.64.64 0 0 1 .87 0l2.52 2.97V4.5H3.2v10.12l3.71-4.08zm10.27-7.51c.6 0 1.09.47 1.09 1.05v11.84c0 .59-.'
||'49 1.06-1.09 1.06H2.79c-.6 0-1.09-.47-1.09-1.06V4.08c0-.58.49-1.05 1.1-1.05h14.38zm-5.22 5.56a1.96 1.96 0 1 1 3.4-1.96 1.96 1.96 0 0 1-3.4 1.96z"/></svg>'',',
'                    label: ''Custom Button'',',
'                    withText: false,',
'                    tooltip: true',
'                });',
'                view.on(''execute'', () => {',
'                    const imageUrl = prompt( ''Image URL'' );',
'',
'                    if(imageUrl){',
'                        editor.model.change( writer => {',
'                            const imageElement = writer.createElement(''image'', {',
'                                src: imageUrl',
'                            });',
'                            editor.model.insertContent( imageElement, editor.model.document.selection );',
'                        });',
'                    }',
'                });',
'                return view;',
'            });',
'        }',
'    }',
'',
'    options.editorOptions.extraPlugins.push(InsertImageByURLButton);',
'    options.editorOptions.extraPlugins.push(AddClassToAllTable);',
'    options.editorOptions.toolbar.push(''insertImageByUrl'');',
'options.editorOptions.table = {',
'        contentToolbar: [',
'            ''tableColumn'', ''tableRow'', ''mergeTableCells'',',
'            ''tableProperties'', ''tableCellProperties''',
'        ]',
'}',
'',
'options.editorOptions.fontSize = {',
'	options: [',
'		{',
'		 	title: ''9'',',
'		 	model: ''12px''',
'		},',
'        {',
'		 	title: ''11'',',
'		 	model: ''14.5px''',
'		},{',
'            title: ''12'',',
'            model: ''16px''',
'        },',
'        {',
'		 	title: ''13'',',
'		 	model: ''17px''',
'		},',
'        {',
'		 	title: ''14'',',
'		 	model: ''18.5px''',
'		},',
'		{',
'		 	title: ''17'',',
'		 	model: ''22.5px''',
'		},',
'        {',
'		 	title: ''19'',',
'		 	model: ''25px''',
'		},',
'        {',
'		 	title: ''21'',',
'		 	model: ''28px''',
'		}',
'	]',
'}',
'    return options;',
'}'))
,p_attribute_01=>'HTML'
,p_attribute_02=>'FULL'
,p_attribute_03=>'OVERFLOW'
,p_attribute_04=>'180'
,p_attribute_07=>'N'
,p_attribute_25=>'CKEDITOR'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(32359869050426149)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_region_id=>wwv_flow_imp.id(341677082342246453)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Fetch Row from G5EVENTNEWS'
,p_internal_uid=>32359869050426149
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(32360226499426149)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(341677082342246453)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process Row of G5EVENTNEWS'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>32360226499426149
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(32361776235426152)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(32347667454426123)
,p_internal_uid=>32361776235426152
);
wwv_flow_imp.component_end;
end;
/
