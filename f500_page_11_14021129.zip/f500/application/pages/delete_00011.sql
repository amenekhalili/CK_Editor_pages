prompt --application/pages/delete_00011
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1379074910136873
,p_default_application_id=>500
,p_default_id_offset=>0
,p_default_owner=>'FARA'
);
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>11);
wwv_flow_imp.component_end;
end;
/
