prompt --install_page
@@application/set_environment.sql
@@application/pages/delete_00011.sql
@@application/pages/page_00011.sql
@@application/end_environment.sql
