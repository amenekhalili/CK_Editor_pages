prompt --install_page
@@application/set_environment.sql
@@application/pages/delete_00212.sql
@@application/pages/page_00212.sql
@@application/end_environment.sql
