prompt --application/pages/page_00212
begin
--   Manifest
--     PAGE: 00212
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1379074910136873
,p_default_application_id=>500
,p_default_id_offset=>0
,p_default_owner=>'FARA'
);
wwv_flow_imp_page.create_page(
 p_id=>212
,p_name=>'D5DIRECTIVEDETAIL_FORM'
,p_page_mode=>'MODAL'
,p_step_title=>'&P0_B5FORMREF_TITLE.'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(68234327446132701)
,p_dialog_height=>'700'
,p_dialog_width=>'90%'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_upd_yyyymmddhh24miss=>'20231015145816'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(520485515455502484)
,p_plug_name=>'Directive Detail'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(32284354317728808)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'D5DIRECTIVEDETAIL'
,p_include_rowid_column=>true
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(520486187418502485)
,p_plug_name=>'bc'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(32273729395728805)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(305937256855299048)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(520486187418502485)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(32322885630728823)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_button_condition=>'P212_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(305937603523299050)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(520486187418502485)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(32322885630728823)
,p_button_image_alt=>'Cancel'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(305938047095299050)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(520486187418502485)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(32322885630728823)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P212_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(305938468502299050)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(520486187418502485)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(32322885630728823)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_condition=>'P212_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(305934525407299046)
,p_name=>'P212_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(520485515455502484)
,p_item_source_plug_id=>wwv_flow_imp.id(520485515455502484)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(305934923129299046)
,p_name=>'P212_D5DIRECTIVE_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(520485515455502484)
,p_item_source_plug_id=>wwv_flow_imp.id(520485515455502484)
,p_use_cache_before_default=>'NO'
,p_source=>'D5DIRECTIVE_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(305935365748299046)
,p_name=>'P212_DETAILTOPIC'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(520485515455502484)
,p_item_source_plug_id=>wwv_flow_imp.id(520485515455502484)
,p_use_cache_before_default=>'NO'
,p_prompt=>'topic'
,p_source=>'DETAILTOPIC'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_colspan=>11
,p_field_template=>wwv_flow_imp.id(32322374895728822)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(305935770681299046)
,p_name=>'P212_COMMENTDETAIL'
,p_source_data_type=>'CLOB'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(520485515455502484)
,p_item_source_plug_id=>wwv_flow_imp.id(520485515455502484)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Comment Detail'
,p_source=>'COMMENTDETAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(32322374895728822)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options){',
'',
'    function findViewChild( viewElement, viewElementName, conversionApi ) {',
'        const viewChildren = Array.from( conversionApi.writer.createRangeIn( viewElement ).getItems() );',
'        return viewChildren.find( item => item.is( ''element'', viewElementName ) );',
'    } ',
'  ',
'    function AddClassToAllTable( editor ) {',
'        editor.conversion.for( ''downcast'' ).add( dispatcher => {',
'        dispatcher.on( ''insert:table'', ( evt, data, conversionApi ) => {',
'        const viewWriter = conversionApi.writer;',
'        const viewFigure = conversionApi.mapper.toViewElement( data.item );',
'        viewWriter.setAttribute( ''style'', ''margin:1em auto;'', viewFigure ); //***********test',
'        const viewElementtable = findViewChild( viewFigure, ''table'', conversionApi );',
'        viewWriter.setAttribute( ''style'', ''border-collapse:collapse;width:100%;'', viewElementtable );',
'        /*',
'          Array.from( conversionApi.writer.createRangeIn( viewFigure ).getItems(),item=> {',
'               if(item.name=="td"){',
'                    viewWriter.setAttribute( ''style'', ''border:1px solid gray;'', item ) ;',
'               }',
'                ',
'          });',
'          */',
'        }, { priority: ''low'' } );',
'    } );',
'    ',
'}',
'',
'',
'    class InsertImageByURLButton extends ClassicEditor.libraryClasses.Plugin {',
'        init(){',
'            const editor = this.editor;',
'            editor.ui.componentFactory.add(''insertImageByUrl'', locale => {',
'                const view = new ClassicEditor.libraryClasses.ButtonView(locale);',
'                view.set({',
'                    icon: ''<svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M6.91 10.54c.26-.23.64-.21.88.03l3.36 3.14 2.23-2.06a.64.64 0 0 1 .87 0l2.52 2.97V4.5H3.2v10.12l3.71-4.08zm10.27-7.51c.6 0 1.09.47 1.09 1.05v11.84c0 .59-.'
||'49 1.06-1.09 1.06H2.79c-.6 0-1.09-.47-1.09-1.06V4.08c0-.58.49-1.05 1.1-1.05h14.38zm-5.22 5.56a1.96 1.96 0 1 1 3.4-1.96 1.96 1.96 0 0 1-3.4 1.96z"/></svg>'',',
'                    label: ''Custom Button'',',
'                    withText: false,',
'                    tooltip: true',
'                });',
'                view.on(''execute'', () => {',
'                    const imageUrl = prompt( ''Image URL'' );',
'',
'                    if(imageUrl){',
'                        editor.model.change( writer => {',
'                            const imageElement = writer.createElement(''image'', {',
'                                src: imageUrl',
'                            });',
'                            editor.model.insertContent( imageElement, editor.model.document.selection );',
'                        });',
'                    }',
'                });',
'                return view;',
'            });',
'        }',
'    }',
'',
'    options.editorOptions.extraPlugins.push(InsertImageByURLButton);',
'    options.editorOptions.extraPlugins.push(AddClassToAllTable);',
'    options.editorOptions.toolbar.push(''insertImageByUrl'');',
'options.editorOptions.table = {',
'        contentToolbar: [',
'            ''tableColumn'', ''tableRow'', ''mergeTableCells'',',
'            ''tableProperties'', ''tableCellProperties''',
'        ]',
'}',
'',
'options.editorOptions.fontSize = {',
'	options: [',
'		{',
'		 	title: ''9'',',
'		 	model: ''12px''',
'		},',
'        {',
'		 	title: ''11'',',
'		 	model: ''14.5px''',
'		},{',
'            title: ''12'',',
'            model: ''16px''',
'        },',
'        {',
'		 	title: ''13'',',
'		 	model: ''17px''',
'		},',
'        {',
'		 	title: ''14'',',
'		 	model: ''18.5px''',
'		},',
'		{',
'		 	title: ''17'',',
'		 	model: ''22.5px''',
'		},',
'        {',
'		 	title: ''19'',',
'		 	model: ''25px''',
'		},',
'        {',
'		 	title: ''21'',',
'		 	model: ''28px''',
'		}',
'	]',
'}',
'    return options;',
'}'))
,p_attribute_01=>'HTML'
,p_attribute_02=>'FULL'
,p_attribute_03=>'OVERFLOW'
,p_attribute_04=>'180'
,p_attribute_07=>'N'
,p_attribute_25=>'CKEDITOR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(305936148495299046)
,p_name=>'P212_SCRIPT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(520485515455502484)
,p_item_source_plug_id=>wwv_flow_imp.id(520485515455502484)
,p_use_cache_before_default=>'NO'
,p_source=>'SCRIPT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(305936579118299046)
,p_name=>'P212_D5DIRECTIVEDETAIL_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(520485515455502484)
,p_item_source_plug_id=>wwv_flow_imp.id(520485515455502484)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Parent Number'
,p_source=>'D5DIRECTIVEDETAIL_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'PLUGIN_BE.CTB.SELECT2'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DETAILTOPIC  ,id ',
'from d5directivedetail ',
'where D5DIRECTIVE_ID = :P211_ID ',
'      and DETAILTOPIC is not null ;'))
,p_lov_display_null=>'YES'
,p_colspan=>11
,p_field_template=>wwv_flow_imp.id(32322374895728822)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'SINGLE'
,p_attribute_08=>'CIC'
,p_attribute_10=>'100%'
,p_attribute_14=>'Y'
,p_attribute_15=>'30'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(305940044143299050)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(305937603523299050)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(305940567732299051)
,p_event_id=>wwv_flow_imp.id(305940044143299050)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(305939250438299050)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_region_id=>wwv_flow_imp.id(520485515455502484)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Fetch Row from D5DIRECTIVEDETAIL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>305939250438299050
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(305939639956299050)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(520485515455502484)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process Row of D5DIRECTIVEDETAIL'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>305939639956299050
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(305938849169299050)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>305938849169299050
);
wwv_flow_imp.component_end;
end;
/
