prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1379074910136873
,p_default_application_id=>104
,p_default_id_offset=>0
,p_default_owner=>'FARA'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'MyyyyO5IOLETTER_Forms'
,p_alias=>'MYYYYO5IOLETTER-FORMS'
,p_step_title=>'&P0_B5FORMREF_TITLE.'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'function getApexCollectionClob(callback) ',
'{',
'    var apexAjaxObj = new apex.ajax.clob (function() {',
'        var rs = p.readyState;',
'        if(rs==4){',
'            callback(p.responseText);',
'            }',
'        else{ ',
'            return false;',
'            }',
'        });',
'    apexAjaxObj._get();',
'}',
''))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var finding_cke_1_top_interval = setInterval(function(){',
'	var cke= $(''#cke_1_top'');',
'	if(cke.length>0){',
'		clearInterval(finding_cke_1_top_interval);',
'		window.setTimeout(function(){',
'			$(''#cke_1_top'').prepend(`<span title="Select from Template" onclick="$(''#btnTemplate'').trigger(''click'');" style="margin-left:3px; ',
'			margin-right:3px;cursor:pointer;position:relative;display:flex;justify-content:center;item-aligns:center;align-items:center;border-radius:6px;width:25px;height:25px;text-align:center;background:linear-gradient(white,#eee);" class="cke_toolbar" rol'
||'e="toolbar"><span class="cke_toolbar_start"></span><span class="cke_toolgroup" role="presentation">',
'			<span aria-hidden="true" style="cursor:pointer;display:block;position:absolute;left:6px;top:6px;" class="fa fa-envelope-bookmark fam-arrow-down fam-is-success"></span>',
'			</span><span class="cke_toolbar_end"></span></span>`);	',
'		},500);',
'',
'	}',
'}, 1000);'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#templateRegion tr:hover td{',
'		background:#eff;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.same-input .select2 .selection .select2-selection {',
'   border: 1px solid #dfdfdf;',
'    height: 30px !important;',
'    min-height: 30px !important;',
'    padding: 1px 2px;',
'    background-color: #f9f9f9;',
'}',
'.apex-item-select, .apex-item-text, .apex-item-textarea {',
'    height: 30px !important;',
'    min-height: 30px !important;',
'    border-radius: 0.6rem;',
'}',
'.a-Button.a-Button--calendar, .a-Button.a-Button--popupLOV {',
'    height: 30px;',
'    min-height: 30px;',
'    border-top-left-radius: 0.6rem;',
'    border-bottom-left-radius: 0.6rem;',
'    border-top-left-radius: 0;',
'    border-bottom-left-radius: 0;',
'    background-color: #f9f9f9;',
'}'))
,p_page_component_map=>'02'
,p_last_upd_yyyymmddhh24miss=>'20231015145816'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(410487245847906221)
,p_plug_name=>'O5IOLETTER_Forms'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--stacked:t-Region--scrollBody:t-Form--slimPadding'
,p_plug_template=>wwv_flow_imp.id(9706102754609458)
,p_plug_display_sequence=>40
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(434497593049660285)
,p_plug_name=>'Form'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--noUI:t-Region--scrollBody:t-Form--noPadding:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(9706102754609458)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(371717134616703392)
,p_plug_name=>'Main_Body'
,p_parent_plug_id=>wwv_flow_imp.id(434497593049660285)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(9706102754609458)
,p_plug_display_sequence=>60
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(371717262929703393)
,p_plug_name=>'Attachfile'
,p_region_name=>'Attachfile'
,p_parent_plug_id=>wwv_flow_imp.id(371717134616703392)
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_imp.id(9709302264609458)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'Y'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(371717361920703394)
,p_plug_name=>'AttachFile'
,p_region_name=>'AttachFile'
,p_parent_plug_id=>wwv_flow_imp.id(371717262929703393)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(9706102754609458)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'PLUGIN_DE.DANIELH.DROPZONE2'
,p_attribute_01=>'COLLECTION'
,p_attribute_02=>'DROPZONE_UPLOAD'
,p_attribute_07=>'STYLE4'
,p_attribute_08=>'100%'
,p_attribute_09=>'350px'
,p_attribute_10=>'0.25'
,p_attribute_12=>'1'
,p_attribute_14=>'700'
,p_attribute_15=>'CHUNKED'
,p_attribute_16=>'true'
,p_attribute_17=>'true'
,p_attribute_18=>'false'
,p_attribute_19=>'false'
,p_attribute_20=>'true'
,p_attribute_22=>'true'
,p_attribute_23=>'600'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(371720040189703421)
,p_plug_name=>'AttachList'
,p_parent_plug_id=>wwv_flow_imp.id(371717262929703393)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(9705634702609457)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct',
'    '''' remove,',
'    a.ID ,',
'    ----',
'    --APEX_ITEM.CHECKBOX2(p_idx => 1, p_value => a.id, p_attributes => ''class="boxes"'') AS SELECTOR ,',
'    ----',
'',
'',
'    ar.B5IDREF_ID,',
'    a.filename ,',
'    a.file_mimetype,',
'    a.file_charset,',
'    apex_util.filesize_mask(dbms_lob.getlength(a.file_blob)) f_len,',
'    a.DESCRIPTION ,',
'    a.tag ,       ',
'    --sys.dbms_lob.getlength(file_blob) as file_size,',
'    case',
'        when instr(upper(a.FILENAME),''.PPT'') > 0 or instr(upper(FILENAME),''.PPTX'') > 0 then',
'            ''fa fa fa-file-powerpoint-o''',
'        when instr(upper(a.FILENAME),''.XLS'') > 0 or instr(upper(FILENAME),''.XLSX'') > 0 then',
'            ''fa fa fa-file-excel-o''',
'        when instr(upper(a.FILENAME),''.DOC'') > 0 or instr(upper(FILENAME),''.DOCX'') > 0 then',
'            ''fa fa fa-file-word-o''',
'        when instr(upper(a.FILENAME),''.PDF'') > 0 then',
'            ''<span aria-hidden="true" class="fa fa-file-pdf-o"></span>''',
'        when instr(upper(a.FILENAME),''.GIF'') > 0 or',
'             instr(upper(a.FILENAME),''.PNG'') > 0 or',
'             instr(upper(a.FILENAME),''.TIFF'') > 0 or',
'             instr(upper(a.FILENAME),''.JPEG'') > 0 or',
'             instr(upper(a.FILENAME),''.JPG'') > 0 then',
'            ''<span aria-hidden="true" class="fa fa-file-image-o"></span>''',
'        else',
'            ''<span aria-hidden="true" class="fa fa-file-o"></span>''',
'        end file_type,',
'    case',
'        when instr(upper(a.FILENAME),''.PPT'') > 0or instr(upper(FILENAME),''.PPTX'') > 0 then',
'            ''MS Powerpoint File''',
'        when instr(upper(a.FILENAME),''.XLS'') > 0 or instr(upper(FILENAME),''.XLSX'') > 0 then',
'            ''MS Excel File''',
'        when instr(upper(a.FILENAME),''.DOC'') > 0 or instr(upper(FILENAME),''.DOCX'') > 0 then',
'            ''MS Word File''',
'        when instr(upper(a.FILENAME),''.PDF'') > 0 then',
'            ''Adobe PDF File''',
'        when instr(upper(a.FILENAME),''.GIF'') > 0 or',
'             instr(upper(a.FILENAME),''.PNG'') > 0 or',
'             instr(upper(a.FILENAME),''.TIFF'') > 0 or',
'             instr(upper(a.FILENAME),''.JPG'') > 0 then',
'            ''Image File''',
'        else',
'            ''Text File''',
'        end file_type_title,',
'    ar.ATTACHDATE,',
'    lower(listagg(u."USERID", '' , '') WITHIN GROUP(ORDER BY u.id) OVER(PARTITION BY u.id,ar.A5ATTACHMENT_ID)) created_by',
'    --sys.dbms_lob.getlength(a.file_blob) ',
'',
'    from A5ATTACHMENT a',
'    LEFT JOIN  A5ATTACHMENTRELATED ar  on a.id = ar.A5ATTACHMENT_ID',
'    left join u5user_v u on u.id = ar.U5USER_ID ',
'    where ar.B5IDREF_ID = :P5_ID',
'',
'    '))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(412973014714668999)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'N'
,p_owner=>'SHAJIEI'
,p_internal_uid=>412973014714668999
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129718469081250902)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'O'
,p_column_label=>'Download'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_format_mask=>'DOWNLOAD:A5ATTACHMENT:FILE_BLOB:ID::FILE_MIMETYPE:FILENAME:::attachment:#FILENAME#:FARAATTACH'
,p_use_as_row_header=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129714075806250892)
,p_db_column_name=>'B5IDREF_ID'
,p_display_order=>20
,p_column_identifier=>'C'
,p_column_label=>'B5idref Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129714466874250893)
,p_db_column_name=>'FILENAME'
,p_display_order=>30
,p_column_identifier=>'D'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129714890483250894)
,p_db_column_name=>'FILE_MIMETYPE'
,p_display_order=>40
,p_column_identifier=>'E'
,p_column_label=>'File Mimetype'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129715293104250895)
,p_db_column_name=>'FILE_CHARSET'
,p_display_order=>50
,p_column_identifier=>'F'
,p_column_label=>'File Charset'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129715643099250896)
,p_db_column_name=>'F_LEN'
,p_display_order=>60
,p_column_identifier=>'G'
,p_column_label=>'F Len'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129716057299250897)
,p_db_column_name=>'DESCRIPTION'
,p_display_order=>70
,p_column_identifier=>'H'
,p_column_label=>'Description'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129716408154250898)
,p_db_column_name=>'TAG'
,p_display_order=>80
,p_column_identifier=>'I'
,p_column_label=>'Tag'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129716876034250899)
,p_db_column_name=>'FILE_TYPE'
,p_display_order=>90
,p_column_identifier=>'J'
,p_column_label=>'File Type'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129717297296250899)
,p_db_column_name=>'FILE_TYPE_TITLE'
,p_display_order=>100
,p_column_identifier=>'K'
,p_column_label=>'File Type Title'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129717640017250900)
,p_db_column_name=>'ATTACHDATE'
,p_display_order=>110
,p_column_identifier=>'L'
,p_column_label=>'Attachdate'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129718078897250901)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>120
,p_column_identifier=>'M'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129718896385250903)
,p_db_column_name=>'REMOVE'
,p_display_order=>130
,p_column_identifier=>'P'
,p_column_label=>'Remove'
,p_column_link=>'javascript:void(null);'
,p_column_linktext=>'<span class="t-Icon fa fa-trash-o delete-note" aria-hidden="true"></span>'
,p_column_link_attr=>'data-id=#ID#'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(413004147768704419)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1297192'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:ATTACHDATE:F_LEN:CREATED_BY::REMOVE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(434497442090660284)
,p_plug_name=>'Body_Content'
,p_parent_plug_id=>wwv_flow_imp.id(371717134616703392)
,p_region_template_options=>'#DEFAULT#:t-Region--showIcon:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(9706102754609458)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>9
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(434497233125660282)
,p_plug_name=>'Info_Two'
,p_parent_plug_id=>wwv_flow_imp.id(434497593049660285)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--noBorder:t-Region--scrollBody:t-Form--slimPadding:t-Form--stretchInputs:margin-top-sm:margin-bottom-none'
,p_plug_template=>wwv_flow_imp.id(9706102754609458)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(198293735792561281)
,p_plug_name=>'Sub1'
,p_parent_plug_id=>wwv_flow_imp.id(434497233125660282)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody:t-Form--slimPadding'
,p_plug_template=>wwv_flow_imp.id(9706102754609458)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'TABLE'
,p_query_table=>'O5IOLETTER'
,p_include_rowid_column=>true
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(198293853421561282)
,p_plug_name=>'Sub2'
,p_parent_plug_id=>wwv_flow_imp.id(434497233125660282)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody:t-Form--slimPadding:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(9706102754609458)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(434497397305660283)
,p_plug_name=>'More Info'
,p_parent_plug_id=>wwv_flow_imp.id(434497593049660285)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(9706102754609458)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_plug_display_when_condition=>'P0_B5FORMREF_CODE'
,p_plug_display_when_cond2=>'114'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(446204338057214812)
,p_plug_name=>'Template List'
,p_region_name=>'templateRegion'
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_imp.id(9704689740609457)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select O.ID,',
'       O.CODE,',
'       O.B5HCSTATUS_ID,',
'       O.B5FORMREFIDS,',
'       O.SUBJECT ,',
'       LISTAGG( b.code || '' - '' ||B.TITLE, ''<br>'' ) WITHIN GROUP (ORDER BY B.TITLE) AS NAME',
'  from O5LETTERTEMPLATE O',
'  inner join B5FORMREF_V B ON b.ID IN (SELECT TEXTPART FROM B5UTIL.SPLIT(O.B5FORMREFIDS,'':'')) ',
'  --where :P0_B5FORMREF_ID in (SELECT TEXTPART FROM B5UTIL.SPLIT(O.B5FORMREFIDS,'':'')) ',
'  GROUP BY  O.ID,',
'       O.CODE,',
'       O.B5HCSTATUS_ID,',
'       O.B5FORMREFIDS,',
'       O.SUBJECT'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(446204500100214813)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'N'
,p_owner=>'RAHMATI'
,p_internal_uid=>446204500100214813
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129730272689250922)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'select'
,p_column_link=>'javascript:$s(''P640_O5LETTERTEMPLATE_ID'',''#ID#'');console.log(''#ID#'');'
,p_column_linktext=>'<img src="#WORKSPACE_IMAGES#ok-icon.png" class="apex-edit-pencil" width="30px" alt="Select">'
,p_column_link_attr=>'select-link'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'select-link'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129730697681250922)
,p_db_column_name=>'CODE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Code'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129731061410250923)
,p_db_column_name=>'B5HCSTATUS_ID'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'B5hcstatus Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129731440056250923)
,p_db_column_name=>'B5FORMREFIDS'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'B5formrefids'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129731805673250924)
,p_db_column_name=>'SUBJECT'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Subject'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129732293480250924)
,p_db_column_name=>'NAME'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(154479129290621305)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1297326'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:CODE:B5HCSTATUS_ID:B5FORMREFIDS:SUBJECT:NAME'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(129712428506250887)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(434497593049660285)
,p_button_name=>'other_coding'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#:t-Button--small'
,p_button_template_id=>wwv_flow_imp.id(9742423357609473)
,p_button_image_alt=>'Other Coding'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=112:76:&SESSION.::&DEBUG.::P0_B5FORMREF_CODE,P0_PARENT_PAGEID:375,640'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P0_B5FORMREF_CODE = 40 OR :P0_B5FORMREF_CODE = 41 THEN',
'RETURN TRUE;',
'END IF;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P0_B5FORMREF_CODE =40 OR :P0_B5FORMREF_CODE =41 THEN',
'RETURN TRUE;',
'END IF;'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(129709690227250884)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(434497593049660285)
,p_button_name=>'btnTemplate'
,p_button_static_id=>'btnTemplate'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--small'
,p_button_template_id=>wwv_flow_imp.id(17514615811112701)
,p_button_image_alt=>'Btntemplate'
,p_button_position=>'TOP'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-envelope-bookmark'
,p_button_cattributes=>'style="display:none;"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(129710098464250885)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(434497593049660285)
,p_button_name=>'BtnReply'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--small:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(9742595523609473)
,p_button_image_alt=>'Reply'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:RP,640:P0_B5FORMREF_CODE,P5_B5IDREF_ID,P5_B5HCFORWARDREPLY_CODE,P5_B5IDREF_IDS_RECEIVER,P0_ID:114,&P5_ID.,OAOR,&P5_B5IDREF_ID_1.,0'
,p_button_condition=>'P5_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-reply'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(129710476232250886)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(434497593049660285)
,p_button_name=>'BtnForward'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--small:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(9742595523609473)
,p_button_image_alt=>'Forward'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:RP,640:P0_B5FORMREF_CODE,P5_B5IDREF_ID,P5_B5HCFORWARDREPLY_CODE,P0_ID:114,&P5_ID.,OAOF,0'
,p_button_condition=>'P5_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-mail-forward'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(129710868668250886)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(434497593049660285)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--small:t-Button--success:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(9742595523609473)
,p_button_image_alt=>'Create'
,p_button_position=>'TOP'
,p_button_condition=>'P5_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(129711253673250886)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(434497593049660285)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--small:t-Button--success:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(9742595523609473)
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'TOP'
,p_button_condition=>'P5_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-save-as'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(129711628119250887)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(434497593049660285)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--small:t-Button--danger:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(9742595523609473)
,p_button_image_alt=>'Delete'
,p_button_position=>'TOP'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_button_condition=>'P5_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-trash'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(129712042452250887)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(434497593049660285)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--small:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(9742595523609473)
,p_button_image_alt=>'Cancel'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:107:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-remove'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(129750928278250946)
,p_branch_name=>'Go To Page 640'
,p_branch_action=>'f?p=&APP_ID.:645:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129704157542250876)
,p_name=>'P5_B5IDREF_ID_1_LABEL'
,p_item_sequence=>8
,p_item_plug_id=>wwv_flow_imp.id(410487245847906221)
,p_source=>'SELECT h.name FROM b5hc_v h WHERE h.code = CASE :P0_B5FORMREF_CODE WHEN ''40'' THEN ''BD10'' WHEN ''41'' THEN ''BD9'' WHEN ''114'' THEN ''BD9'' ELSE NULL END'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129704525092250878)
,p_name=>'P5_B5IDREF_IDS_RECEIVER_LABEL'
,p_item_sequence=>9
,p_item_plug_id=>wwv_flow_imp.id(410487245847906221)
,p_source=>'SELECT h.name FROM b5hc_v h WHERE h.code = CASE :P0_B5FORMREF_CODE WHEN ''40'' THEN ''BD9'' WHEN ''41'' THEN ''BD10'' WHEN ''114'' THEN ''BD10'' ELSE NULL END'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129704943130250879)
,p_name=>'P5_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(410487245847906221)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129705315013250879)
,p_name=>'P5_B5FINANCIALYEAR_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(410487245847906221)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_item_default=>':APP_B5FINANCIALYEAR_ID'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_source=>'B5FINANCIALYEAR_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129705726240250880)
,p_name=>'P5_B5FORMREF_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(410487245847906221)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_item_default=>':P0_B5FORMREF_ID'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_source=>'B5FORMREF_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129706109755250880)
,p_name=>'P5_Z5SIGNATORYPOST_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(410487245847906221)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_source=>'Z5SIGNATORYPOST_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129706571127250881)
,p_name=>'P5_SIGNATORYNAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(410487245847906221)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_source=>'SIGNATORYNAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129706966477250881)
,p_name=>'P5_INSERTDATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(410487245847906221)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_item_default=>'sysdate'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_source=>'INSERTDATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129707341093250882)
,p_name=>'P5_B5COUNTRYDIVISIONTYPE_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(410487245847906221)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_source=>'B5COUNTRYDIVISIONTYPE_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1379074910136873
,p_default_application_id=>104
,p_default_id_offset=>0
,p_default_owner=>'FARA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129707707118250882)
,p_name=>'P5_O5CLASSEUR_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(410487245847906221)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_source=>'O5CLASSEUR_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129708118112250882)
,p_name=>'P5_O5CATEGORY_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(410487245847906221)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_source=>'O5CATEGORY_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129708560210250883)
,p_name=>'P5_B5HCSTATUS_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(410487245847906221)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    During number;',
'begin',
'    select id into During from b5hc where code=''ST2''; --During',
'    return During;',
'end;'))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_source=>'B5HCSTATUS_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129708986746250883)
,p_name=>'P5_B5HCSECURITY_ID_HIDDEN'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(410487245847906221)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_source=>'B5HCSECURITY_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P0_B5FORMREF_CODE'
,p_display_when2=>'114'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129719679274250905)
,p_name=>'P5_DELETEID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(371720040189703421)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129720395188250906)
,p_name=>'P5_SUBJECT'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(434497442090660284)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Subject'
,p_source=>'SUBJECT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>500
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(9742083268609472)
,p_item_template_options=>'#DEFAULT#:margin-bottom-md'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129720761418250906)
,p_name=>'P5_BODY'
,p_source_data_type=>'CLOB'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(434497442090660284)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Body'
,p_source=>'BODY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(9741849336609472)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options){',
'',
'    function findViewChild( viewElement, viewElementName, conversionApi ) {',
'        const viewChildren = Array.from( conversionApi.writer.createRangeIn( viewElement ).getItems() );',
'        return viewChildren.find( item => item.is( ''element'', viewElementName ) );',
'    } ',
'  ',
'    function AddClassToAllTable( editor ) {',
'        editor.conversion.for( ''downcast'' ).add( dispatcher => {',
'        dispatcher.on( ''insert:table'', ( evt, data, conversionApi ) => {',
'        const viewWriter = conversionApi.writer;',
'        const viewFigure = conversionApi.mapper.toViewElement( data.item );',
'        viewWriter.setAttribute( ''style'', ''margin:1em auto;'', viewFigure ); //***********test',
'        const viewElementtable = findViewChild( viewFigure, ''table'', conversionApi );',
'        viewWriter.setAttribute( ''style'', ''border-collapse:collapse;width:100%;'', viewElementtable );',
'        /*',
'          Array.from( conversionApi.writer.createRangeIn( viewFigure ).getItems(),item=> {',
'               if(item.name=="td"){',
'                    viewWriter.setAttribute( ''style'', ''border:1px solid gray;'', item ) ;',
'               }',
'                ',
'          });',
'          */',
'        }, { priority: ''low'' } );',
'    } );',
'    ',
'}',
'',
'',
'    class InsertImageByURLButton extends ClassicEditor.libraryClasses.Plugin {',
'        init(){',
'            const editor = this.editor;',
'            editor.ui.componentFactory.add(''insertImageByUrl'', locale => {',
'                const view = new ClassicEditor.libraryClasses.ButtonView(locale);',
'                view.set({',
'                    icon: ''<svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M6.91 10.54c.26-.23.64-.21.88.03l3.36 3.14 2.23-2.06a.64.64 0 0 1 .87 0l2.52 2.97V4.5H3.2v10.12l3.71-4.08zm10.27-7.51c.6 0 1.09.47 1.09 1.05v11.84c0 .59-.'
||'49 1.06-1.09 1.06H2.79c-.6 0-1.09-.47-1.09-1.06V4.08c0-.58.49-1.05 1.1-1.05h14.38zm-5.22 5.56a1.96 1.96 0 1 1 3.4-1.96 1.96 1.96 0 0 1-3.4 1.96z"/></svg>'',',
'                    label: ''Custom Button'',',
'                    withText: false,',
'                    tooltip: true',
'                });',
'                view.on(''execute'', () => {',
'                    const imageUrl = prompt( ''Image URL'' );',
'',
'                    if(imageUrl){',
'                        editor.model.change( writer => {',
'                            const imageElement = writer.createElement(''image'', {',
'                                src: imageUrl',
'                            });',
'                            editor.model.insertContent( imageElement, editor.model.document.selection );',
'                        });',
'                    }',
'                });',
'                return view;',
'            });',
'        }',
'    }',
'',
'    options.editorOptions.extraPlugins.push(InsertImageByURLButton);',
'    options.editorOptions.extraPlugins.push(AddClassToAllTable);',
'    options.editorOptions.toolbar.push(''insertImageByUrl'');',
'options.editorOptions.table = {',
'        contentToolbar: [',
'            ''tableColumn'', ''tableRow'', ''mergeTableCells'',',
'            ''tableProperties'', ''tableCellProperties''',
'        ]',
'}',
'',
'options.editorOptions.fontSize = {',
'	options: [',
'		{',
'		 	title: ''9'',',
'		 	model: ''12px''',
'		},',
'        {',
'		 	title: ''11'',',
'		 	model: ''14.5px''',
'		},{',
'            title: ''12'',',
'            model: ''16px''',
'        },',
'        {',
'		 	title: ''13'',',
'		 	model: ''17px''',
'		},',
'        {',
'		 	title: ''14'',',
'		 	model: ''18.5px''',
'		},',
'		{',
'		 	title: ''17'',',
'		 	model: ''22.5px''',
'		},',
'        {',
'		 	title: ''19'',',
'		 	model: ''25px''',
'		},',
'        {',
'		 	title: ''21'',',
'		 	model: ''28px''',
'		}',
'	]',
'}',
'    return options;',
'}'))
,p_attribute_01=>'MARKDOWN'
,p_attribute_02=>'FULL'
,p_attribute_03=>'OVERFLOW'
,p_attribute_04=>'180'
,p_attribute_07=>'N'
,p_attribute_25=>'CKEDITOR'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function ( configObject ) {',
'    configObject.toolbar = [',
'        [''Cut'',''Copy'',''Paste'',''PasteText'',''PasteFromWord'',''-'',''Print'',''Preview'',''-'',''Undo'',''Redo''],',
'        [''Templates''],',
'        [''Iframe'',''Link'',''Unlink'',''Anchor''],',
'        [''Image'',''image2'', ''Table'',''HorizontalRule'',''Smiley'',''SpecialChar'',''PageBreak''],',
'        ''/'',',
'        [''Bold'',''Italic'',''Underline'',''Strike'',''-'',''Subscript'',''Superscript'',''-'',''RemoveFormat''],',
'        [''NumberedList'',''BulletedList'',''-'',''Outdent'', ''Indent'',''Blockquote''],',
'        [''JustifyLeft'',''JustifyCenter'',''JustifyRight'',''JustifyBlock''],',
'        [''TextColor'',''-'',''BGColor''],',
'        [''ShowBlocks'',''Maximize''],',
'        ''/'',',
'        [ ''Styles'', ''Format'', ''Font'', ''FontSize'' ],',
'        [''Source''],',
'        [''Find'',''-'',''Replace''],',
'    ];',
'',
'    configObject.width      = $( "#P5_BODY" ).closest(".t-Form-inputContainer").width() - 12; //set fix width',
'    configObject.height     = 350;  // Specify your desired item height, in pixels',
'    configObject.resize_dir = ''both''',
'    ',
'    return configObject;',
'}',
''))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129721185165250908)
,p_name=>'P5_U5USER_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(434497442090660284)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_item_default=>':APP_USER_ID'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'User'
,p_source=>'U5USER_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_grid_label_column_span=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(9741849336609472)
,p_item_template_options=>'#DEFAULT#:margin-bottom-md'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129722170605250910)
,p_name=>'P5_B5IDREF_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_source=>'B5IDREF_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129722500483250911)
,p_name=>'P5_B5HCFORWARDREPLY_CODE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129722960705250911)
,p_name=>'P5_B5HCFORWARDREPLY_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_source=>'B5HCFORWARDREPLY_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129723332698250912)
,p_name=>'P5_B5IDREF_ID_1'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'pid number;',
'begin',
'if  :P0_B5FORMREF_CODE =114 then ',
'pid := :APP_USER_ID ;',
'else ',
'pid := NUll ;',
'',
'END IF;',
'return pid;',
'end;'))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'&P5_B5IDREF_ID_1_LABEL.'
,p_source=>'B5IDREF_ID_1'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_lov_display_null=>'YES'
,p_read_only_when=>'P0_B5FORMREF_CODE'
,p_read_only_when2=>'114'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(9741849336609472)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129723774069250912)
,p_name=>'P5_B5IDREF_IDS_RECEIVER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_prompt=>'&P5_B5IDREF_IDS_RECEIVER_LABEL.'
,p_source=>'B5IDREF_IDS_RECEIVER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_lov_display_null=>'YES'
,p_read_only_when=>'P5_B5HCFORWARDREPLY_CODE'
,p_read_only_when2=>'OAOR'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(9741849336609472)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'Y'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_attribute_11=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129724105831250913)
,p_name=>'P5_B5IDREF_IDS_COPY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Copy Reciver'
,p_source=>'B5IDREF_IDS_COPY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_lov_display_null=>'YES'
,p_field_template=>wwv_flow_imp.id(9741849336609472)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'Y'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_attribute_11=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129724849410250914)
,p_name=>'P5_O5SCSECRETARIAT_ID'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(198293853421561282)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Secretariat'
,p_source=>'O5SCSECRETARIAT_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT SC_NAME, SC_ID FROM fara.B5UTIL.softcode_lov2(''O5'',''SEC'',:APP_C5COMPANY_ID ) ;'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_grid_label_column_span=>2
,p_display_when=>'P0_B5FORMREF_CODE'
,p_display_when2=>'114'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(9741849336609472)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129725243253250914)
,p_name=>'P5_INDICATORNO'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(198293853421561282)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Ind. No'
,p_source=>'INDICATORNO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_colspan=>5
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(9742083268609472)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129725639087250915)
,p_name=>'P5_INDICATORDATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(198293853421561282)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_item_default=>'sysdate'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Ind. Date'
,p_source=>'INDICATORDATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_colspan=>7
,p_grid_label_column_span=>2
,p_display_when=>'P0_B5FORMREF_CODE'
,p_display_when2=>'114'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(9741849336609472)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129726075899250915)
,p_name=>'P5_LETTERNO'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(198293853421561282)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Letter No'
,p_source=>'LETTERNO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>30
,p_colspan=>5
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(9742083268609472)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129726417957250916)
,p_name=>'P5_LETTERDATE'
,p_source_data_type=>'DATE'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(198293853421561282)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Letter Date'
,p_source=>'LETTERDATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_tag_css_classes=>'date-picker'
,p_begin_on_new_line=>'N'
,p_colspan=>7
,p_read_only_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(9741849336609472)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129727174227250917)
,p_name=>'P5_B5HCSECURITY_ID'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(434497397305660283)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Security'
,p_source=>'B5HCSECURITY_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov_language=>'PLSQL'
,p_lov=>'RETURN B5UTIL.hardcode_lov(''B'',1,''SEC'');'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(9742083268609472)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:margin-bottom-md'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129727509123250917)
,p_name=>'P5_B5HCLETTERSTATE_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(434497397305660283)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Letter State'
,p_source=>'B5HCLETTERSTATE_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov_language=>'PLSQL'
,p_lov=>'RETURN B5UTIL.hardcode_lov(''B'',1,''LES'');'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_display_when=>'P0_B5FORMREF_CODE'
,p_display_when2=>'114'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(9741849336609472)
,p_item_template_options=>'#DEFAULT#:margin-bottom-md'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129727962373250918)
,p_name=>'P5_B5HCPRIORITY_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(434497397305660283)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Priority'
,p_source=>'B5HCPRIORITY_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov_language=>'PLSQL'
,p_lov=>'RETURN B5UTIL.hardcode_lov(''B'',1,''PRY'');'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(9741849336609472)
,p_item_template_options=>'#DEFAULT#:margin-bottom-md'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129728336013250918)
,p_name=>'P5_DEADTIME'
,p_source_data_type=>'DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(434497397305660283)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Dead Time'
,p_source=>'DEADTIME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_tag_css_classes=>'date-picker'
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(9741849336609472)
,p_item_template_options=>'#DEFAULT#:margin-bottom-md'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129728718264250919)
,p_name=>'P5_B5HCIOTYPE_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(434497397305660283)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_prompt=>'IO Type'
,p_source=>'B5HCIOTYPE_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov_language=>'PLSQL'
,p_lov=>'RETURN B5UTIL.hardcode_lov(''B'',1,''ILT'');'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_grid_label_column_span=>1
,p_display_when=>'P0_B5FORMREF_CODE'
,p_display_when2=>'114'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(9741849336609472)
,p_item_template_options=>'#DEFAULT#:margin-bottom-md'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129729115845250919)
,p_name=>'P5_O5SCACTION_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(434497397305660283)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Action'
,p_source=>'O5SCACTION_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT SC_NAME, SC_ID FROM fara.B5UTIL.softcode_lov2(''O5'',''ACT'',:APP_C5COMPANY_ID ) ;'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(9741849336609472)
,p_item_template_options=>'#DEFAULT#:margin-bottom-md'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129729540852250920)
,p_name=>'P5_KEYWORDS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(434497397305660283)
,p_item_source_plug_id=>wwv_flow_imp.id(198293735792561281)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Keywords'
,p_source=>'KEYWORDS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>100
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(9741849336609472)
,p_item_template_options=>'#DEFAULT#:margin-bottom-md'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129733036063250925)
,p_name=>'P5_O5LETTERTEMPLATE_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(446204338057214812)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(129737956602250934)
,p_name=>'Set_Indicator_No'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P5_O5SCSECRETARIAT_ID'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129738445344250934)
,p_event_id=>wwv_flow_imp.id(129737956602250934)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P5_O5SCSECRETARIAT_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129738943222250935)
,p_event_id=>wwv_flow_imp.id(129737956602250934)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  SELECT nvl(MAX(i.indicatorno), 0) + 1',
'  INTO :P5_INDICATORNO',
'  FROM o5ioletter i',
'  JOIN b5financialyear f ON i.b5financialyear_id = f.id',
'  WHERE f.b5idref_id_org = :APP_C5COMPANY_ID',
'  AND i.O5SCSECRETARIAT_ID = :P5_O5SCSECRETARIAT_ID',
'  AND i.b5formref_id = (SELECT id FROM b5formref WHERE code = :P0_B5FORMREF_CODE)',
'  AND i.b5financialyear_id = :APP_B5FINANCIALYEAR_ID;',
'EXCEPTION ',
'  WHEN OTHERS THEN',
'      b5logging.v_sql_code     := SQLCODE;',
'      b5logging.v_sql_error    := SQLERRM;',
'      b5logging.v_back_trace   := dbms_utility.format_error_backtrace;',
'      b5logging.v_sub_program  := utl_call_stack.concatenate_subprogram(utl_call_stack.subprogram(1));',
'      b5logging.v_user_message := ''this message show to user'';',
'      b5logging.v_comments     := '''';',
'      b5logging.setlog_package;    ',
'      RAISE;      ',
'END;'))
,p_attribute_02=>'P5_O5SCSECRETARIAT_ID'
,p_attribute_03=>'P5_INDICATORNO'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(129739360535250935)
,p_name=>'New'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P5_LETTERNO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P0_B5FORMREF_CODE'
,p_display_when_cond2=>'114'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129739846995250936)
,p_event_id=>wwv_flow_imp.id(129739360535250935)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--:P5_INDICATORNO := :P5_LETTERNO * -1;',
':P5_INDICATORNO := ''-''||regexp_substr(:P5_LETTERNO ,''\d+'',1,regexp_count(:P5_LETTERNO,''\d+'')) ;'))
,p_attribute_02=>'P5_LETTERNO'
,p_attribute_03=>'P5_INDICATORNO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(129740291716250936)
,p_name=>'New_1'
,p_event_sequence=>30
,p_condition_element=>'P0_B5FORMREF_CODE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'114'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129740730588250937)
,p_event_id=>wwv_flow_imp.id(129740291716250936)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    letter_no varchar2(100);',
'    num number;',
'    v_id number;',
'begin',
'',
'/*',
'    SELECT',
'    --max(to_number( regexp_substr(''123Ali456Majid15'',''\d+'',1,regexp_count(''123Ali456Majid15'',''\d+''))))',
'    nvl(MAX(i.LETTERNO), 0) INTO letter_no',
'         FROM o5ioletter i',
'             INNER JOIN b5financialyear f  ON i.b5financialyear_id = f.id',
'         WHERE f.b5idref_id_org = :APP_C5COMPANY_ID',
'               AND i.b5formref_id = (select id from b5formref where code = :P0_B5FORMREF_CODE );',
'*/               ',
'    SELECT  LETTERNO into letter_no from --get the maximum letter no',
'    (',
'        select i.LETTERNO ',
'         FROM o5ioletter i',
'             INNER JOIN b5financialyear f  ON i.b5financialyear_id = f.id',
'         WHERE f.b5idref_id_org = :APP_C5COMPANY_ID',
'               AND i.b5formref_id = (select id from b5formref where code = :P0_B5FORMREF_CODE )',
'               order by to_number(regexp_substr(i.LETTERNO ,''\d+'',1,regexp_count(i.LETTERNO ,''\d+'')) ) desc ',
'    )',
'    where rownum=1;',
'               ',
'    if nvl(regexp_count(letter_no,''\d+''),0)!=0 then',
'        ',
'        num := regexp_substr(letter_no,''\d+'',1,regexp_count(letter_no,''\d+''));',
'        letter_no :=rtrim(letter_no,num);',
'    else',
'        num :=0;',
'        letter_no:='''';',
'    end if;',
'   :P5_LETTERNO := letter_no || (to_number(nvl(num,0))+1);',
'   :P5_LETTERDATE :=sysdate;',
'   ',
'   apex_debug.error(''**P5_LETTERNO''||:P5_LETTERNO);',
'   apex_debug.error(''**P5_LETTERDATE''||:P5_LETTERDATE);',
'',
'end;'))
,p_attribute_03=>'P5_LETTERNO,P5_LETTERDATE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129741296431250937)
,p_event_id=>wwv_flow_imp.id(129740291716250936)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P5_INDICATORNO'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129741755304250937)
,p_event_id=>wwv_flow_imp.id(129740291716250936)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P5_LETTERNO,P5_LETTERDATE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(129742177259250938)
,p_name=>'Disable Indicator'
,p_event_sequence=>40
,p_condition_element=>'P0_B5FORMREF_CODE'
,p_triggering_condition_type=>'NOT_EQUALS'
,p_triggering_expression=>'114'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129742650632250938)
,p_event_id=>wwv_flow_imp.id(129742177259250938)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P5_INDICATORNO'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1379074910136873
,p_default_application_id=>104
,p_default_id_offset=>0
,p_default_owner=>'FARA'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(129743039273250939)
,p_name=>'beforePageSubmit'
,p_event_sequence=>50
,p_condition_element=>'P0_B5FORMREF_CODE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'114'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexbeforepagesubmit'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129743527572250939)
,p_event_id=>wwv_flow_imp.id(129743039273250939)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P5_LETTERNO,P5_LETTERDATE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(129743944530250939)
,p_name=>'beforePageSubmit_1'
,p_event_sequence=>60
,p_condition_element=>'P0_B5FORMREF_CODE'
,p_triggering_condition_type=>'NOT_EQUALS'
,p_triggering_expression=>'114'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexbeforepagesubmit'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129744485721250940)
,p_event_id=>wwv_flow_imp.id(129743944530250939)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P5_INDICATORNO'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(129744844585250940)
,p_name=>'clearCollession'
,p_event_sequence=>70
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129745380436250941)
,p_event_id=>wwv_flow_imp.id(129744844585250940)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
' IF apex_collection.collection_exists(p_collection_name => ''DROPZONE_UPLOAD'') ',
'  THEN',
'    apex_collection.delete_collection(p_collection_name => ''DROPZONE_UPLOAD'');',
'  END IF;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(129745744110250941)
,p_name=>'New_2'
,p_event_sequence=>80
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.delete-note'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129746281760250941)
,p_event_id=>wwv_flow_imp.id(129745744110250941)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Are You Sure?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129746798064250942)
,p_event_id=>wwv_flow_imp.id(129745744110250941)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P5_DELETEID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''id'')'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129747207685250943)
,p_event_id=>wwv_flow_imp.id(129745744110250941)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete faraattach.a5attachment',
'                  where id = :P5_DELETEID;'))
,p_attribute_02=>'P5_DELETEID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129747770732250943)
,p_event_id=>wwv_flow_imp.id(129745744110250941)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(371720040189703421)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(129748122424250943)
,p_name=>'btnTemplate click'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(129709690227250884)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129748606145250944)
,p_event_id=>wwv_flow_imp.id(129748122424250943)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(446204338057214812)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(129749007652250944)
,p_name=>'select a template'
,p_event_sequence=>100
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(446204338057214812)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129749500361250945)
,p_event_id=>wwv_flow_imp.id(129749007652250944)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var selectedRowLink = $(this.browserEvent.target).closest(''tr'').find(''td > a[select-link]'');',
'if(selectedRowLink.length > 0){',
'    window.location = selectedRowLink.attr(''href'');',
'    this.browserEvent.preventDefault();',
'}',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(129749957330250945)
,p_name=>'O5LETTERTEMPLATE_ID change'
,p_event_sequence=>110
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P5_O5LETTERTEMPLATE_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129750475318250946)
,p_event_id=>wwv_flow_imp.id(129749957330250945)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var letterTemplateId=$v(''P5_O5LETTERTEMPLATE_ID'');',
'$(''#templateRegion'').css(''cursor'',''progress'');',
'//get_letter_template',
'//getApexCollectionClob (function(pReturnedClobValue){ $(''#P1_TEXTAREA'').val(pReturnedClobValue) });',
'if(letterTemplateId>0){',
'	apex.server.process(''get_letter_template'', {',
'            x01: letterTemplateId,',
'        }, {dataType: ''text'',',
'            success: function (resp) {',
'				$(''#templateRegion'').css(''cursor'',''default'');',
'                console.log(''SUCCESS'');',
'                //console.log(resp);',
'                if(resp.indexOf(''SUCCESS'') > -1 ) {',
'                    getApexCollectionClob (function(pReturnedClobValue){',
'						$s(''P5_BODY'',pReturnedClobValue)',
'						//closeModal(''templateRegion'');/*Deprecated Function In Version 20.2*/ ',
'                        apex.theme.closeRegion(''templateRegion'');//close modal after fetching data.	',
'                    });',
'                }',
'            }, ',
'            error: function (request, status, error) {',
'				$(''#templateRegion'').css(''cursor'',''default'');',
'                console.log(''error'');',
'                console.log(request);',
'            }',
'        }); ',
'}',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(129737001490250933)
,p_name=>'Refresh Page'
,p_event_sequence=>130
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(434497593049660285)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129737534497250933)
,p_event_id=>wwv_flow_imp.id(129737001490250933)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P5_B5IDREF_ID_1,P5_B5IDREF_IDS_COPY,P5_B5IDREF_IDS_RECEIVER'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(129735057745250931)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_region_id=>wwv_flow_imp.id(198293735792561281)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Fetch Row from O5IOLETTER'
,p_internal_uid=>129735057745250931
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(129733802685250927)
,p_process_sequence=>30
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set B5HCFORWARDREPLY'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    select id into :P5_B5HCFORWARDREPLY_ID from b5hc where code=:P5_B5HCFORWARDREPLY_CODE;',
'    exception when no_data_found then',
'    select id into :P5_B5HCFORWARDREPLY_ID from b5hc where code=''OAON'';',
'end;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>129733802685250927
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(129736612571250932)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Before Insert'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_id number;',
'begin',
'    if :P5_B5HCSECURITY_ID is null then',
'        select id into v_id from b5hc where code=''SEC-2'';',
'        :P5_B5HCSECURITY_ID_HIDDEN := v_id;',
'    end if;',
'    apex_debug.error(''**P5_B5HCSECURITY_ID :''||:P5_B5HCSECURITY_ID );',
'exception',
'when no_data_found then',
'raise;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>129736612571250932
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(129735405646250931)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(198293735792561281)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process Row of O5IOLETTER'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_process_error_message=>'Action Failed !'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>129735405646250931
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(129736289445250932)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set_P0_ID'
,p_process_sql_clob=>':P0_ID := :P5_ID;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>129736289445250932
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(129734253509250927)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SaveAtach'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  -- get files data from saved apex_collection',
'  CURSOR l_cur_files IS',
'    SELECT c001    AS filename',
'          ,c002    AS mime_type',
'          ,d001    AS date_created',
'          ,n001    AS file_id',
'          ,blob001 AS file_content',
'    FROM apex_collections',
'    WHERE collection_name = ''DROPZONE_UPLOAD'';',
'  o_attach_id NUMBER;',
'  o_file_url  VARCHAR2(1000);',
'  pFormRefID NUMBER;',
'  errText  VARCHAR2(1000);',
'BEGIN',
'',
'  -----------------------',
'  BEGIN',
'    SELECT id  INTO pFormRefID  FROM b5formref  WHERE code = :P0_B5FORMREF_CODE;',
'  ',
'  END;',
'',
'  FOR l_rec_files IN l_cur_files',
'  LOOP',
'    B5UTIL.insert_into_a5attachment(p_b5hctype           => ''IMG''',
'                                   ,p_userid             => NV(''APP_USER_ID'')',
'                                   ,p_filename           => l_rec_files.filename',
'                                   ,p_file_mimetype      => l_rec_files.mime_type',
'                                   ,p_b5financialyear_id => nv(''APP_B5FINANCIALYEAR_ID'')',
'                                   ,p_b5idref_id_org     => nv(''APP_C5COMPANY_ID'')',
'                                   ,p_file_blob          => l_rec_files.file_content',
'                                   ,p_uploadtime         => l_rec_files.date_created',
'                                   ,p_bidref             => NV(''P5_ID'') ---Soltani-97/8/20-change item P5_ID',
'                                   ,o_attach_id          => o_attach_id',
'                                   ,o_file_url           => o_file_url',
'                                   ,p_columnnumber       => 0',
'                                    ',
'                                    );',
'    ---------------------------------------------',
' ',
'  END LOOP;',
'',
'  ---------------------------------------------',
'  -- clear original apex collection (only if exist)',
'  /*IF apex_collection.collection_exists(p_collection_name => ''DROPZONE_UPLOAD'') ',
'  THEN',
'    apex_collection.delete_collection(p_collection_name => ''DROPZONE_UPLOAD'');',
'  END IF;*/',
'  ---------------------------------------------  ',
'EXCEPTION',
'  WHEN OTHERS THEN',
'      errText := SQLERRM;',
'      b5util.setLog(pErrCode => 1, pErrText => errText);',
'      apex_debug_message.log_message(''P460'' || errText);',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Process of Attach was Failed.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Process of Attach was Successfull.'
,p_internal_uid=>129734253509250927
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(129734674874250930)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ClearAtach'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF apex_collection.collection_exists(p_collection_name => ''DROPZONE_UPLOAD'') ',
'  THEN',
'    apex_collection.delete_collection(p_collection_name => ''DROPZONE_UPLOAD'');',
'  END IF;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>129734674874250930
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(129735868941250932)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(129711628119250887)
,p_internal_uid=>129735868941250932
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(129733412434250926)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'get_letter_template'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'subjectClob clob:= empty_clob();',
'',
'begin',
'                 ',
'    if apex_collection.collection_exists(p_collection_name=>''CLOB_CONTENT'' ) then',
'          apex_collection.delete_collection(p_collection_name=>''CLOB_CONTENT'' );',
'    end if;',
'    apex_collection.create_or_truncate_collection(p_collection_name=>''CLOB_CONTENT'' );',
'    dbms_lob.createtemporary( subjectClob, false, dbms_lob.SESSION );',
'',
'    SELECT "BODY"	 ',
'    INTO subjectClob',
'    FROM O5LETTERTEMPLATE',
'    WHERE ID = apex_application.g_x01 ;',
'',
'    apex_collection.add_member(p_collection_name => ''CLOB_CONTENT''  ,p_clob001 => subjectClob);',
'    htp.prn(''SUCCESS-AddMemberCollection'');',
'    exception when others then htp.prn(SQLERRM);',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>129733412434250926
);
wwv_flow_imp.component_end;
end;
/
