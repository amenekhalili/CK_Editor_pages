prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1379074910136873
,p_default_application_id=>108
,p_default_id_offset=>0
,p_default_owner=>'FARA'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'Ckeditor'
,p_step_title=>'&P0_B5FORMREF_TITLE.'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script type="text/javascript">',
'<!--',
'function submitenter(e)',
'{',
'var keycode;',
'if (window.event) keycode = window.event.keyCode;',
'else if (e) keycode = e.which;',
'else return true;',
'',
'if (keycode == 13)',
'   {',
'   apex.submit(''PAGE'');',
'   return false;',
'   }',
'else',
'   return true;',
'}',
'',
'//-->',
'</script>'))
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APP_IMAGES#js/jquery/logError.js',
'#APP_IMAGES#js/jquery/FullCalendarBaseCode.js'))
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var isPersianCalendar = true;',
'String.prototype.toEnglishDigits = function () {',
unistr('    var charCodeZero = ''\06F0''.charCodeAt(0);'),
unistr('    return this.replace(/[\06F0-\06F9]/g, function (w) {'),
'        //debugger;',
'        return w.charCodeAt(0) - charCodeZero;',
'    });',
'}',
'function getRandomColor() {',
'  var letters = ''0123456789ABCDEF'';',
'  var color = ''#'';',
'  for (var i = 0; i < 6; i++) {',
'    color += letters[Math.floor(Math.random() * 16)];',
'  }',
'  return color;',
'}',
'function setRandomColor() {',
'  for(var i = 0;i<$(".block-span").length;i++){',
'      $($(".block-span")[i]).css("background-color", getRandomColor());',
'      var str = $($(".block-span")[i]).html();',
'      var res = str.substring(0, 2);',
'      $($(".block-span")[i]).html(res);',
'  }',
'}',
'function progressRender(){',
'    $(''.fc-day-top'').append(`<div class="col-xs-1 col-sm-1">',
'    <div class="inner-content text-center">',
'    <div class="c100 p40 small center" style="float:right;margin: 2px 2px 0 0;">',
'    <span>25%</span>',
'    <div class="slice"><div class="bar"></div><div class="fill"></div></div>',
'    </div>',
'    </div>',
'    </div>`);',
'    /*$(''.progressWrapper progress'').each(function(){',
'      var prgsVal = $(this).data(''value'');',
'      var maxN = $(this).attr(''max'');',
'      var pop = prgsVal/maxN * 100',
'      ',
'      $(this).prev().css(''left'', pop + ''%'').text(prgsVal);',
'      $(this).val(prgsVal);',
'    });*/',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Developer Toolbar integration */',
'/*apex.builder.nameBuilderWindow();',
'apex.jQuery(''#apex_pages_irr_toolbar'').wrap(''<div class="a-IRR-toolbarWrap" id="apps_irr_wrap_toolbar"></div>'');',
'apex.builder.initStickyHeader(''apps_irr_wrap_toolbar'');',
'apex.theme.defaultStickyTop = function() { return $("#apps_irr_wrap_toolbar").outerHeight(); }*/',
'',
'$("#DESKTOP_ID").hide();',
'$(''#desktop_related'').hide();',
'$(''[headers=DESKTOP_ID]'').hide();',
'$(''[data-view="details"]'').trigger(''click'');',
'setRandomColor();',
'',
'/*for(var i = 0; i <$(''li .need-link'').length; i++ ){',
'    var alink = $($(''li .need-link'')[i]).closest(''li'').find(''a:nth-child(2)'').attr(''href'');',
'    $($("li .need-link")[i]).attr(''href'',alink);',
'    $($(''li .need-link'')[i]).closest(''li'').find(''a:nth-child(2)'').remove();',
'}*/',
'if(window.localStorage.getItem(''ctype'') == 1) { ',
'    //morteza azimi 21/1/97',
'    $.getScript( "#APP_IMAGES#js/jquery/moment.min.js", function( data, textStatus, jqxhr ) {',
'        $.getScript( "#APP_IMAGES#js/jquery/moment-jalaali.js", function( data, textStatus, jqxhr ) {',
'            $.getScript( "#APP_IMAGES#js/jquery/fullcalendar.js", function( data, textStatus, jqxhr ) {',
'                $.getScript( "#APP_IMAGES#js/jquery/fa.js", function( data, textStatus, jqxhr ) {',
'                    activeCalendar(true);',
'                    isPersianCalendar = true;',
'                    console.log(''persianFullCalendar success'');',
'               });',
'                ',
'            });',
'        });',
'        ',
'    });',
'    ',
'    ',
'}',
'else { // render gregorian',
'    $.getScript(''#APP_IMAGES#calendar_v3/moment.min.js'',',
'        function (data, textStatus, jqxhr) {',
'            $.getScript(''#APP_IMAGES#js/jquery/fullcalendar-g.js'', function (data, textStatus, jqxhr) {',
'                activeCalendar(false);',
'                isPersianCalendar = false;',
'                console.log(''gregorianFullCalendar success'');',
'            })',
'        }',
'    );',
'   ',
'}'))
,p_css_file_urls=>'#APP_IMAGES#js/jquery/fullcalendar.min.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.block-span{',
'    transition:background-color .5s;',
'}',
'.fill-div{',
'    height:100%;',
'    width:100%;',
'}',
'.fill-div-height{',
'    height:100%;',
'}',
'.container-card{',
'    display:block;',
'    transition: padding .1s ease-in-out,background-color .1s ease-in-out;',
'    padding:10px 50px;',
'}',
'.container-card:hover{',
'    background-color: #F8F8F8;',
'    box-shadow: 0 0 0 1px #EDEDED inset;',
'}',
'.content-card{',
'    height:80px;',
'    width:80px;',
'}',
'.flex-center-content{',
'    display: flex;',
'    justify-content: center;',
'}',
'.card-continer{',
'    display:flex;',
'}',
'.span-title{',
'    color: #707070;',
'    display: block;',
'    margin-top: 8px;',
'    font-size: 14px;',
'    line-height: 20px;',
'    ',
'}',
'.a-ImageNav-item {',
'    display: table-cell;',
'    width: auto;',
'    text-align: center;',
'    vertical-align: top;',
'}',
'.a-ImageNav-link {',
'    width: 100%;',
'    display: block;',
'    border: none;',
'    padding: 24px 0;',
'    background-color: transparent;',
'    margin: 0;',
'    transition: padding .1s ease-in-out,background-color .1s ease-in-out;',
'}',
'.block-span{',
'    background:orange;',
'    width: 64px;',
'    height: 64px;',
'    display: block;',
'    border-radius: 2px;',
'    margin: 8px;',
'    overflow: hidden;',
'    text-align: center;',
'    line-height: 64px;',
'    white-space: nowrap;',
'    font-size: 20px;',
'    font-weight: 200;',
'    color: #FFF;',
'}',
'.text-title{',
'    display: block;',
'    margin-top: 7px;',
'    color: #555;',
'}',
'.li-card{',
'    margin: 0px;',
'}',
'.li-card:hover{',
'    background:#f8f8f8;',
'}',
'.dis-block{',
'    cursor:pointer;',
'    display:block;',
'}',
'.container-page {',
'    padding: 10px 20px;',
'}',
'.hidden-sub{',
'    display:none;',
'}',
'#view-b{',
'    position: absolute;',
'    right: 10px;',
'    top: 10px;',
'}',
'#desktopir{display:none;}',
'[card_image]{',
'    width:64px;',
'    height:80px;',
'}',
'.t-IRR-region .a-IRR-iconViewTable td{',
'    width:100px;',
'    text-align:center;',
'        padding: 10px;',
'}',
'.t-IRR-region .a-IRR-iconViewTable tr:last-child{',
'    display:none;',
'} ',
'.t-IRR-region .a-IRR-iconViewTable td:hover{',
'    background-color: #F8F8F8;',
'    box-shadow: 0 0 0 1px #EDEDED inset;',
'}',
'.t-IRR-region .a-IRR-iconViewTable tr{',
'    display: flex;',
'    flex-wrap: wrap;',
'}',
'.t-IRR-region .a-IRR-iconViewTable tbody {',
'    display: flex;',
'    flex-wrap: wrap;',
'}',
'.t-Cards{',
'    margin:0;',
'}',
'/*calendar morteza azimi 2/2/97*/',
'.fc-day.fc-today{',
'background: #e4e4e4;',
'/*background: rgb(169,228,247);',
'background: -moz-linear-gradient(45deg, rgba(169,228,247,1) 0%, rgba(15,180,231,1) 100%);',
'background: -webkit-linear-gradient(45deg, rgba(169,228,247,1) 0%,rgba(15,180,231,1) 100%);',
'background: linear-gradient(45deg, rgba(169,228,247,1) 0%,rgba(15,180,231,1) 100%);',
'filter: progid:DXImageTransform.Microsoft.gradient( startColorstr=''#a9e4f7'', endColorstr=''#0fb4e7'',GradientType=1 );*/',
'}',
'.holiday{',
'background: #e56666;',
'/*background: rgb(248,80,50);',
'background: -moz-linear-gradient(45deg, rgba(248,80,50,1) 0%, rgba(241,111,92,1) 18%, rgba(246,41,12,1) 51%, rgba(240,47,23,1) 71%, rgba(231,56,39,1) 100%);',
'background: -webkit-linear-gradient(45deg, rgba(248,80,50,1) 0%,rgba(241,111,92,1) 18%,rgba(246,41,12,1) 51%,rgba(240,47,23,1) 71%,rgba(231,56,39,1) 100%);',
'background: linear-gradient(45deg, rgba(248,80,50,1) 0%,rgba(241,111,92,1) 18%,rgba(246,41,12,1) 51%,rgba(240,47,23,1) 71%,rgba(231,56,39,1) 100%);',
'filter: progid:DXImageTransform.Microsoft.gradient( startColorstr=''#f85032'', endColorstr=''#e73827'',GradientType=1 );*/',
'}',
'#P1620_TYPE_CONTAINER {',
'    margin: 0 5px;',
'}',
'#P1620_TYPE_CONTAINER .t-Form-itemWrapper{',
'    justify-content: flex-end;',
'    white-space: nowrap;',
'}',
'.innerEventButton{',
'    background: #ff8708;',
'    border-radius: 3px;',
'    float: left;',
'    padding: 3px;',
'    margin: 0 5px 0 0;',
'}',
'.innerEventButton:hover{',
'    background:orange;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'17'
,p_last_upd_yyyymmddhh24miss=>'20231015145816'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26235550921388202)
,p_plug_name=>'CKEDITOR'
,p_region_css_classes=>'col-12'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(11796548791586953)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_css_classes=>'col-12'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26237517697388222)
,p_plug_name=>'CALENDAR'
,p_region_name=>'calendar-region'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(11806509318586957)
,p_plug_display_sequence=>20
,p_plug_source=>'<div id="calendar"></div>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26235676471388203)
,p_name=>'P5_CKEDITOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(26235550921388202)
,p_prompt=>'Ckeditor'
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_tag_css_classes=>'col-12'
,p_colspan=>12
,p_grid_label_column_span=>0
,p_grid_column_css_classes=>'col-12'
,p_field_template=>wwv_flow_imp.id(11828894137586970)
,p_item_css_classes=>'col-12'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--radioButtonGroup'
,p_encrypt_session_state_yn=>'N'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options){',
'',
'    function findViewChild( viewElement, viewElementName, conversionApi ) {',
'        const viewChildren = Array.from( conversionApi.writer.createRangeIn( viewElement ).getItems() );',
'        return viewChildren.find( item => item.is( ''element'', viewElementName ) );',
'    } ',
'  ',
'    function AddClassToAllTable( editor ) {',
'        editor.conversion.for( ''downcast'' ).add( dispatcher => {',
'        dispatcher.on( ''insert:table'', ( evt, data, conversionApi ) => {',
'        const viewWriter = conversionApi.writer;',
'        const viewFigure = conversionApi.mapper.toViewElement( data.item );',
'        viewWriter.setAttribute( ''style'', ''margin:1em auto;'', viewFigure ); //***********test',
'        const viewElementtable = findViewChild( viewFigure, ''table'', conversionApi );',
'        viewWriter.setAttribute( ''style'', ''border-collapse:collapse;width:100%;'', viewElementtable );',
'        /*',
'          Array.from( conversionApi.writer.createRangeIn( viewFigure ).getItems(),item=> {',
'               if(item.name=="td"){',
'                    viewWriter.setAttribute( ''style'', ''border:1px solid gray;'', item ) ;',
'               }',
'                ',
'          });',
'          */',
'        }, { priority: ''low'' } );',
'    } );',
'    ',
'}',
'',
'',
'    class InsertImageByURLButton extends ClassicEditor.libraryClasses.Plugin {',
'        init(){',
'            const editor = this.editor;',
'            editor.ui.componentFactory.add(''insertImageByUrl'', locale => {',
'                const view = new ClassicEditor.libraryClasses.ButtonView(locale);',
'                view.set({',
'                    icon: ''<svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M6.91 10.54c.26-.23.64-.21.88.03l3.36 3.14 2.23-2.06a.64.64 0 0 1 .87 0l2.52 2.97V4.5H3.2v10.12l3.71-4.08zm10.27-7.51c.6 0 1.09.47 1.09 1.05v11.84c0 .59-.'
||'49 1.06-1.09 1.06H2.79c-.6 0-1.09-.47-1.09-1.06V4.08c0-.58.49-1.05 1.1-1.05h14.38zm-5.22 5.56a1.96 1.96 0 1 1 3.4-1.96 1.96 1.96 0 0 1-3.4 1.96z"/></svg>'',',
'                    label: ''Custom Button'',',
'                    withText: false,',
'                    tooltip: true',
'                });',
'                view.on(''execute'', () => {',
'                    const imageUrl = prompt( ''Image URL'' );',
'',
'                    if(imageUrl){',
'                        editor.model.change( writer => {',
'                            const imageElement = writer.createElement(''image'', {',
'                                src: imageUrl',
'                            });',
'                            editor.model.insertContent( imageElement, editor.model.document.selection );',
'                        });',
'                    }',
'                });',
'                return view;',
'            });',
'        }',
'    }',
'',
'    options.editorOptions.extraPlugins.push(InsertImageByURLButton);',
'    options.editorOptions.extraPlugins.push(AddClassToAllTable);',
'    options.editorOptions.toolbar.push(''insertImageByUrl'');',
'options.editorOptions.table = {',
'        contentToolbar: [',
'            ''tableColumn'', ''tableRow'', ''mergeTableCells'',',
'            ''tableProperties'', ''tableCellProperties''',
'        ]',
'}',
'',
'options.editorOptions.fontSize = {',
'	options: [',
'		{',
'		 	title: ''9'',',
'		 	model: ''12px''',
'		},',
'        {',
'		 	title: ''11'',',
'		 	model: ''14.5px''',
'		},{',
'            title: ''12'',',
'            model: ''16px''',
'        },',
'        {',
'		 	title: ''13'',',
'		 	model: ''17px''',
'		},',
'        {',
'		 	title: ''14'',',
'		 	model: ''18.5px''',
'		},',
'		{',
'		 	title: ''17'',',
'		 	model: ''22.5px''',
'		},',
'        {',
'		 	title: ''19'',',
'		 	model: ''25px''',
'		},',
'        {',
'		 	title: ''21'',',
'		 	model: ''28px''',
'		}',
'	]',
'}',
'    return options;',
'}'))
,p_attribute_01=>'HTML'
,p_attribute_02=>'FULL'
,p_attribute_03=>'OVERFLOW'
,p_attribute_04=>'180'
,p_attribute_07=>'N'
,p_attribute_25=>'CKEDITOR'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (o) {',
'    //o.width = $("#P218_CONTRCTBODY_TEMPLATE").closest(".t-Form-inputContainer").width() - 2;',
'    o.height = 480;  // Specify your desired item height, in pixels',
'    CKEDITOR.config.contentsCss = ''#APP_IMAGES#style/FontsEditor.css'';',
'    CKEDITOR.config.font_names = ''IRANSans;BHOMA;BKOODAKO;BLOTUS;BLOTUSB;BNAZANB;BNAZANIN;BTRAFB;BTRAFFIC;BZAR;BZARBOLD;'' + CKEDITOR.config.font_names;// specify a custom font',
'    o.allowedContent = true; // force editor to dont touch the data.',
'    o.extraPlugins = ''tableresize'';',
'    //debugger;',
'    return o;',
'}'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26237156274388218)
,p_name=>'P5_CKEDITOR_VALUE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(26235550921388202)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26237628953388223)
,p_name=>'P5_USER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(26237517697388222)
,p_prompt=>'User'
,p_source=>'select id from u5user where id = :APP_USER_ID;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cust as ( ',
'',
'select id,name,LASTNAME from fara.c5person',
'',
'union',
'',
'select id,name,'''' as LASTNAME from c5shop',
'',
'union',
'',
'select id,name,'''' as LASTNAME from c5company )',
'',
'select c.name||'' ''||c.LASTNAME||''/''||listagg(u."USERID", '' , '') WITHIN GROUP(ORDER BY u.id) OVER(PARTITION BY u.id) as d ,u.id as r  from u5user_v u',
'',
'left join cust c on c.id = u.id ',
'',
'left join u5userrelated ur on u.id = ur.U5USER_ID_1 ',
'',
'where ur.B5IDREF_ID_ORG = :APP_C5COMPANY_ID;',
''))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_colspan=>3
,p_grid_label_column_span=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(11828894137586970)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_item_comment=>'Soltani--97/5/24--change email'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26237777586388224)
,p_name=>'P5_SHEETPLAN_URL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(26237517697388222)
,p_item_default=>'null;'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26237893098388225)
,p_name=>'P5_TYPE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(26237517697388222)
,p_prompt=>'Type'
,p_display_as=>'NATIVE_YES_NO'
,p_tag_css_classes=>'text-right P_TYPE'
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_grid_label_column_span=>0
,p_grid_column_css_classes=>'text-right'
,p_field_template=>wwv_flow_imp.id(11828894137586970)
,p_item_css_classes=>'text-right'
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'sheetplan'
,p_attribute_03=>'sheetplan'
,p_attribute_04=>'timesheet'
,p_attribute_05=>'timesheet'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(26238138948388228)
,p_name=>'P5_CALANDAR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(26237517697388222)
,p_prompt=>'Calandar'
,p_display_as=>'PLUGIN_BE.CTB.SELECT2'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'		c.NAME as d,',
'		c.id as r ',
'	from T5CALENDARSHARE cs',
'	left join T5CALENDAR c on c.id = cs.T5CALENDAR_ID ',
'	where cs.U5USER_ID = :APP_USER_ID',
'/*union	',
'	select ',
'        NAME as d,',
'        id as r',
'	from T5CALENDAR',
'	where B5IDREF_ID_ORG = :B5IDREF_ID ',
'	and ISPRIVATE = 0*/',
'union  ',
'	select ',
'	    NAME as d,',
'		id as r',
'	from T5CALENDAR',
'	where B5IDREF_ID_ORG = :APP_C5COMPANY_ID ',
'	and ISPRIVATE = 0',
''))
,p_lov_display_null=>'YES'
,p_tag_css_classes=>'P_CALENDAR'
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(11828894137586970)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'MULTI'
,p_attribute_08=>'CIC'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(26236184660388208)
,p_name=>'New'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26236226235388209)
,p_event_id=>wwv_flow_imp.id(26236184660388208)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''.cke_toolbox_collapser'').trigger(''click'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(26236385091388210)
,p_name=>'New_1'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P5_CKEDITOR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26236482818388211)
,p_event_id=>wwv_flow_imp.id(26236385091388210)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P5_CKEDITOR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(26236594009388212)
,p_name=>'New_2'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P5_CKEDITOR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'focusout'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26236601697388213)
,p_event_id=>wwv_flow_imp.id(26236594009388212)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P5_CKEDITOR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(26237227026388219)
,p_name=>'New_3'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P5_CKEDITOR'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26237480035388221)
,p_event_id=>wwv_flow_imp.id(26237227026388219)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P5_CKEDITOR_VALUE,P5_CKEDITOR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26237361162388220)
,p_event_id=>wwv_flow_imp.id(26237227026388219)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var CK = CKEDITOR.instances["P5_CKEDITOR"];',
'var data= CK.getData();',
'$(''#P5_CKEDITOR_VALUE'').val(data);',
'apex.server.process(',
'    ''DUMMY'',',
'    {',
'        pageItems: ''#P5_CKEDITOR,#P5_CKEDITOR_VALUE''',
'    },',
'    {',
'        dataType: ''text'',',
'        success: function () {',
'            alert(''SUBMITED...'');',
'        }',
'    }',
');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(26237924346388226)
,p_name=>'OnTypeChange'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P5_TYPE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26238085277388227)
,p_event_id=>wwv_flow_imp.id(26237924346388226)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#calendar'').fullCalendar(''removeEvents'');',
'activeCalendar(true);',
'//LoadCalendarEventsData();',
'if (!$(''#P5_CALENDAR'').val()) {',
'        return;',
'}',
'if(!respEvents) {',
'    return;',
'}',
'for (var i = 0; i<respEvents.length; i++){',
'    if(apex.item(''P5_TYPE'').getValue()=="sheetplan" && respEvents[i].isplan == 1){',
'        if(respEvents[i].start!=null){',
'                var myevent = {eventID:respEvents[i].id,',
'                               title: respEvents[i].title,',
'                               start:respEvents[i].start,',
'                               end:respEvents[i].end,',
'                               taskUrl: respEvents[i].taskUrl,',
'                               createUrl: respEvents[i].createUrl};',
'                $(''#calendar'').fullCalendar(''renderEvent'', myevent, true);',
'         }',
'        window.setTimeout(function(){',
'                     if($(''.innerEventButton'').length==0){',
'                        $(''<i class="fa fa-clock-o innerEventButton" aria-hidden="true"></i>'').insertBefore(''.fc-list-item-title a'');',
'                        $(''<i class="fa fa-clock-o innerEventButton" aria-hidden="true"></i>'').insertBefore(''.fc-title''); ',
'                     }',
'                }, 200);',
'    }',
'    else if(apex.item(''P5_TYPE'').getValue()=="timesheet" && respEvents[i].isplan == 0){',
'        if(respEvents[i].start!=null){',
'                var myevent = {eventID:respEvents[i].id,',
'                               title: respEvents[i].title,',
'                               start:respEvents[i].start,',
'                               end:respEvents[i].end,',
'                               taskUrl: respEvents[i].taskUrl,',
'                               createUrl: respEvents[i].createUrl};',
'                $(''#calendar'').fullCalendar(''renderEvent'', myevent, true);',
'         }',
'        ',
'    }      ',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(26238233662388229)
,p_name=>'OnChangeCal'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P5_CALANDAR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26238302267388230)
,p_event_id=>wwv_flow_imp.id(26238233662388229)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P5_CALANDAR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26238466967388231)
,p_event_id=>wwv_flow_imp.id(26238233662388229)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(26237517697388222)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26238590382388232)
,p_event_id=>wwv_flow_imp.id(26238233662388229)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#calendar'').fullCalendar(''removeEvents'');',
'//$(''#calendar'').fullCalendar(''destroy'');',
'activeCalendar(true);',
'var startDate = $(''#calendar'').data(''fullCalendar'').getView().start;',
'var endDate = $(''#calendar'').data(''fullCalendar'').getView().end;',
'',
'LoadCalendarEventsData(`${startDate.year()}-${startDate.month()+1}-${startDate.date()}`, `${endDate.year()}-${endDate.month()+1}-${endDate.date()}`);'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(26238693761388233)
,p_name=>'New_4'
,p_event_sequence=>70
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(26237517697388222)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'after'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(26238766985388234)
,p_event_id=>wwv_flow_imp.id(26238693761388233)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'alert(''hi'');'
);
wwv_flow_imp.component_end;
end;
/
