prompt --application/pages/page_00643
begin
--   Manifest
--     PAGE: 00643
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1379074910136873
,p_default_application_id=>500
,p_default_id_offset=>0
,p_default_owner=>'FARA'
);
wwv_flow_imp_page.create_page(
 p_id=>643
,p_name=>'O5CORRESPONDENCE_FORM'
,p_step_title=>'&P0_B5FORMREF_TITLE.'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#WORKSPACE_IMAGES#attach-file-preview.js',
''))
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'',
'function sendCartablePacket() {',
'    //(recieverUserId, recieverUsername, recieverImageUrl, message)',
'    window.realTimeCartableHelper.sendCartablePacket(',
'        $(''#P643_TO'').val(), ',
'        $(''#P643_TO'').text(), ',
'        ''null'', ',
'        ''correspondence'');',
'}',
''))
,p_javascript_code_onload=>'$(''.readonly_text'').prop(''readonly'', true);'
,p_css_file_urls=>'#WORKSPACE_IMAGES#ImagePopup.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#t_Body_side {',
'    width: 8% !important;',
'    right: 0px !important;',
'}',
'',
'.t-Form-labelContainer.col-null {',
'    width: 0% !important;',
'}',
'',
'.decearse_margin_left{',
' margin-left: 73px !important;',
'}',
'.t-ButtonRegion-col.t-ButtonRegion-col--content{',
'    padding:0;',
'}',
'div#P640_BODY_DISPLAY,div#cke_P640_BODY{',
'    width: 100% !important;',
'}',
'',
'#_menu{',
'    position: absolute;',
'    right: 7%;',
'}',
'',
'',
'',
'.gallery-parent {',
'    width: fit-content;',
'    border: 1px solid #b7b7b7;',
'    border-radius: 4px;',
'    padding: 6px;',
'    box-shadow: 0px 0px 3px 1px #969595;',
'    margin: 4px;',
'}',
'.locked-row {',
'    user-select: none;',
'    pointer-events: none;',
'    background-color: #cecece;',
'}',
'#attached-records_ig_grid_view_container .a-GV-w-scroll tr:not(.is-inserted) {',
'    user-select: none;',
'    pointer-events: none;',
'}',
'#t_Body_side {',
'    width: 8% !important;',
'    right: 0px !important;',
'}',
'',
'.t-Form-labelContainer.col-null {',
'    width: 0% !important;',
'}',
'',
'.decearse_margin_left{',
' margin-left: 73px !important;',
'}',
'.t-ButtonRegion-col.t-ButtonRegion-col--content{',
'    padding:0;',
'}',
'div#P640_BODY_DISPLAY,div#cke_P640_BODY{',
'    width: 100% !important;',
'}',
'',
'',
'    .cke_editable img.cke_widget_element {',
'        max-width: 100%;',
'        height: auto;',
'    }',
'',
'#preview-report {',
'    min-height: 50px;',
'    border: 1px solid #555;',
'    margin: 0px;',
'}',
'.selected-btn {',
'    background-color: #056bbf !important;',
'    color: #fff !important;',
'}',
'.selected-btn .fa {',
'    color: #fff !important;',
'}',
'',
'',
'/*-------------------------*/',
'.select2-container {',
'    width: 100% !important;',
'}',
'.has-btn-side .select2-selection {',
'    height: 28px;',
'    border-radius: 4px 0 0 4px !important;',
'}',
'.u-RTL .has-btn-side .select2-selection {',
'    height: 28px;',
'    border-radius: 0 4px 4px 0 !important;',
'}',
'.is-side-btn {',
'    height: 28px;',
'    margin-top: 8px;',
'    margin-left: -20px !important;',
'    border-radius: 0;',
'    z-index: 9;',
'}',
'.is-plus-btn{',
'    height: 24px;',
'    padding: 6px 12px;',
'}',
'.u-RTL .is-side-btn {',
'    height: 28px;',
'    margin-top: 8px;',
'    margin-right: -17px !important;',
'}',
'.js-rightCollapsed .is-side-btn {',
'    height: 28px;',
'    margin-top: 8px;',
'    margin-left: -17px !important;',
'}',
'.js-rightCollapsed.u-RTL .is-side-btn {',
'    height: 28px;',
'    margin-top: 8px;',
'    margin-right: -17px !important;',
'} ',
'#_menu span.t-Button-label {',
'    position: relative;',
'    bottom: 2px;',
'}',
'/*[start] fix style _menu m.azimi 97/4/9*/',
'@media (min-width:800px){',
'    [data-menu="definereciever_menu"]{',
'        /*margin-left: 0 !important;*/',
'        left:20px;',
'    }',
'}',
'/* input select2  KAMA*/',
'span.select2-selection.select2-selection--multiple{',
'    height:auto !important;',
'    min-height:34px !important;',
'}',
'button#_menu{',
'    height:34px;',
'    margin-top: 8px;',
'    padding:0;',
'    padding-left: 7px;',
'    padding-right: 7px;',
'}',
'#preview-stage img {',
'    cursor: pointer;',
'}',
'.display_only {',
'    border: none !important;',
'    box-shadow: none !important;',
'    background: transparent !important;',
'    user-select: none !important;',
'    pointer-events: none;',
'}',
'.display-only-column {',
'    border: none !important;',
'    box-shadow: none !important;',
'    user-select: none !important;',
'    pointer-events: none;',
'}',
'/* input select2 */',
'',
'',
'/*[end]*/',
'/* vahid seraj 97/04/27 */',
'.categoryAlert{',
'    box-shadow: red 0px 0px 8px 1px;',
'    color: red !important;',
'}',
'.categoryAlert:after{',
'    content: "Category not found...!";',
'    font-size: 10px;',
'    position: absolute;',
'    left: 0;',
'    top: 26px;',
'}',
'.t-Button[onclick="apex.submit({request:''CheckFinancialYear'',validate:true});"] {',
'    display: none;',
'}',
'/* end */',
' img.scanned {',
'    max-width: 100%;',
'    height: auto;',
'}',
'',
'/*morteza rahat 97.5.8 scanned image tag*/',
'',
'.close-btn{',
'    position: absolute !important;',
'    left: -5px;',
'    top: -5px;',
'    cursor: pointer;',
'}',
'.img-container{',
'    position: relative !important;',
'    width: 85%;',
'    margin: 0 auto;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(68234327446132701)
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'morteza rahat 97.5.4',
'APP_IMAGES to WORKSPACE_IMAGES and deleted v1.0.6 from attach-file-preview'))
,p_page_component_map=>'02'
,p_last_upd_yyyymmddhh24miss=>'20231015145817'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29638837118260002)
,p_plug_name=>'COPY_FORM'
,p_region_name=>'COPY_FORM'
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(32282897949728808)
,p_plug_display_sequence=>120
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       SUBJECT,',
'       BODY',
'  from O5LETTERTEMPLATE'))
,p_plug_source_type=>'NATIVE_IG'
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(29639090558260004)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(29639405257260008)
,p_name=>'SUBJECT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SUBJECT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Subject'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>true
,p_max_length=>500
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(29639594810260009)
,p_name=>'BODY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BODY'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Body'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>true
,p_max_length=>32767
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(29639643290260010)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_03=>'N'
,p_enable_hide=>true
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(29639723461260011)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_03=>'N'
,p_enable_hide=>true
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(29638973108260003)
,p_internal_uid=>29638973108260003
,p_is_editable=>true
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>true
,p_requires_filter=>false
,p_max_row_count=>100000
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU:SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU:RESET:SAVE'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(29649701921496603)
,p_interactive_grid_id=>wwv_flow_imp.id(29638973108260003)
,p_static_id=>'12621'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(29649865104496603)
,p_report_id=>wwv_flow_imp.id(29649701921496603)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(29650380071496607)
,p_view_id=>wwv_flow_imp.id(29649865104496603)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(29639090558260004)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(29650832033496612)
,p_view_id=>wwv_flow_imp.id(29649865104496603)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(29639405257260008)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(29651311803496614)
,p_view_id=>wwv_flow_imp.id(29649865104496603)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(29639594810260009)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(29654056183559240)
,p_view_id=>wwv_flow_imp.id(29649865104496603)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(29639643290260010)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(94022036865956631)
,p_plug_name=>'hiddenButtonList_carboncopy'
,p_region_name=>'carboncopy'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(32273317843728805)
,p_plug_display_sequence=>100
,p_list_id=>wwv_flow_imp.id(32602891505743107)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(32319925589728820)
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(241012868782655334)
,p_name=>'History'
,p_template=>wwv_flow_imp.id(32283891449728808)
,p_display_sequence=>80
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Comments--chat'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with s as (',
'                select Code||''-''||name as d , id as r from J5ORGCHART',
'             union all',
'                select NATIONALID||''-''||name as d , id as r from C5COMPANY',
'             union all',
'                select Code||''-''||name as d , id as r from C5GOODS',
'             union all',
'                select Code||''-''||name as d , id as r from C5SHOP',
'             union all',
'                select NATIONALCODE||''-''||name||'' ''||lastname as d , id as r from c5person',
'           )',
'select distinct ',
'     co.id',
'    ,co.INSERTDATE',
'    ,co.SUBJECT',
'    ,ct.B5IDREF_ID_1 ',
'    ,c.name||''-''||c.lastname sender',
'    ,s.d as receiver ',
'from O5CORRESPONDENCE co',
'inner join O5CARTABLE ct on ct.B5IDREF_ID_2 = co.id',
'inner join c5person c on c.id = co.U5USER_ID',
'left join s on s.r = ct.B5IDREF_ID_1',
'where co.id = :P643_ID'))
,p_required_role=>wwv_flow_imp.id(68234107797132700)
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(76905482889559349)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>'Soltani-97/8/24'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76091012279686742)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>6
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68234107797132700)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76090164230686733)
,p_query_column_id=>2
,p_column_alias=>'INSERTDATE'
,p_column_display_sequence=>1
,p_column_heading=>'Insertdate'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68234107797132700)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76090202772686734)
,p_query_column_id=>3
,p_column_alias=>'SUBJECT'
,p_column_display_sequence=>2
,p_column_heading=>'Subject'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68234107797132700)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76090443460686736)
,p_query_column_id=>4
,p_column_alias=>'B5IDREF_ID_1'
,p_column_display_sequence=>3
,p_column_heading=>'B5idref id 1'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68234107797132700)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76090860542686740)
,p_query_column_id=>5
,p_column_alias=>'SENDER'
,p_column_display_sequence=>4
,p_column_heading=>'Sender'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68234107797132700)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76090900137686741)
,p_query_column_id=>6
,p_column_alias=>'RECEIVER'
,p_column_display_sequence=>5
,p_column_heading=>'Receiver'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68234107797132700)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(245258379612987505)
,p_plug_name=>'attach_Attribute'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--scrollBody:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(32284354317728808)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_column=>9
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(276455247345910748)
,p_plug_name=>'Attached Files'
,p_parent_plug_id=>wwv_flow_imp.id(245258379612987505)
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--pill'
,p_plug_template=>wwv_flow_imp.id(32287539323728809)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(75500040737501581)
,p_plug_name=>'Preview'
,p_parent_plug_id=>wwv_flow_imp.id(276455247345910748)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(32284354317728808)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(101325254972778176)
,p_plug_name=>'PopUpImagePlaceholder'
,p_parent_plug_id=>wwv_flow_imp.id(75500040737501581)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--noUI:t-Region--scrollBody:t-Form--noPadding:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(32284354317728808)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="myModal" class="modal">',
'  <span class="close">&times;</span>',
'  <img class="modal-content" id="img01">',
'  <div class="rotations">',
'      <span class="rotate-left fa fa-undo"></span>',
'      <span class="rotate-right fa fa-repeat" ></span>',
'  </div>',
'  <div id="caption"></div>  ',
'</div>'))
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(161444032650146064)
,p_name=>'Preview_Buttons_REPORT'
,p_region_name=>'preview-report'
,p_parent_plug_id=>wwv_flow_imp.id(75500040737501581)
,p_template=>wwv_flow_imp.id(32284354317728808)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_new_grid_row=>false
,p_grid_column_span=>1
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH pth AS',
' (SELECT oc.id',
'        ,oc.o5cartable_id parent_id',
'        ,oc.b5idref_id_2',
'        ,LEVEL',
'        ,sys_connect_by_path(id, ''/'') "PATH"',
'  FROM o5cartable oc',
'  CONNECT BY PRIOR oc.o5cartable_id = oc.id',
'  START WITH oc.id = (select max(id) from O5CARTABLE where B5IDREF_ID_2 = :P643_id))',
'SELECT a.id ,',
'A.filename as FILE_NAME,',
'A.file_mimetype as FILE_TYPE,',
'    CASE A.file_mimetype ',
'                  WHEN ''image/gif'' THEN ''fa fa-file-image-o''',
'                  WHEN ''image/jpeg'' THEN ''fa fa-file-image-o''',
'                  WHEN ''image/png'' THEN ''fa fa-file-image-o''',
'                  WHEN ''video/mp4'' THEN ''fa fa-file-video-o''',
'                  WHEN ''audio/mp3'' THEN ''fa fa-file-audio-o''',
'                  WHEN ''application/vnd.openxmlformats-officedocument.wordprocessingml.document'' THEN ''fa fa-file-word-o''',
'                  WHEN ''application/pdf'' THEN ''fa fa-file-pdf-o''',
'                  WHEN ''text/plain'' THEN ''fa fa-file-text''',
'     ELSE ''fa fa-paperclip'' END AS BTN_ICON',
'',
'FROM a5attachmentrelated ar',
'inner join a5attachment a on a.id = ar.a5attachment_id',
'JOIN pth ON ar.b5idref_id = pth.b5idref_id_2'))
,p_required_role=>wwv_flow_imp.id(68234107797132700)
,p_ajax_items_to_submit=>'P643_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(32289721455728810)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(42854230374433456)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68234107797132700)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(42854689040433457)
,p_query_column_id=>2
,p_column_alias=>'FILE_NAME'
,p_column_display_sequence=>2
,p_column_heading=>'File name'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68234107797132700)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(42855091723433457)
,p_query_column_id=>3
,p_column_alias=>'FILE_TYPE'
,p_column_display_sequence=>3
,p_column_heading=>'File type'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68234107797132700)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(42855446488433457)
,p_query_column_id=>4
,p_column_alias=>'BTN_ICON'
,p_column_display_sequence=>4
,p_column_heading=>'Btn icon'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68234107797132700)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(161445240441146076)
,p_plug_name=>'Preview Stage'
,p_region_name=>'preview-stage'
,p_parent_plug_id=>wwv_flow_imp.id(75500040737501581)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(32284354317728808)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(87869576022325041)
,p_plug_name=>'Scan'
,p_parent_plug_id=>wwv_flow_imp.id(276455247345910748)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(32284354317728808)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(87869729334325042)
,p_plug_name=>'Other'
,p_parent_plug_id=>wwv_flow_imp.id(276455247345910748)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(32283891449728808)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>'select ID,B5IDREF_ID, NAME, DESCRIPTION from A5ATTACHMENTELSE where B5IDREF_ID = :P643_ID'
,p_plug_source_type=>'NATIVE_IG'
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>'o5automation.isEditable(nvl(:P643_ID,0)) '
,p_plug_read_only_when2=>'PLSQL'
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'vahid seraj ------------ 1397/04/08',
'set static id for grid',
'------------------------------------'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(87870294940325048)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(87870380852325049)
,p_name=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Name'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>true
,p_max_length=>100
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(87870545528325050)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Description'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>true
,p_max_length=>500
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(87870617542325051)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_enable_hide=>true
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(87870737821325052)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_enable_hide=>true
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(92220093384525304)
,p_name=>'B5IDREF_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'B5IDREF_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>60
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P643_ID'
,p_duplicate_value=>true
,p_include_in_export=>false
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(87870240344325047)
,p_internal_uid=>87870240344325047
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_max_row_count=>100000
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SET'
,p_show_total_row_count=>false
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(92227083373525565)
,p_interactive_grid_id=>wwv_flow_imp.id(87870240344325047)
,p_static_id=>'12622'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(92227247339525565)
,p_report_id=>wwv_flow_imp.id(92227083373525565)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(92227700378525567)
,p_view_id=>wwv_flow_imp.id(92227247339525565)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(87870294940325048)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(92228257344525595)
,p_view_id=>wwv_flow_imp.id(92227247339525565)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(87870380852325049)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(92228700483525596)
,p_view_id=>wwv_flow_imp.id(92227247339525565)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(87870545528325050)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(92229229107525598)
,p_view_id=>wwv_flow_imp.id(92227247339525565)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(87870617542325051)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(92232936092538581)
,p_view_id=>wwv_flow_imp.id(92227247339525565)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(92220093384525304)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(93963472130105405)
,p_plug_name=>'Attache'
,p_parent_plug_id=>wwv_flow_imp.id(276455247345910748)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(32284354317728808)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(101459516201014146)
,p_plug_name=>'attach file'
,p_parent_plug_id=>wwv_flow_imp.id(93963472130105405)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(32283891449728808)
,p_plug_display_sequence=>35
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct',
'    a.ID,',
'    ----',
'    --APEX_ITEM.CHECKBOX2(p_idx => 1, p_value => a.id, p_attributes => ''class="boxes"'') AS SELECTOR ,',
'    ----',
'    ''/ords/fara/image/image/''||a.id   as download,',
'    ar.B5IDREF_ID,',
'    a.filename ,',
'    a.file_mimetype,',
'    a.file_charset,',
'    apex_util.filesize_mask(dbms_lob.getlength(a.file_blob)) f_len,',
'    a.DESCRIPTION ,',
'    a.tag ,       ',
'    --sys.dbms_lob.getlength(file_blob) as file_size,',
'    case',
'        when instr(upper(a.FILENAME),''.PPT'') > 0 or instr(upper(FILENAME),''.PPTX'') > 0 then',
'            ''fa fa fa-file-powerpoint-o''',
'        when instr(upper(a.FILENAME),''.XLS'') > 0 or instr(upper(FILENAME),''.XLSX'') > 0 then',
'            ''fa fa fa-file-excel-o''',
'        when instr(upper(a.FILENAME),''.DOC'') > 0 or instr(upper(FILENAME),''.DOCX'') > 0 then',
'            ''fa fa fa-file-word-o''',
'        when instr(upper(a.FILENAME),''.PDF'') > 0 then',
'            ''fa fa fa-file-pdf-o''',
'        when instr(upper(a.FILENAME),''.GIF'') > 0 or',
'             instr(upper(a.FILENAME),''.PNG'') > 0 or',
'             instr(upper(a.FILENAME),''.TIFF'') > 0 or',
'             instr(upper(a.FILENAME),''.JPEG'') > 0 or',
'             instr(upper(a.FILENAME),''.JPG'') > 0 then',
'            ''fa fa fa-file-image-o''',
'        else',
'            ''fa fa fa-file-o''',
'        end file_type,',
'    case',
'        when instr(upper(a.FILENAME),''.PPT'') > 0or instr(upper(FILENAME),''.PPTX'') > 0 then',
'            ''MS Powerpoint File''',
'        when instr(upper(a.FILENAME),''.XLS'') > 0 or instr(upper(FILENAME),''.XLSX'') > 0 then',
'            ''MS Excel File''',
'        when instr(upper(a.FILENAME),''.DOC'') > 0 or instr(upper(FILENAME),''.DOCX'') > 0 then',
'            ''MS Word File''',
'        when instr(upper(a.FILENAME),''.PDF'') > 0 then',
'            ''Adobe PDF File''',
'        when instr(upper(a.FILENAME),''.GIF'') > 0 or',
'             instr(upper(a.FILENAME),''.PNG'') > 0 or',
'             instr(upper(a.FILENAME),''.TIFF'') > 0 or',
'             instr(upper(a.FILENAME),''.JPG'') > 0 then',
'            ''Image File''',
'        else',
'            ''Text File''',
'        end file_type_title,',
'    ar.ATTACHDATE,',
'    lower(listagg(u."USERID", '' , '') WITHIN GROUP(ORDER BY u.id) OVER(PARTITION BY u.id)) created_by',
'    --sys.dbms_lob.getlength(a.file_blob) ',
'',
'    from A5ATTACHMENT a',
'    LEFT JOIN  A5ATTACHMENTRELATED ar  on a.id = ar.A5ATTACHMENT_ID',
'    left join u5user_v u on u.id = ar.U5USER_ID ',
'    where ar.B5IDREF_ID = :P643_ID',
'',
'    '))
,p_plug_source_type=>'NATIVE_IG'
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    1',
'',
'    from A5ATTACHMENT a',
'    LEFT JOIN  FARA.A5ATTACHMENTRELATED ar  on a.id = ar.A5ATTACHMENT_ID',
'    left join u5user u on u.id = ar.U5USER_ID ',
'    where ar.B5IDREF_ID = :P643_ID'))
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>'o5automation.isEditable(nvl(:P643_ID,0)) '
,p_plug_read_only_when2=>'PLSQL'
,p_plug_comment=>'Soltani-97/5/24-change create by'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1379074910136873
,p_default_application_id=>500
,p_default_id_offset=>0
,p_default_owner=>'FARA'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(101459702656014148)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(101459839987014149)
,p_name=>'DOWNLOAD'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DOWNLOAD'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_LINK'
,p_heading=>'download'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_link_target=>'&DOWNLOAD.'
,p_link_text=>'download file'
,p_link_attributes=>'target="_blank" download'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_escape_on_http_output=>true
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(101459905175014150)
,p_name=>'B5IDREF_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'B5IDREF_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>70
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(101460030642014151)
,p_name=>'FILENAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FILENAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Filename'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>130
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>true
,p_max_length=>100
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(101460114091014152)
,p_name=>'FILE_MIMETYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FILE_MIMETYPE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>80
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(101544116569349103)
,p_name=>'FILE_CHARSET'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FILE_CHARSET'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>90
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(101544209188349104)
,p_name=>'F_LEN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'F_LEN'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HTML_EXPRESSION'
,p_heading=>'Length'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attribute_01=>'&F_LEN. <i class="&FILE_TYPE."></i>'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(101544361016349105)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Description'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>500
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(101544442837349106)
,p_name=>'TAG'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TAG'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Tag'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>150
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>50
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(101544551752349107)
,p_name=>'FILE_TYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FILE_TYPE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>110
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(101544571489349108)
,p_name=>'FILE_TYPE_TITLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FILE_TYPE_TITLE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>100
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(101544687608349109)
,p_name=>'ATTACHDATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ATTACHDATE'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Attachdate'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>160
,p_value_alignment=>'CENTER'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(101544818701349110)
,p_name=>'CREATED_BY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_BY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Created by'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>170
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(101544998169349112)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>60
,p_enable_hide=>true
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(101545157065349113)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_enable_hide=>true
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(101459629601014147)
,p_internal_uid=>101459629601014147
,p_is_editable=>true
,p_edit_operations=>'u:d'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_max_row_count=>100000
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_no_data_found_message=>'No Data Found'
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU:RESET'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(101549710095358908)
,p_interactive_grid_id=>wwv_flow_imp.id(101459629601014147)
,p_static_id=>'12623'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(101549805543358908)
,p_report_id=>wwv_flow_imp.id(101549710095358908)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(101550212960358912)
,p_view_id=>wwv_flow_imp.id(101549805543358908)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(101459702656014148)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(101550727244358942)
,p_view_id=>wwv_flow_imp.id(101549805543358908)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(101459839987014149)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(101551176700358943)
,p_view_id=>wwv_flow_imp.id(101549805543358908)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(101459905175014150)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(101551670112358945)
,p_view_id=>wwv_flow_imp.id(101549805543358908)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(101460030642014151)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(101552187319358947)
,p_view_id=>wwv_flow_imp.id(101549805543358908)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(101460114091014152)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(101552695457358949)
,p_view_id=>wwv_flow_imp.id(101549805543358908)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(101544116569349103)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(101553218664358954)
,p_view_id=>wwv_flow_imp.id(101549805543358908)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(101544209188349104)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(101553737874358956)
,p_view_id=>wwv_flow_imp.id(101549805543358908)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(101544361016349105)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(101554178466358958)
,p_view_id=>wwv_flow_imp.id(101549805543358908)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(101544442837349106)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(101554757087358959)
,p_view_id=>wwv_flow_imp.id(101549805543358908)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(101544551752349107)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(101555229136358961)
,p_view_id=>wwv_flow_imp.id(101549805543358908)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(101544571489349108)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(101555716133358963)
,p_view_id=>wwv_flow_imp.id(101549805543358908)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(101544687608349109)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(101556222999358965)
,p_view_id=>wwv_flow_imp.id(101549805543358908)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(101544818701349110)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(101620158648693874)
,p_view_id=>wwv_flow_imp.id(101549805543358908)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(101544998169349112)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(581658585280644233)
,p_plug_name=>'Attache file'
,p_parent_plug_id=>wwv_flow_imp.id(93963472130105405)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(32283891449728808)
,p_plug_display_sequence=>25
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'PLUGIN_DE.DANIELH.DROPZONE2'
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin ',
'case o5automation.isEditable(nvl(:P643_ID,0)) ',
'when true then ',
'return false ;',
'else ',
'return true ;',
'end case;',
'end;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'COLLECTION'
,p_attribute_02=>'DROPZONE_UPLOAD'
,p_attribute_07=>'STYLE3'
,p_attribute_08=>'400px'
,p_attribute_09=>'400px'
,p_attribute_10=>'0.25'
,p_attribute_12=>'1'
,p_attribute_14=>'700'
,p_attribute_15=>'CHUNKED'
,p_attribute_16=>'true'
,p_attribute_17=>'true'
,p_attribute_18=>'true'
,p_attribute_19=>'false'
,p_attribute_20=>'true'
,p_attribute_22=>'true'
,p_attribute_23=>'600'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(421470928117173385)
,p_plug_name=>'Letter''s Attribute'
,p_parent_plug_id=>wwv_flow_imp.id(245258379612987505)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(32284354317728808)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(419788517921764119)
,p_plug_name=>'design'
,p_parent_plug_id=>wwv_flow_imp.id(421470928117173385)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--stacked:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(32284354317728808)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(419788668049764120)
,p_plug_name=>'UserInformation'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--noUI:t-Region--scrollBody:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(32284354317728808)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(421470731193173383)
,p_plug_name=>'Body'
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_imp.id(32287539323728809)
,p_plug_display_sequence=>50
,p_plug_grid_column_span=>7
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(76689459653077836)
,p_plug_name=>'Forward Message'
,p_parent_plug_id=>wwv_flow_imp.id(421470731193173383)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(32284354317728808)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P658_SELECTEDID2'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_plug_comment=>'Soltani-97/8/28'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(76690538989077847)
,p_plug_name=>'Attached File (Forward)'
,p_parent_plug_id=>wwv_flow_imp.id(76689459653077836)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(32283891449728808)
,p_plug_display_sequence=>45
,p_plug_grid_column_span=>6
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    a.id',
'from a5attachment a ',
'    inner join a5attachmentrelated ar on ar.A5ATTACHMENT_ID = a.id ',
'where ar.b5idref_id = (select B5IDREF_ID_2 from o5cartable where id = :P658_SELECTEDID2)',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P658_SELECTEDID2'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_plug_comment=>'Soltani-97/8/28-forward'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(76690684755077848)
,p_no_data_found_message=>'No Data Found'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_enable_mail_download=>'N'
,p_owner=>'SOLTANI1'
,p_internal_uid=>76690684755077848
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(76690779723077849)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Image'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'IMAGE:A5ATTACHMENT:FILE_BLOB:ID::::::::'
,p_use_as_row_header=>'N'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(77037130038679312)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'770372'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(423686323931498898)
,p_plug_name=>'hidden items'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(32284354317728808)
,p_plug_display_sequence=>60
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(423686387292498899)
,p_plug_name=>'rds'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--scrollBody:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(32284354317728808)
,p_plug_display_sequence=>10
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'N'
,p_attribute_03=>'SESSION'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(423686485509498900)
,p_plug_name=>'Design'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_plug_template=>wwv_flow_imp.id(32284354317728808)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>8
,p_plug_required_role=>wwv_flow_imp.id(68234107797132700)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(29640659619260020)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(29638837118260002)
,p_button_name=>'issue'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(32322885630728823)
,p_button_image_alt=>'Issue'
,p_button_position=>'BELOW_BOX'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(42852753909433444)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(75500040737501581)
,p_button_name=>'NEXT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(32322749267728823)
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-angle-right'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(42853189931433445)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(75500040737501581)
,p_button_name=>'PREVIOUS'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(32322749267728823)
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-chevron-left'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(32984299298781837)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(423686387292498899)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(32322930038728823)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Cancel'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:107:&SESSION.::&DEBUG.:RP,107:P0_B5FORMREF_CODE:1079'
,p_button_condition=>'P0_BACK_TO_CARTABLE'
,p_button_condition2=>'0'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-level-up'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(32984698750781837)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(423686387292498899)
,p_button_name=>'BackToCartable'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(32322930038728823)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Back To Cartable'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:658:&SESSION.:inbox:&DEBUG.:RP:P0_BACK_TO_CARTABLE,P0_B5FORMREF_CODE:0,1021'
,p_button_condition=>'P0_BACK_TO_CARTABLE'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-level-up'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(32985033562781837)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(423686387292498899)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(32322930038728823)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Save'
,p_button_position=>'TOP'
,p_button_execute_validations=>'N'
,p_button_condition=>'P643_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(73837707944008902)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(423686387292498899)
,p_button_name=>'PRINT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(32322749267728823)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Print'
,p_button_position=>'TOP'
,p_button_redirect_url=>'f?p=&APP_ID.:643:&SESSION.:APPLICATION_PROCESS=PRINT_PDF:&DEBUG.:RP:APP_PRINT_LAYOUT_CODE,APP_PRINT_NAME:52,AUTOMATION_643_1'
,p_button_condition=>'P643_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-print'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_button_comment=>'Soltani-97/8/7'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(41376448758543004)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(423686387292498899)
,p_button_name=>'copy'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(32322885630728823)
,p_button_image_alt=>'Recal'
,p_button_position=>'TOP'
,p_button_redirect_url=>'javascript: apex.theme.openRegion(''COPY_FORM'');// openModal(''COPY_FORM''); /*Deprecated Function In Version 20.2*/'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(32985895852781837)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(423686387292498899)
,p_button_name=>'DELETE5'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(32322930038728823)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Delete'
,p_button_position=>'TOP'
,p_button_execute_validations=>'N'
,p_button_condition=>'P643_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-minus'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Soltani-97/8/7-condition',
'rahmati 97/9/25 ,database Action:Select'))
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(76091106526686743)
,p_branch_name=>'On Create'
,p_branch_action=>'f?p=&APP_ID.:107:&SESSION.::&DEBUG.:RP:P0_B5FORMREF_CODE,P643_FORMREF_CODE_HIDDEN:1079,&P643_FORMREF_CODE_HIDDEN.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
,p_branch_condition_type=>'REQUEST_IN_CONDITION'
,p_branch_condition=>'CREATE'
,p_branch_comment=>'Soltani-97/8/23'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(73837634986008901)
,p_branch_name=>'OnSave_Stay'
,p_branch_action=>'f?p=&APP_ID.:643:&SESSION.::&DEBUG.:RP,641:P643_ID,P643_FORMREF_CODE_HIDDEN:&P643_ID.,&P643_FORMREF_CODE_HIDDEN.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>30
,p_branch_condition_type=>'REQUEST_IN_CONDITION'
,p_branch_condition=>'SAVE'
,p_branch_comment=>'Soltani-97/8/7'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(33000565057781844)
,p_branch_name=>'OnDel_GoTo641'
,p_branch_action=>'f?p=&APP_ID.:641:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(32985895852781837)
,p_branch_sequence=>40
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(29640417923260018)
,p_branch_name=>'goto643'
,p_branch_action=>'f?p=&APP_ID.:643:&SESSION.::&DEBUG.:RP:P643_TO,P643_ID488:&P643_TO.,&P643_IDGRID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>50
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29640795128260021)
,p_name=>'P643_IDGRID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(29638837118260002)
,p_display_as=>'NATIVE_HIDDEN'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32973684587781832)
,p_name=>'P643_TO_REPLY_1'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(423686485509498900)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Reply To '
,p_source=>'P658_SENDERID_FOR_REPLY'
,p_source_type=>'ITEM'
,p_display_as=>'PLUGIN_BE.CTB.SELECT2'
,p_named_lov=>'U5USER_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct c.code ||'' ''||c.name  || ''-''|| c.NATIONALID as d ,c.id as r  ',
'from u5userrelated ur  ',
'     join b5publiccoding_v c on c.id = ur.u5user_id_1 and ur.b5idref_id_org = c.B5IDREF_ID_ORG',
'where ur.B5IDREF_ID_ORG = :APP_C5COMPANY_ID',
'--- rezaei 1398/0/06',
';',
''))
,p_display_when=>':P643_REPLY_FORWARD_CARTABLE = 1'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'MULTI'
,p_attribute_08=>'CIC'
,p_item_comment=>'from inbox in cartable'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1379074910136873
,p_default_application_id=>500
,p_default_id_offset=>0
,p_default_owner=>'FARA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32975255405781833)
,p_name=>'P643_SUBJECT'
,p_is_required=>true
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(423686485509498900)
,p_use_cache_before_default=>'NO'
,p_prompt=>'SUBJECT'
,p_placeholder=>'---   subject   ---'
,p_source=>'SUBJECT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(32322433151728822)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32975654116781833)
,p_name=>'P643_BODY'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(423686485509498900)
,p_use_cache_before_default=>'NO'
,p_prompt=>'&nbsp'
,p_source=>'BODY'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_field_template=>wwv_flow_imp.id(32322374895728822)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:margin-top-none:margin-bottom-none:margin-left-none:margin-right-none'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options){',
'',
'    function findViewChild( viewElement, viewElementName, conversionApi ) {',
'        const viewChildren = Array.from( conversionApi.writer.createRangeIn( viewElement ).getItems() );',
'        return viewChildren.find( item => item.is( ''element'', viewElementName ) );',
'    } ',
'  ',
'    function AddClassToAllTable( editor ) {',
'        editor.conversion.for( ''downcast'' ).add( dispatcher => {',
'        dispatcher.on( ''insert:table'', ( evt, data, conversionApi ) => {',
'        const viewWriter = conversionApi.writer;',
'        const viewFigure = conversionApi.mapper.toViewElement( data.item );',
'        viewWriter.setAttribute( ''style'', ''margin:1em auto;'', viewFigure ); //***********test',
'        const viewElementtable = findViewChild( viewFigure, ''table'', conversionApi );',
'        viewWriter.setAttribute( ''style'', ''border-collapse:collapse;width:100%;'', viewElementtable );',
'        /*',
'          Array.from( conversionApi.writer.createRangeIn( viewFigure ).getItems(),item=> {',
'               if(item.name=="td"){',
'                    viewWriter.setAttribute( ''style'', ''border:1px solid gray;'', item ) ;',
'               }',
'                ',
'          });',
'          */',
'        }, { priority: ''low'' } );',
'    } );',
'    ',
'}',
'',
'',
'    class InsertImageByURLButton extends ClassicEditor.libraryClasses.Plugin {',
'        init(){',
'            const editor = this.editor;',
'            editor.ui.componentFactory.add(''insertImageByUrl'', locale => {',
'                const view = new ClassicEditor.libraryClasses.ButtonView(locale);',
'                view.set({',
'                    icon: ''<svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M6.91 10.54c.26-.23.64-.21.88.03l3.36 3.14 2.23-2.06a.64.64 0 0 1 .87 0l2.52 2.97V4.5H3.2v10.12l3.71-4.08zm10.27-7.51c.6 0 1.09.47 1.09 1.05v11.84c0 .59-.'
||'49 1.06-1.09 1.06H2.79c-.6 0-1.09-.47-1.09-1.06V4.08c0-.58.49-1.05 1.1-1.05h14.38zm-5.22 5.56a1.96 1.96 0 1 1 3.4-1.96 1.96 1.96 0 0 1-3.4 1.96z"/></svg>'',',
'                    label: ''Custom Button'',',
'                    withText: false,',
'                    tooltip: true',
'                });',
'                view.on(''execute'', () => {',
'                    const imageUrl = prompt( ''Image URL'' );',
'',
'                    if(imageUrl){',
'                        editor.model.change( writer => {',
'                            const imageElement = writer.createElement(''image'', {',
'                                src: imageUrl',
'                            });',
'                            editor.model.insertContent( imageElement, editor.model.document.selection );',
'                        });',
'                    }',
'                });',
'                return view;',
'            });',
'        }',
'    }',
'',
'    options.editorOptions.extraPlugins.push(InsertImageByURLButton);',
'    options.editorOptions.extraPlugins.push(AddClassToAllTable);',
'    options.editorOptions.toolbar.push(''insertImageByUrl'');',
'options.editorOptions.table = {',
'        contentToolbar: [',
'            ''tableColumn'', ''tableRow'', ''mergeTableCells'',',
'            ''tableProperties'', ''tableCellProperties''',
'        ]',
'}',
'',
'options.editorOptions.fontSize = {',
'	options: [',
'		{',
'		 	title: ''9'',',
'		 	model: ''12px''',
'		},',
'        {',
'		 	title: ''11'',',
'		 	model: ''14.5px''',
'		},{',
'            title: ''12'',',
'            model: ''16px''',
'        },',
'        {',
'		 	title: ''13'',',
'		 	model: ''17px''',
'		},',
'        {',
'		 	title: ''14'',',
'		 	model: ''18.5px''',
'		},',
'		{',
'		 	title: ''17'',',
'		 	model: ''22.5px''',
'		},',
'        {',
'		 	title: ''19'',',
'		 	model: ''25px''',
'		},',
'        {',
'		 	title: ''21'',',
'		 	model: ''28px''',
'		}',
'	]',
'}',
'    return options;',
'}'))
,p_attribute_01=>'HTML'
,p_attribute_02=>'FULL'
,p_attribute_03=>'OVERFLOW'
,p_attribute_04=>'180'
,p_attribute_07=>'N'
,p_attribute_25=>'CKEDITOR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32976329351781833)
,p_name=>'P643_B5HCSECURITY_ID'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(421470928117173385)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    pID        number;',
'begin',
'    select id into pID from b5hc where code =''SEC-1'';',
'    return pID;',
'end;'))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Security'
,p_source=>'B5HCSECURITY_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'RETURN B5UTIL.hardcode_lov(''B'',1,''SEC'');',
''))
,p_cHeight=>1
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
,p_item_comment=>'Soltani-97/8/6-default '
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32976704989781833)
,p_name=>'P643_LETTERNO'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(421470928117173385)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Letter NO'
,p_source=>'LETTERNO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_css_classes=>'readonly_text'
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_css_classes=>'readonly_text'
,p_item_template_options=>'#DEFAULT#'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32977105908781833)
,p_name=>'P643_LETTERDATE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(421470928117173385)
,p_use_cache_before_default=>'NO'
,p_item_default=>'sysdate'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Letter Date'
,p_source=>'LETTERDATE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_css_classes=>'date-picker'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Soltani-97/8/6-CSS Classes and default ',
'Rahmati-97/8/19-Server side condition',
'Soltani-97/8/20-read only P643_ISDRAFT = 0'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32978297348781834)
,p_name=>'P643_DEADTIME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(419788517921764119)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Dead Time'
,p_source=>'DEADTIME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_tag_css_classes=>'date-picker'
,p_colspan=>8
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Soltani-97/8/6-CSS Classes',
'Rahmati-97/8/19-Server side condition'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32978646939781834)
,p_name=>'P643_B5HCPRIORITY_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(419788517921764119)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    pID        number;',
'begin',
'    select id into pID from b5hc where code =''NOR'';',
'    return pID;',
'end;'))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Priority'
,p_source=>'B5HCPRIORITY_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov_language=>'PLSQL'
,p_lov=>'RETURN B5UTIL.hardcode_lov(''B'',1,''PRY'');'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'YES'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
,p_item_comment=>'Soltani-97/8/6-default '
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32979387066781835)
,p_name=>'P643_U5USER_ID_DISPLAY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(419788668049764120)
,p_prompt=>'Sender User'
,p_source=>'APP_USER_NAME'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>7
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32979736727781835)
,p_name=>'P643_INSERTDATE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(419788668049764120)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Insert Date'
,p_source=>'INSERTDATE'
,p_source_type=>'DB_COLUMN'
,p_source_post_computation=>'sysdate'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32980160786781835)
,p_name=>'P643_O5SCACTION_ID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(419788517921764119)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Action'
,p_source=>'O5SCACTION_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select name,id from o5sc where b5hctype_id = (select id from b5hc where code = ''ACT'') and B5IDREF_ID_ORG = :APP_C5COMPANY_ID',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32980913946781835)
,p_name=>'P643_KEYWORDS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(419788517921764119)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Keywords'
,p_source=>'KEYWORDS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>100
,p_cHeight=>2
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32981601194781836)
,p_name=>'P643_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(423686323931498898)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32982028864781836)
,p_name=>'P643_B5IDREF_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(423686323931498898)
,p_use_cache_before_default=>'NO'
,p_source=>'B5IDREF_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32982481744781836)
,p_name=>'P643_FORMREF_CODE_HIDDEN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(423686323931498898)
,p_display_as=>'NATIVE_HIDDEN'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32982821719781836)
,p_name=>'P643_B5FINANCIALYEAR_ID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(423686323931498898)
,p_use_cache_before_default=>'NO'
,p_source=>'B5FINANCIALYEAR_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32983249578781836)
,p_name=>'P643_REPLY_FORWARD_CARTABLE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(423686323931498898)
,p_display_as=>'NATIVE_HIDDEN'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'reply : 1 ',
'forward : 2',
'nothing : null'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41377102142543011)
,p_name=>'P643_ID488'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(423686323931498898)
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P643_ID488'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42853586750433453)
,p_name=>'P643_DISPLAY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(75500040737501581)
,p_prompt=>'&nbsp'
,p_source=>'6'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'SQL'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select FILE_BLOB from A5ATTACHMENT_GET_LOGO_V',
'where B5IDREF_ID = :P643_A5ATTACHMENT_ID'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73574058584905349)
,p_name=>'P643_FORM_MODE_HIDDEN'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(423686323931498898)
,p_display_as=>'NATIVE_HIDDEN'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Soltani-97/8/7-',
'1---show buttons',
'0---doesn''t show buttons'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76565237782572041)
,p_name=>'P643_IDFORWARD'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(423686323931498898)
,p_display_as=>'NATIVE_HIDDEN'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_item_comment=>'Soltani-97/8/24-for subject. correspondence (forward) from cartable '
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76689248740077834)
,p_name=>'P643_SUBJECT_FORWARD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(76689459653077836)
,p_prompt=>'Subject'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>10
,p_grid_label_column_span=>1
,p_display_when=>'P658_SELECTEDID2'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLAIN'
,p_item_comment=>'Soltani-97/8/28-forward'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76689300653077835)
,p_name=>'P643_BODY_FORWARD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(76689459653077836)
,p_prompt=>'Body'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>10
,p_grid_label_column_span=>1
,p_display_when=>'P658_SELECTEDID2'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLAIN'
,p_item_comment=>'Soltani-97/8/28-forward'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76689948313077841)
,p_name=>'P643_LETTERDATE_FORWARD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(76689459653077836)
,p_prompt=>'Letter Date'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>10
,p_grid_label_column_span=>1
,p_display_when=>'P658_SELECTEDID2'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLAIN'
,p_item_comment=>'Soltani-97/8/28'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(245259458843987516)
,p_name=>'P643_B5IDREF_IDS_RECEIVER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(423686485509498900)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Recivers'
,p_source=>'B5IDREF_IDS_RECEIVER'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'PLUGIN_BE.CTB.SELECT2'
,p_named_lov=>'O5IOLETTER_RECIEVER_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  NAME AS D, ID AS R FROM ',
'',
'TABLE(O5AUTOMATION.coding_sender_reciever(:APP_C5COMPANY_ID,:APP_USER_ID)) ;'))
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(32322433151728822)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'MULTI'
,p_attribute_08=>'CIC'
,p_attribute_10=>'100%'
,p_attribute_14=>'Y'
,p_attribute_15=>'20'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(245259596684987517)
,p_name=>'P643_B5IDREF_IDS_COPY'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(423686485509498900)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Copy'
,p_source=>'B5IDREF_IDS_COPY'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'PLUGIN_BE.CTB.SELECT2'
,p_named_lov=>'O5IOLETTER_RECIEVER_LOV5'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  NAME AS D, ID AS R FROM ',
'',
'TABLE(O5AUTOMATION.coding_sender_reciever(:APP_C5COMPANY_ID,:APP_USER_ID)) ;'))
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(32322236557728822)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_security_scheme=>wwv_flow_imp.id(68234107797132700)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'MULTI'
,p_attribute_08=>'CIC'
,p_attribute_10=>'100%'
,p_attribute_14=>'Y'
,p_attribute_15=>'20'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(42843263010232834)
,p_tabular_form_region_id=>wwv_flow_imp.id(101459516201014146)
,p_validation_name=>'Mandatory_Attach_OnInput'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*declare',
'    l_count number ;',
'    ret boolean ;',
'begin',
'    l_count := APEX_COLLECTION.COLLECTION_MEMBER_COUNT( p_collection_name => ''DROPZONE_UPLOAD'') ;',
'    if :P0_B5FORMREF_CODE = 41 and l_count < 10 then',
'        ret := false;',
'        return ret ;',
'    else ',
'        ret := true ;',
'        return ret ;',
'    end if ;',
'end ;*/',
'return false;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'Attach Letter Body'
,p_always_execute=>'Y'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(32990470795781840)
,p_name=>'Onchange'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P643_B5HCLETTERTYPE_ID'
,p_condition_element=>'P643_B5HCLETTERTYPE_ID'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(32990941525781841)
,p_event_id=>wwv_flow_imp.id(32990470795781840)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P643_ISDRAFT'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(32991478371781841)
,p_event_id=>wwv_flow_imp.id(32990470795781840)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P643_ISDRAFT'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(32991898362781841)
,p_name=>'OnChange'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P643_RECIEVER'
,p_condition_element=>'P643_RECIEVER'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(32992328808781841)
,p_event_id=>wwv_flow_imp.id(32991898362781841)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P643_TO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(32992830877781841)
,p_event_id=>wwv_flow_imp.id(32991898362781841)
,p_event_result=>'FALSE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P643_CC'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(32993353587781841)
,p_event_id=>wwv_flow_imp.id(32991898362781841)
,p_event_result=>'FALSE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P643_BCC'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(32993713017781842)
,p_name=>'OngetFocus_cc'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P643_TO'
,p_condition_element=>'P643_CC'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'PLUGIN_BE.CTB.SELECT2|ITEM TYPE|slctopen'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(32994249048781842)
,p_event_id=>wwv_flow_imp.id(32993713017781842)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P643_CC'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(32994632301781842)
,p_name=>'OngetFocus_bcc'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P643_TO'
,p_condition_element=>'P643_BCC'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'PLUGIN_BE.CTB.SELECT2|ITEM TYPE|slctopen'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(32995156794781842)
,p_event_id=>wwv_flow_imp.id(32994632301781842)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P643_BCC'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(32999155023781844)
,p_name=>'OnChangePriority'
,p_event_sequence=>140
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P643_B5HCPRIORITY_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(32999685249781844)
,p_event_id=>wwv_flow_imp.id(32999155023781844)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P643_LETTERNO'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--set defult value for letterno according to org and B5HCPRIORITY_ID ',
'declare ',
'pMax number;',
'begin ',
'select max(o.LETTERNO) into pMax from O5CORRESPONDENCE o',
'left join u5user u on o.U5USER_ID = u.id',
'left join u5userrelated ur on ur.U5USER_ID_1 = u.id',
'where ur.B5IDREF_ID_ORG = :APP_C5COMPANY_ID and o.B5HCPRIORITY_ID = :P643_B5HCPRIORITY_ID  ;--find max letterno filter on org and B5HCPRIORITY_ID',
'pMax := nvl(pMax,0) + 1 ; ',
'--DBMS_OUTPUT.PUT_LINE( pMax);',
'return pMax ;',
'end ;'))
,p_attribute_07=>'P643_B5HCPRIORITY_ID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(23615532190472921)
,p_name=>'getHeight'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P643_TO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(23615699639472922)
,p_event_id=>wwv_flow_imp.id(23615532190472921)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var h = $(''#P643_TO'').closest(''div'').find(''.select2-selection'').height() + 2;',
'$(''#_menu'').css(''height'',h+''px'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(75803316860513035)
,p_name=>'Submit Letter Date'
,p_event_sequence=>190
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'ITEM_IS_NULL'
,p_display_when_cond=>'P643_ID'
,p_da_event_comment=>'Soltani-97/8/20-submit item'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75803407351513036)
,p_event_id=>wwv_flow_imp.id(75803316860513035)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P643_LETTERDATE'
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>'sysdate'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_da_action_comment=>'Soltani-97/8/20-set value item'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75803553956513037)
,p_event_id=>wwv_flow_imp.id(75803316860513035)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P643_LETTERDATE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_da_action_comment=>'Soltani-97/8/20-submit item'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(76565313124572042)
,p_name=>'Set Value For Forward'
,p_event_sequence=>200
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_display_when_cond=>'P658_SELECTEDID2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76565437141572043)
,p_event_id=>wwv_flow_imp.id(76565313124572042)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    pletterID            number;',
'    pCorrID              number;',
'    pHistoryID           number;',
'    pBody                clob;',
'begin ',
'    ----------------------------------------------------------------------------',
'    select count(id) into pHistoryID from o7historyflow',
'    where id = :P658_SELECTEDID2;',
'    ----------------------------------------------------------------------------',
'    select count(i.id) into pletterID from O5IOLETTER i',
'        inner join o5cartable c on c.b5idref_id_2 = i.id',
'    where c.id = :P658_SELECTEDID2;',
'    ----------------------------------------------------------------------------',
'    select count(i.id) into pCorrID from O5CORRESPONDENCE i',
'        inner join o5cartable c on c.b5idref_id_2 = i.id',
'    where c.id = :P658_SELECTEDID2;',
'    ----------------------------------------------------------------------------',
'    if pletterID = 0 and pHistoryID = 0 then ',
'        ------------------------------------------------------------------------',
'        select regexp_replace(i.body, ''<.*?>'') into pBody from O5CORRESPONDENCE i',
'            inner join o5cartable c on c.b5idref_id_2 = i.id',
'        where c.id = :P658_SELECTEDID2;',
'        ------------------------------------------------------------------------',
'    elsif pCorrID = 0 and pHistoryID = 0 then',
'        ------------------------------------------------------------------------',
'        select regexp_replace(i.body, ''<.*?>'') into pBody from O5IOLETTER i',
'            inner join o5cartable c on c.b5idref_id_2 = i.id',
'        where c.id = :P658_SELECTEDID2;',
'        ------------------------------------------------------------------------',
'    elsif pletterID = 0 and pCorrID = 0 then',
'        ------------------------------------------------------------------------',
'        pBody := '''';',
'        ------------------------------------------------------------------------',
'    end if;',
'    :P643_BODY_FORWARD := pBody;',
'     --------------------------------------------------------------------------------------------------------------',
'     exception when others then ',
'          b5logging.v_sql_code := SQLCODE;',
'          b5logging.v_sql_error := SQLERRM;',
'          b5logging.v_back_trace := dbms_utility.format_error_backtrace;',
'          b5logging.v_sub_program := utl_call_stack.concatenate_subprogram(utl_call_stack.subprogram(1));',
'          b5logging.v_user_message := ''this message show to user'';',
'          b5logging.v_comments := ''an error occured in set body in forward'';					 ',
'          b5logging.setlog_package;',
'          dbms_output.put_line(b5logging.v_message);',
'          rollback;',
'     null;',
'    --------------------------------------------------------------------------------------------------------------',
'end;',
''))
,p_attribute_03=>'P643_BODY_FORWARD'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_da_action_comment=>'Soltani-97/8/23-'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1379074910136873
,p_default_application_id=>500
,p_default_id_offset=>0
,p_default_owner=>'FARA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76689579531077837)
,p_event_id=>wwv_flow_imp.id(76565313124572042)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    pletterID            number;',
'    pCorrID              number;',
'    pHistoryID           number;',
'    pSubject             clob;',
'begin ',
'      --------------------------------------------------------------------------',
'    select count(id) into pHistoryID from o7historyflow',
'    where id = :P658_SELECTEDID2;',
'      --------------------------------------------------------------------------',
'    select count(i.id) into pletterID from O5IOLETTER i',
'        inner join o5cartable c on c.b5idref_id_2 = i.id',
'    where c.id = :P658_SELECTEDID2;',
'      --------------------------------------------------------------------------',
'    select count(i.id) into pCorrID from O5CORRESPONDENCE i',
'        inner join o5cartable c on c.b5idref_id_2 = i.id',
'    where c.id = :P658_SELECTEDID2;',
'      --------------------------------------------------------------------------',
'    if pletterID = 0 and pHistoryID  = 0 then ',
'        ------------------------------------------------------------------------',
'        select i.subject into pSubject from O5CORRESPONDENCE i ',
'            inner join o5cartable c on c.b5idref_id_2 = i.id',
'        where c.id = :P658_SELECTEDID2;',
'        ------------------------------------------------------------------------',
'    elsif pCorrID = 0 and pHistoryID = 0 then',
'        ------------------------------------------------------------------------',
'        select i.subject into pSubject from O5IOLETTER i',
'            inner join o5cartable c on c.b5idref_id_2 = i.id',
'        where c.id = :P658_SELECTEDID2;',
'        ------------------------------------------------------------------------',
'    elsif pletterID = 0 and pCorrID = 0 then',
'        ------------------------------------------------------------------------',
'        select subject into pSubject from o7historyflow',
'        where id = :P658_SELECTEDID2;',
'        ------------------------------------------------------------------------',
'    end if;',
'    :P643_SUBJECT_FORWARD := pSubject;',
'      --------------------------------------------------------------------------------------------------------------',
'     exception when others then ',
'          b5logging.v_sql_code := SQLCODE;',
'          b5logging.v_sql_error := SQLERRM;',
'          b5logging.v_back_trace := dbms_utility.format_error_backtrace;',
'          b5logging.v_sub_program := utl_call_stack.concatenate_subprogram(utl_call_stack.subprogram(1));',
'          b5logging.v_user_message := ''this message show to user'';',
'          b5logging.v_comments := ''an error occured in set subject in forward'';					 ',
'          b5logging.setlog_package;',
'          dbms_output.put_line(b5logging.v_message);',
'          rollback;',
'     null;',
'    --------------------------------------------------------------------------------------------------------------',
'end;',
''))
,p_attribute_03=>'P643_SUBJECT_FORWARD'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_da_action_comment=>'Soltani-97/8/28'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76690028356077842)
,p_event_id=>wwv_flow_imp.id(76565313124572042)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    pletterID            number;',
'    pCorrID              number;',
'    pHistoryID           number;',
'    pLetterDate          date;',
'begin ',
'    ----------------------------------------------------------------------------',
'    select count(id) into pHistoryID from o7historyflow',
'    where id = :P658_SELECTEDID2;',
'    ----------------------------------------------------------------------------',
'    select count(i.id) into pletterID from O5IOLETTER i',
'        inner join o5cartable c on c.b5idref_id_2 = i.id',
'    where c.id = :P658_SELECTEDID2;',
'    ----------------------------------------------------------------------------',
'    select count(i.id) into pCorrID from O5CORRESPONDENCE i',
'        inner join o5cartable c on c.b5idref_id_2 = i.id',
'    where c.id = :P658_SELECTEDID2;',
'    ----------------------------------------------------------------------------',
'    if pletterID = 0 and pHistoryID = 0 then ',
'        ------------------------------------------------------------------------',
'        select i.letterdate into pLetterDate from O5CORRESPONDENCE i',
'            inner join o5cartable c on c.b5idref_id_2 = i.id',
'        where c.id = :P658_SELECTEDID2;',
'        ------------------------------------------------------------------------',
'    elsif pCorrID = 0 and pHistoryID = 0 then',
'        ------------------------------------------------------------------------',
'        select i.LETTERDATE into pLetterDate from O5IOLETTER i ',
'            inner join o5cartable c on c.b5idref_id_2 = i.id',
'        where c.id = :P658_SELECTEDID2;',
'        ------------------------------------------------------------------------',
'    elsif pletterID = 0 and pCorrID = 0 then',
'        ------------------------------------------------------------------------',
'        select INSERTDATE into pLetterDate from o7historyflow',
'    where id = :P658_SELECTEDID2;',
'        ------------------------------------------------------------------------',
'    end if;',
'    :P643_LETTERDATE_FORWARD := pLetterDate;',
'     --------------------------------------------------------------------------------------------------------------',
'     exception when others then ',
'          b5logging.v_sql_code := SQLCODE;',
'          b5logging.v_sql_error := SQLERRM;',
'          b5logging.v_back_trace := dbms_utility.format_error_backtrace;',
'          b5logging.v_sub_program := utl_call_stack.concatenate_subprogram(utl_call_stack.subprogram(1));',
'          b5logging.v_user_message := ''this message show to user'';',
'          b5logging.v_comments := ''an error occured in set letter date in forward'';					 ',
'          b5logging.setlog_package;',
'          dbms_output.put_line(b5logging.v_message);',
'          rollback;',
'     null;',
'    --------------------------------------------------------------------------------------------------------------',
'end;',
'',
''))
,p_attribute_03=>'P643_LETTERDATE_FORWARD'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(78705263140097516)
,p_name=>'Set Value To'
,p_event_sequence=>210
,p_condition_element=>'P643_ID'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(78705320220097517)
,p_event_id=>wwv_flow_imp.id(78705263140097516)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_receiver     VARCHAR2(600);',
'BEGIN',
'    WITH cust AS (',
'        SELECT',
'            id,',
'            name,',
'            lastname',
'        FROM',
'            fara.c5person',
'        UNION',
'        SELECT',
'            id,',
'            name,',
'            '''' AS lastname',
'        FROM',
'            c5shop',
'        UNION',
'        SELECT',
'            id,',
'            name,',
'            '''' AS lastname',
'        FROM',
'            c5company',
'    ) SELECT',
'        LISTAGG(c.id,',
'        '','') WITHIN GROUP(',
'        ORDER BY',
'            c.id',
'        ) AS d',
'    INTO',
'        v_receiver',
'      FROM',
'        u5user u',
'        LEFT JOIN cust c ON c.id IN (',
'            u.id',
'        )',
'      WHERE',
'        u.id IN (',
'            SELECT',
'                c1.id',
'            FROM',
'                cust c1',
'                LEFT JOIN u5userrelated ur ON ur.u5user_id_1 = c1.id',
'                INNER JOIN o5cartable o ON o.b5idref_id_1 = c1.id',
'                INNER JOIN b5hc h ON h.id = o.b5hcinout_id',
'            WHERE',
'                ur.b5idref_id_org = :APP_C5COMPANY_ID',
'                AND   o.b5idref_id_2 = :P643_ID',
'                AND   h.code = ''TOO''',
'        );',
'     :P643_TO := v_receiver;',
'END;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(88396676633436014)
,p_name=>'goToPreviousPreview'
,p_event_sequence=>230
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(42853189931433445)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(88396795984436015)
,p_event_id=>wwv_flow_imp.id(88396676633436014)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'//1. get selected button',
'var selectedButton = $(''.selected-btn'');',
'//2. go to previous or go to last',
'var currentIndex = selectedButton.length == 0 ? 0 : selectedButton.index();',
'if(currentIndex == 0) {',
'    $(''.preview-btns-container'').find(''button.preview-file-btn'').last().trigger(''click'');',
'}',
'else {',
'    $(''.preview-btns-container'').find(''button.preview-file-btn'')[currentIndex - 1].click();',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(88396855097436016)
,p_name=>'goToNextPreview'
,p_event_sequence=>240
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(42852753909433444)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(88396913201436017)
,p_event_id=>wwv_flow_imp.id(88396855097436016)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'//1. get selected button',
'var selectedButton = $(''.selected-btn'');',
'//2. go to next or go to last',
'var currentIndex = selectedButton.length == 0 ?',
'    selectedButton.closest(''.preview-btns-container'').find(''button.preview-file-btn'').children().length - 1 ',
'    : selectedButton.index();',
'if(currentIndex == selectedButton.closest(''.preview-btns-container'').find(''button.preview-file-btn'').children().length - 1) {',
'    $(''.preview-btns-container'').find(''button.preview-file-btn'').first().trigger(''click'');',
'}',
'else {',
'    $(''.preview-btns-container'').find(''button.preview-file-btn'')[currentIndex + 1].click();',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(88397037115436018)
,p_name=>'OnFilePreview_Click'
,p_event_sequence=>250
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.preview-file-btn'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(88397142437436019)
,p_event_id=>wwv_flow_imp.id(88397037115436018)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'//1. prevent page submit',
'this.browserEvent.preventDefault();',
'//2. get button element',
'var elem = $(this.triggeringElement).closest(''button'');',
'//3. toggle selected button class',
'$(''.selected-btn'').removeClass(''selected-btn'');',
'elem.addClass(''selected-btn'');',
'//4. initialize some variables',
'var baseFileUrl = ''/ords/fara/image/showimage'';',
'var fileId = elem.attr(''data-id'');',
'var fileType = elem.attr(''file-type'');',
'//5. initialize preview stage',
'$(''#preview-stage'').html('''');',
'//6. render the preview',
'window.generatePreview(`${baseFileUrl}/${fileId}`, fileType, ''#preview-stage'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(40447946530886543)
,p_name=>'SETVALUE_BODY'
,p_event_sequence=>260
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P643_ID48'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(40448013122886544)
,p_event_id=>wwv_flow_imp.id(40447946530886543)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT BODY',
'FROM O5LETTERTEMPLATE',
'WHERE ID=:ID;'))
,p_attribute_02=>'P643_BODY'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(41377297895543012)
,p_name=>'setVlaue_ID488'
,p_event_sequence=>270
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P643_ID488'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_display_when_cond=>'P643_ID488'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41377338985543013)
,p_event_id=>wwv_flow_imp.id(41377297895543012)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P643_BODY'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select body',
'from o5lettertemplate',
'where id=:p643_id488;'))
,p_attribute_07=>'P643_BODY'
,p_attribute_08=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(29639901624260013)
,p_name=>'selectgrid'
,p_event_sequence=>280
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(29638837118260002)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29640050891260014)
,p_event_id=>wwv_flow_imp.id(29639901624260013)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P643_IDGRID'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if(this.data != null){ ',
'        var model = apex.region(''COPY_FORM'').widget().data(''apex-interactiveGrid'').getViews().grid.model; ',
'        debugger;',
'        if(this.data.selectedRecords.length > 0) {',
'         //   var workagreementId = model.getValue(this.data.selectedRecords[0], ''WORKAGREEMENT_ID'');',
'            var Id = model.getValue(this.data.selectedRecords[0], ''ID'');',
'            ',
'            $s("P643_IDGRID", Id);',
'        }        ',
'}'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(32988893681781839)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from O5CORRESPONDENCE'
,p_attribute_02=>'O5CORRESPONDENCE'
,p_attribute_03=>'P643_ID'
,p_attribute_04=>'ID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>32988893681781839
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(32990077307781840)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'clear file collection'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF apex_collection.collection_exists(p_collection_name => ''DROPZONE_UPLOAD'') ',
'  THEN',
'    apex_collection.delete_collection(p_collection_name => ''DROPZONE_UPLOAD'');',
'  END IF;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>32990077307781840
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(32989298842781840)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of O5IOLETTER'
,p_attribute_02=>'O5CORRESPONDENCE'
,p_attribute_03=>'P0_ID'
,p_attribute_04=>'ID'
,p_attribute_09=>'P643_ID'
,p_attribute_11=>'I:U'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed'
,p_internal_uid=>32989298842781840
,p_process_comment=>'Soltani-97/8/23-success message '
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(32988424830781839)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'OnSubmit'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'',
'',
'    -- get files data from saved apex_collection',
'    CURSOR l_cur_files IS',
'    SELECT c001    AS filename,',
'           c002    AS mime_type,',
'           d001    AS date_created,',
'           n001    AS file_id,',
'           blob001 AS file_content',
'    FROM apex_collections',
'    WHERE collection_name = ''DROPZONE_UPLOAD'';',
'    -----',
'        o_attach_id         number;  ',
'        o_file_url  varchar2(1000);',
'    ------------------- recivers : (to/cc/bcc)',
'    vArr1     APEX_APPLICATION_GLOBAL.VC_ARR2;',
'    vArr2     APEX_APPLICATION_GLOBAL.VC_ARR2;',
'    vArr3     APEX_APPLICATION_GLOBAL.VC_ARR2;',
'    ------------------- b5hc inout id :',
'    pRecieversTo varchar2(1000);',
'    pRecieversCc varchar2(1000);',
'    pRecieversBcc varchar2(1000);',
'    p_B5HCINOUT_ID_TO number;',
'    p_B5HCINOUT_ID_CC number;',
'    p_B5HCINOUT_ID_BCC number;',
'    p_B5HCINOUT_ID_SEN number;',
'    -------------------   b5 formref id :',
'    pFormRefID       number;',
'    -------------------   b5hc state id : (draft/none)',
'    pDraftId         number;',
'    pNoneId          number;',
'    pParentId        number;',
'    -------------------',
'    errText       varchar2(4000) ;',
'BEGIN',
'    apex_debug_message.log_message(''raha1'');',
'    begin',
'        select id into p_B5HCINOUT_ID_TO from b5hc where code = ''TOO'' ;',
'        select id into p_B5HCINOUT_ID_CC from b5hc where code = ''CCC'' ;',
'        select id into p_B5HCINOUT_ID_BCC from b5hc where code = ''BCC'' ;',
'        select id into p_B5HCINOUT_ID_SEN from b5hc where code = ''SEN'' ;',
'        -----------------------',
'        select id INTO pDraftId from b5hc where code = ''DRF'' ;',
'        select id INTO pNoneId from b5hc where code = ''NON'' ;',
'    exception when others then',
'        raise_application_error( -20001, ''hc data has problem'' ); ',
'        errText := ''hc data has problem'' ;',
'        b5util.setLog( pErrCode => 6 , pErrText => errText ) ;',
'    end;',
'    ----------------------- ',
'    apex_debug_message.log_message(''raha1'');',
'    ----------------------- reply',
'    if :P643_REPLY_FORWARD_CARTABLE = 1 then',
'        pRecieversTo := :P643_TO_REPLY_1 || '':''  ;',
'    end if;',
'    -----------------------',
'    pRecieversTo := pRecieversTo || :P643_TO ;',
'    pRecieversCc := :P643_CC ;',
'    pRecieversBcc := :P643_BCC ;',
'    -----------------------',
'    pRecieversTo := trim('':'' from pRecieversTo) ;',
'    pRecieversCc := trim('':'' from pRecieversCc) ;',
'    pRecieversBcc := trim('':'' from pRecieversBcc) ;',
'    -----------------------        ',
'    vArr1:=apex_util.string_to_table(pRecieversTo,'':'');',
'    vArr2:=apex_util.string_to_table(pRecieversCc,'':'');    ',
'    vArr3:=apex_util.string_to_table(pRecieversBcc,'':'');    ',
'    -----------------------',
'    begin',
'        select id into pFormRefID from b5formref where code = :P0_B5FORMREF_CODE ;          ',
'        apex_debug_message.log_message(''raha2'');',
'        exception when others then',
'        errText := ''P643_FORMREF_CODE_HIDDEN is null'' ;',
'        b5util.setLog( pErrCode => 1, pErrText => errText ) ;',
'        apex_debug_message.log_message(''raha: ''||errText);',
'        raise;',
'    end;',
'                                                                           ',
'    ----------------------------------------------------',
'    -- send letter to reciever(s) cartable',
'    ----------------------------------------------------',
'    ----------------------------------------------------',
'    -- for parent id',
'    ----------------------------------------------------',
'    case :P643_REPLY_FORWARD_CARTABLE ',
'    when 1 then  --reply ',
'    pParentId := :P658_SELECTEDID2;',
'    when 2 then   --forward',
'    pParentId := :P658_SELECTEDID2;',
'    else',
'    pParentId := null ;',
'    end case;',
'    ----------------------------------------------------',
'    if vArr1.count > 0 then ',
'    for i in 1..vArr1.count loop',
'        insert into O5CARTABLE (',
'            B5HCINOUT_ID,',
'            SUBJECT,',
'            B5IDREF_ID_1,            ',
'            B5FORMREF_ID,',
'            B5IDREF_ID_2,',
'            B5HCSTATUS_ID,',
'            O5CARTABLE_ID',
'        )',
'        values(',
'            p_B5HCINOUT_ID_TO,',
'            :P643_SUBJECT,',
'            vArr1(i),',
'            pFormRefID,',
'            :P643_ID,',
'            decode(:P643_ISDRAFT,0,pNoneId,1,pDraftId),',
'            pParentId',
'            );',
'    end loop;',
'    end if;',
'    -----------------------',
'    if vArr2.count > 0 then',
'    for j in 1..vArr2.count loop',
'        insert into O5CARTABLE (            ',
'            B5HCINOUT_ID,',
'            SUBJECT,',
'            B5IDREF_ID_1,',
'            B5FORMREF_ID,            ',
'            B5IDREF_ID_2,',
'            B5HCSTATUS_ID,',
'            O5CARTABLE_ID)',
'        values(',
'            p_B5HCINOUT_ID_CC,',
'            :P643_SUBJECT,',
'            vArr2(j),',
'            pFormRefID,            ',
'            :P643_ID,',
'            decode(:P643_ISDRAFT,0,pNoneId,1,pDraftId),',
'            pParentId',
'            );            ',
'    end loop;',
'    end if;',
'    -----------------------',
'    if vArr3.count > 0 then',
'    for k in 1..vArr3.count loop',
'        insert into O5CARTABLE (',
'            B5HCINOUT_ID,           ',
'            SUBJECT,',
'            B5IDREF_ID_1,',
'            B5FORMREF_ID,                        ',
'            B5IDREF_ID_2,',
'            B5HCSTATUS_ID,',
'            O5CARTABLE_ID)',
'        values(',
'            p_B5HCINOUT_ID_BCC,',
'            :P643_SUBJECT,',
'           vArr3(k),',
'            pFormRefID,            ',
'            :P643_ID,',
'             decode(:P643_ISDRAFT,0,pNoneId,1,pDraftId),',
'            pParentId',
'            ); ',
'    end loop;',
'    end if;',
'    ----------------------------------------------------',
'    -- send letter to sender cartable',
'    ----------------------------------------------------',
'    apex_debug_message.log_message(''raha3  : ''||pRecieversTo);',
'            ',
'        insert into O5CARTABLE (',
'            B5HCINOUT_ID,           ',
'            SUBJECT,',
'            B5IDREF_ID_1,',
'            B5FORMREF_ID,                        ',
'            B5IDREF_ID_2,',
'            B5HCSTATUS_ID,',
'            O5CARTABLE_ID)',
'        values(',
'            p_B5HCINOUT_ID_SEN,',
'            :P643_SUBJECT,',
'            :APP_USER_ID ,',
'            pFormRefID,            ',
'            :P643_ID,',
'            decode(:P643_ISDRAFT,0,pNoneId,1,pDraftId),',
'            pParentId',
'        );         ',
'--------------------------------------------------------------------------------            ',
'-- file attachment             ',
'--------------------------------------------------------------------------------                            ',
'  ---     "P0_ID" is an application item that will be used in attachment trigger ',
'  ---     and it will be used as related bidref id in attachment related table inserting',
'--------------------------------------------------------------------------------  ',
'  ',
' -- :P0_ID := :P643_ID ;',
'     APEX_DEBUG.MESSAGE(''raha: ''||:P0_ID);',
'  FOR l_rec_files IN l_cur_files ',
'  LOOP',
'     B5UTIL.insert_into_a5attachment',
'            (',
'                 p_b5hctype => ''IMG''',
'                ,p_userid => NV(''APP_USER_ID'') ',
'                ,p_filename => l_rec_files.filename ',
'                ,p_file_mimetype => l_rec_files.mime_type',
'                ,p_b5financialyear_id => nv(''APP_B5FINANCIALYEAR_ID'') ',
'                ,p_b5idref_id_org => nv(''APP_C5COMPANY_ID'')',
'                ,p_file_blob => l_rec_files.file_content',
'                ,p_uploadtime => l_rec_files.date_created',
'                ,p_bidref => NV(''P643_ID'')      ---Soltani-97/8/20-change item P640_ID',
'                ,o_attach_id => o_attach_id          ',
'                ,o_file_url => o_file_url  ',
'                ,p_columnnumber => 0',
'',
'            );  ',
'  ---------------------------------------------',
'  select :P643_ID into :P0_ID from dual ;         ',
'  END LOOP;  ',
'  ',
'  ---------------------------------------------',
'  -- clear original apex collection (only if exist)',
'  /*IF apex_collection.collection_exists(p_collection_name => ''DROPZONE_UPLOAD'') ',
'  THEN',
'    apex_collection.delete_collection(p_collection_name => ''DROPZONE_UPLOAD'');',
'  END IF;*/',
'  ---------------------------------------------  ',
'  exception when others then',
'     begin',
'     errText := sqlerrm ;',
'     b5util.setLog( pErrCode => 1, pErrText => errText ) ;',
'     apex_debug_message.log_message(''raha: ''||errText);',
'     raise;',
'     end;',
'  ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'sqlerrm'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(32985033562781837)
,p_process_success_message=>'Action Processed'
,p_internal_uid=>32988424830781839
,p_process_comment=>'Soltani-97/8/23-success message '
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(32989648949781840)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Reply_Forward_From_Cartable'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'                --set parent_id to master id of selected cartable record',
'                update O5CORRESPONDENCE  set B5IDREF_ID  = :P658_SELECTEDID1 where id = :P643_ID ;    ',
'                ------------------------------',
'                --set parent id in cartable to selected cartable id',
'                --insert into O5CARTABLE ( O5CARTABLE_ID ) values ( :P658_SELECTEDID2 ) ;',
'                ------------------------------',
'                -- update selected cartabl record',
'                -- 1 : reply 2 : forward',
'                case :P643_REPLY_FORWARD_CARTABLE ',
'                when 1 then',
'                    update O5CARTABLE set ISREPLIED = 1 where id = :P658_SELECTEDID2 ;',
'                when 2 then',
'                    update O5CARTABLE set ISFORWARDED = 1 where id = :P658_SELECTEDID2 ;',
'                when 3 then',
'                    --update o75HISTORYFLOW set ISREPLIED = 1 where id = :P658_SELECTEDID2 ;',
'                    null;',
'                when 4 then',
'                    --update O7HISTORYFLOW set ISFORWARDED = 1 where id = :P658_SELECTEDID2 ;',
'                    null;',
'                else ',
'                    null;',
'                end case;',
'                ------------------------------',
'                '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(32985033562781837)
,p_process_when=>':P643_REPLY_FORWARD_CARTABLE = 1 or :P643_REPLY_FORWARD_CARTABLE = 2 or :P643_REPLY_FORWARD_CARTABLE = 3 or :P643_REPLY_FORWARD_CARTABLE = 4'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_process_success_message=>'Action Processed'
,p_internal_uid=>32989648949781840
,p_process_comment=>'Soltani-97/8/23-success message '
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(42835209406232827)
,p_process_sequence=>140
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(87869729334325042)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'other attachments - - Save Interactive Grid Data'
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin  ',
'     case :APEX$ROW_STATUS  ',
'     when ''C'' then --insert',
'     NULL;',
'     -- INSERT IS HANDELED BY ANOTHER PROCCESS SEPERATELY',
'     when ''U'' then  --update',
'         update A5ATTACHMENTELSE  ',
'            set ',
'                NAME = :NAME  ,',
'                DESCRIPTION = :DESCRIPTION ',
'          where id  = :ID;  ',
'     when ''D'' then  --delete',
'         delete A5ATTACHMENTELSE  ',
'         where id = :ID;  ',
'     end case;  ',
'end;  ',
'',
''))
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_process_error_message=>'#SQLERRM#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed'
,p_internal_uid=>42835209406232827
,p_process_comment=>'Soltani-97/8/23-success message '
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(42843555091232835)
,p_process_sequence=>150
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(101459516201014146)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'attach file - Save Interactive Grid Data'
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    case :APEX$ROW_STATUS',
'    when ''C'' then',
'       null;',
'    when ''U'' then',
'        update a5attachment',
'           set description  = :DESCRIPTION,',
'               tag = :TAG',
'         where ID  = :ID;',
'    when ''D'' then',
'        delete a5attachment',
'         where ID = :ID;',
'    end case;',
'end;'))
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_process_error_message=>'#SQLERRM#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed'
,p_internal_uid=>42843555091232835
,p_process_comment=>'Soltani-97/8/23-success message '
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(29639855816260012)
,p_process_sequence=>160
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(29638837118260002)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'COPY_FORM - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>29639855816260012
);
wwv_flow_imp.component_end;
end;
/
