prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1379074910136873
,p_default_application_id=>125
,p_default_id_offset=>0
,p_default_owner=>'FARA'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'test'
,p_step_title=>'&P0_B5FORMREF_TITLE.'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#WORKSPACE_IMAGES#editor-helper.js?v=1.0.1',
'#WORKSPACE_IMAGES#logError.js'))
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'console.log(''APP_PAGE_ID'');',
'console.log(&APP_PAGE_ID.);',
'//setApexCollectionClob (''Some large text value...'', function(){alert(''Data saved to Apex Collection!'')})',
'function setApexCollectionClob (pBigValue, callback) ',
'{',
'    var apexAjaxObj = new apex.ajax.clob (function() {',
'        var rs = p.readyState;',
'        if (rs == 4) {',
'            callback();',
'            } ',
'        else {',
'            return false;',
'            }; ',
'    }); ',
'    apexAjaxObj._set(pBigValue); ',
'}',
'',
'//getApexCollectionClob (function(pReturnedClobValue){ $(''#P1_TEXTAREA'').val(pReturnedClobValue) })',
'function getApexCollectionClob(callback) ',
'{',
'    var apexAjaxObj = new apex.ajax.clob (function() {',
'        var rs = p.readyState;',
'        if(rs==4){',
'            callback(p.responseText);',
'            }',
'        else{ ',
'            return false;',
'            }',
'        });',
'    apexAjaxObj._get();',
'}',
'',
'function selectText(elem){',
'    console.log(''selectText'');',
'    var sel, range;',
'    var el = elem; ',
'    if (window.getSelection && document.createRange) { //Browser compatibility',
'      sel = window.getSelection();',
'      if(sel.toString() == ''''){ //no text selection',
'         window.setTimeout(function(){',
'            console.log(''getSelection2'');',
'            console.log(window.getSelection());             ',
'            range = document.createRange(); //range object',
'            range.selectNodeContents(el); //sets Range',
'            sel.removeAllRanges(); //remove all ranges from selection',
'            sel.addRange(range);//add Range to a Selection.',
'',
'        },1);',
'      }',
'    }else if (document.selection) { //older ie',
'        sel = document.selection.createRange();',
'        if(sel.text == ''''){ //no text selection',
'            range = document.body.createTextRange();//Creates TextRange object',
'            range.moveToElementText(el);//sets Range',
'            range.select(); //make selection.',
'        }',
'    }',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*if( apex.item(''P225_ID'').getValue()>0)',
'    {',
'        apex.server.process(''load_apex_collection'', {',
'            x01: apex.item(''P225_ID'').getValue(),',
'        }, {dataType: ''text'',',
'            success: function (resp) {',
'                console.log(''SUCCESS'');',
'                console.log(resp);',
'                if(resp.indexOf(''SUCCESS'') > -1 ) {',
'                    getApexCollectionClob (function(pReturnedClobValue){',
'                                 apex.item(''P225_TEMPLATEBODY'').setValue(pReturnedClobValue);',
'                    });',
'                }',
'            }, ',
'            error: function (request, status, error) {',
'                console.log(''error'');',
'                console.log(request);',
'            }',
'        }); ',
'    }',
'   ',
'*/',
'',
'                        ',
'var ondraggingtext = '''';',
'$(''[draggable]'').on(''dragstart'', function (e){',
'    console.log(e.target);',
'    //$(e.target).text(''%'' + $(e.target).text() + ''%'');',
'    ',
'    ondraggingtext = ''%'' + $(e.target).text() + ''%'';',
'   ',
'});',
'$(''[draggable]'').on(''dragend'', function (e){',
'    window.getSelection().removeAllRanges();',
'    console.log(''getSelection1'');',
'    console.log(window.getSelection());',
'});',
'',
'CKEDITOR.on(''instanceReady'', function (ev) {   ',
'   ev.editor.on(''drop'', function (e) {',
'        console.log(e); ',
'       console.log(''dataTransfer'');',
'       console.log(e.data.dataTransfer);',
'       //console.log(CKEDITOR.instances.DataTransfer.getData());',
'       ',
'       ',
'       e.data.dataTransfer.setData(''text/html'', ondraggingtext);',
'       ',
'       ondraggingtext = '''';',
'    });    ',
'});',
'',
'',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Form-labelContainer.col.col-2 {',
'    width: 150px;',
'}',
'#P225_TEMPLATEBODY_CONTAINER .t-Form-inputContainer {',
'    overflow: auto;',
'}',
'#bread-crumb{',
'    margin-right: 40px;',
'}',
'[draggable] {',
'    cursor: pointer;',
'}',
'#P225_TEMPLATEBODY_DISPLAY{',
'    width: 100%;',
'}',
'#cke_P225_TEMPLATEBODY {',
'    width: 99% !important;',
'    border: none !important;',
'}',
'',
'#P225_TEMPLATEBODY_DISPLAY html {',
'    border: none !important;',
'}',
'',
'.cke_reset{',
'    background:white !important;   ',
'}',
'html{',
'    border:none !important;',
'}',
'html {',
'   border-color: white !important;',
'}',
''))
,p_step_template=>wwv_flow_imp.id(37072025248997096)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(68231930283123033)
,p_protection_level=>'C'
,p_page_comment=>'saadat 11/15'
,p_page_component_map=>'02'
,p_last_upd_yyyymmddhh24miss=>'20231015145817'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(163798280815813645)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(37087017074997107)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(329550720654743346)
,p_name=>'Payment Table'
,p_template=>wwv_flow_imp.id(37080726059997105)
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_display_point=>'REGION_POSITION_03'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''PRICE.SEQUENCE'' as sequence,',
'    ''PRICE.PERCENT''  as percent,',
'    ''PRICE.DESCRIPTION'' as description,',
'    ''PRICE.PRICE''       as price',
'',
'from dual'))
,p_required_role=>wwv_flow_imp.id(68231763228123033)
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37098559616997113)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'ROWS_X_TO_Y'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>'saadat----------97/03/13-------create'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287293412389206668)
,p_query_column_id=>1
,p_column_alias=>'SEQUENCE'
,p_column_display_sequence=>1
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#SEQUENCE#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287293851951206668)
,p_query_column_id=>2
,p_column_alias=>'PERCENT'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#PERCENT#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287294294334206670)
,p_query_column_id=>3
,p_column_alias=>'DESCRIPTION'
,p_column_display_sequence=>3
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#DESCRIPTION#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287294585163206670)
,p_query_column_id=>4
,p_column_alias=>'PRICE'
,p_column_display_sequence=>4
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#PRICE#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(329551252466743352)
,p_name=>'Topic Table'
,p_template=>wwv_flow_imp.id(37080726059997105)
,p_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_display_point=>'REGION_POSITION_03'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    ''TOPIC.SEQUENCE'' as sequence,',
'    ''TOPIC.GOODNAME'' as good,',
'    ''TOPIC.AMOUNT'' as amount,',
'    ''TOPIC.DISCOUNT'' as discount,',
'    ''TOPIC.TAXVALUE'' as taxValue1,',
'   -- ''topic.taxValue2'' as taxValue2,',
'    ''TOPIC.MAINAMOUNT'' as mainamount,',
'    ''TOPIC.TOTALVALUE'' as totalvalue,',
'    ''TOPIC.NETVALUE'' as netvalue,',
'    ''TOPIC.UNITPRICE'' as unitPrice,',
'    ''TOPIC.SUM.TOTALVALUE'' as sumTotalValue,',
'    ''TOPIC.AVG.TOTALVALUE'' as avgTotalValue,',
'    ''TOPIC.SUM.TAXVALUE''  as sumTaxValue,',
'    ''TOPIC.SUM.DISCOUNT'' as sumDiscount,',
'    ''TOPIC.SUM.NETVALUE'' as sumnetvalue ,',
'    ''TOPIC.AUXILIARYDATE'' as AUXILIARYDATE',
'from  dual',
''))
,p_required_role=>wwv_flow_imp.id(68231763228123033)
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37098559616997113)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'ROWS_X_TO_Y'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>'saadat---------97/03/13--------create'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287295275129206670)
,p_query_column_id=>1
,p_column_alias=>'SEQUENCE'
,p_column_display_sequence=>1
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#SEQUENCE#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287295647274206671)
,p_query_column_id=>2
,p_column_alias=>'GOOD'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#GOOD#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287296072793206671)
,p_query_column_id=>3
,p_column_alias=>'AMOUNT'
,p_column_display_sequence=>3
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#AMOUNT#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287296447450206671)
,p_query_column_id=>4
,p_column_alias=>'DISCOUNT'
,p_column_display_sequence=>5
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#DISCOUNT#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287296852331206671)
,p_query_column_id=>5
,p_column_alias=>'TAXVALUE1'
,p_column_display_sequence=>6
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#TAXVALUE1#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287297243809206673)
,p_query_column_id=>6
,p_column_alias=>'MAINAMOUNT'
,p_column_display_sequence=>7
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#MAINAMOUNT#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287297698394206673)
,p_query_column_id=>7
,p_column_alias=>'TOTALVALUE'
,p_column_display_sequence=>8
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#TOTALVALUE#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287298035002206673)
,p_query_column_id=>8
,p_column_alias=>'NETVALUE'
,p_column_display_sequence=>9
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#NETVALUE#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287298420210206673)
,p_query_column_id=>9
,p_column_alias=>'UNITPRICE'
,p_column_display_sequence=>4
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#UNITPRICE#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287298881797206673)
,p_query_column_id=>10
,p_column_alias=>'SUMTOTALVALUE'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#SUMTOTALVALUE#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287299257732206673)
,p_query_column_id=>11
,p_column_alias=>'AVGTOTALVALUE'
,p_column_display_sequence=>11
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#AVGTOTALVALUE#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287299622846206673)
,p_query_column_id=>12
,p_column_alias=>'SUMTAXVALUE'
,p_column_display_sequence=>12
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#SUMTAXVALUE#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287300002262206675)
,p_query_column_id=>13
,p_column_alias=>'SUMDISCOUNT'
,p_column_display_sequence=>13
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#SUMDISCOUNT#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287300841200206675)
,p_query_column_id=>14
,p_column_alias=>'SUMNETVALUE'
,p_column_display_sequence=>14
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#sumnetvalue#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287300479148206675)
,p_query_column_id=>15
,p_column_alias=>'AUXILIARYDATE'
,p_column_display_sequence=>15
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#AUXILIARYDATE#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(329552202999743361)
,p_name=>'Payment Cell'
,p_template=>wwv_flow_imp.id(37080726059997105)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_display_point=>'REGION_POSITION_03'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select ',
'     ''PRICE-''||level as price,',
'     ''PERCENT-''||level as percent,',
'     ''PAYMENTTERM-''||level as paymentterm,',
'     ''DESCRIPTION-''||level as Description,',
'     ''SETTLEMENTDATE-''||level as SettlementDate ',
' from dual',
' connect by level <= 5'))
,p_required_role=>wwv_flow_imp.id(68231763228123033)
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37098559616997113)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'ROWS_X_TO_Y'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>'saadat-----------97/03/13-------create'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287301517905206675)
,p_query_column_id=>1
,p_column_alias=>'PRICE'
,p_column_display_sequence=>1
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#PRICE#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287301957765206675)
,p_query_column_id=>2
,p_column_alias=>'PERCENT'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#PERCENT#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287302323056206675)
,p_query_column_id=>3
,p_column_alias=>'PAYMENTTERM'
,p_column_display_sequence=>3
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#PAYMENTTERM#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287302718589206676)
,p_query_column_id=>4
,p_column_alias=>'DESCRIPTION'
,p_column_display_sequence=>4
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#DESCRIPTION#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287303154161206676)
,p_query_column_id=>5
,p_column_alias=>'SETTLEMENTDATE'
,p_column_display_sequence=>5
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#SETTLEMENTDATE#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(330255313440424343)
,p_name=>'Topic Cell'
,p_template=>wwv_flow_imp.id(37080726059997105)
,p_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_display_point=>'REGION_POSITION_03'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    ''GOOD-''||level as good,',
'    ''UNIT-''||level as unit,',
'    ''UNITPRICE-''||level as unitprice,',
'    ''AMOUNT-''||level as amount,',
'    ''TOTALVALUE-''||level as totalvalue,',
'    ''DISCOUNT-''||level as discount,',
'    ''TAXVALUE1-''||level as taxvalue1,',
'    ''TAXVALUE2-''||level as taxvalue2,',
'    ''NETVALUE-''||level as netvalue',
'from dual',
'connect by level <= 10',
'order by level'))
,p_required_role=>wwv_flow_imp.id(68231763228123033)
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37098559616997113)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'ROWS_X_TO_Y'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>'saadat-------------97/03/13---------create'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287303830435206676)
,p_query_column_id=>1
,p_column_alias=>'GOOD'
,p_column_display_sequence=>1
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#GOOD#</div>'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287304263472206676)
,p_query_column_id=>2
,p_column_alias=>'UNIT'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#UNIT#</div>'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287304604551206676)
,p_query_column_id=>3
,p_column_alias=>'UNITPRICE'
,p_column_display_sequence=>3
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#UNITPRICE#</div>'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287305096125206678)
,p_query_column_id=>4
,p_column_alias=>'AMOUNT'
,p_column_display_sequence=>4
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#AMOUNT#</div>'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287305450475206678)
,p_query_column_id=>5
,p_column_alias=>'TOTALVALUE'
,p_column_display_sequence=>5
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#TOTALVALUE#</div>'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287305839383206678)
,p_query_column_id=>6
,p_column_alias=>'DISCOUNT'
,p_column_display_sequence=>6
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#DISCOUNT#</div>'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287306242763206678)
,p_query_column_id=>7
,p_column_alias=>'TAXVALUE1'
,p_column_display_sequence=>7
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#TAXVALUE1#</div>'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287306649880206678)
,p_query_column_id=>8
,p_column_alias=>'TAXVALUE2'
,p_column_display_sequence=>8
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#TAXVALUE2#</div>'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287307033679206678)
,p_query_column_id=>9
,p_column_alias=>'NETVALUE'
,p_column_display_sequence=>9
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#NETVALUE#</div>'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(360939103872315830)
,p_plug_name=>'Hidden Item'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(37087017074997107)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_required_role=>wwv_flow_imp.id(68231763228123033)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(362926547614278651)
,p_plug_name=>'Contract Template Body'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37076040472997104)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'D5CONTRACTTEMPLATEBODY'
,p_include_rowid_column=>true
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_required_role=>wwv_flow_imp.id(68231763228123033)
,p_plug_display_condition_type=>'NEVER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(405277862551652121)
,p_name=>'Contract Info'
,p_region_name=>'fields-region'
,p_template=>wwv_flow_imp.id(37080726059997105)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_display_point=>'REGION_POSITION_03'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
unistr(' case :APP_LANGUAGE when ''fa'' then ''\0634\0645\0627\0631\0647'' else ''NO'' end as no,'),
unistr(' case :APP_LANGUAGE when ''fa'' then ''\062A\0627\0631\06CC\062E \0634\0631\0648\0639'' else ''STARTDATE'' end  as startdate,'),
unistr(' case :APP_LANGUAGE when ''fa'' then ''\062A\0627\0631\06CC\062E \067E\0627\06CC\0627\0646'' else''ENDDATE'' end  as enddate,'),
unistr(' case :APP_LANGUAGE when ''fa'' then ''\062A\0627\0631\06CC\062E \0642\0631\0627\0631\062F\0627\062F'' else ''CONTRACTDATE'' end  as contractdate,'),
unistr(' case :APP_LANGUAGE when ''fa'' then ''\0634\0645\0627\0631\0647 \0627\0642\062A\0635\0627\062F\06CC'' else ''ECONOMICNUMBER'' end  as econimicnumber,'),
unistr(' case :APP_LANGUAGE when ''fa'' then ''\0634\0645\0627\0631\0647 \062B\0628\062A'' else ''REGISTRATIONNUMBER'' end  as registrationnumber,'),
unistr(' case :APP_LANGUAGE when ''fa'' then ''\0646\0627\0645 \0634\0631\06A9\062A'' else ''COMPANYNAME'' end  as companyname,'),
unistr(' case :APP_LANGUAGE when ''fa'' then ''\0646\0648\0639 \0634\0631\06A9\062A'' else ''COMPANYTYPE'' end  as Companytype,'),
unistr(' case :APP_LANGUAGE when ''fa'' then ''\06A9\062F \0645\0644\06CC'' else ''NATIONALID'' end  as nationalid,'),
unistr(' case :APP_LANGUAGE when ''fa'' then ''\0622\062F\0631\0633'' else ''ADDRESS'' end  as address,'),
unistr(' case :APP_LANGUAGE when ''fa'' then ''\06A9\062F \067E\0633\062A\06CC'' else ''POSTALCODE'' end  as postalcode,'),
unistr(' case :APP_LANGUAGE when ''fa'' then ''\0634\0645\0627\0631\0647 \062A\0645\0627\0633'' else ''PHONE'' end  as phone,'),
unistr(' case :APP_LANGUAGE when ''fa'' then ''\067E\0633\062A \0627\0644\06A9\062A\0631\0648\0646\06CC\06A9\06CC'' else ''EMAIL'' end  as email,'),
unistr(' case :APP_LANGUAGE when ''fa'' then ''\0645\0627\0647'' else ''MONTH'' end  as month,'),
unistr(' case :APP_LANGUAGE when ''fa'' then ''\0631\0648\0632'' else ''DAY'' end  as day ,'),
unistr(' case :APP_LANGUAGE when ''fa'' then ''\062A\0627\0631\06CC\062E \0627\0645\0636\0627\0621'' else ''SIGNINGSWAPPINGDATE'' end  AS SIGNINGSWAPPINGDATE,'),
unistr(' case :APP_LANGUAGE when ''fa'' then ''\062A\0627\0631\06CC\062E \062B\0628\062A'' else ''REGISTRATIONDATE'' end  as REGISTRATIONDATE,'),
unistr(' case :APP_LANGUAGE when ''fa'' then ''\0634\0645\0627\0631\0647 \062D\0633\0627\0628'' else ''BankAccount'' end BankAccount,'),
unistr(' case :APP_LANGUAGE when ''fa'' then ''\0627\0645\0636\0627\0621 \06A9\0646\0646\062F\0647 \0627\0648\0644'' else ''Signer1'' end Signer1,'),
unistr(' case :APP_LANGUAGE when ''fa'' then ''\0627\0645\0636\0627\0621 \06A9\0646\0646\062F\0647 \062F\0648\0645'' else ''Signer2'' end Signer2,    '),
unistr(' case :APP_LANGUAGE when ''fa'' then ''\0634\0645\0627\0631\0647 \0639\0636\0648\06CC\062A \0627\0648\0644'' else ''MembershipNumber1'' end MembershipNumber1,'),
unistr(' case :APP_LANGUAGE when ''fa'' then ''\0634\0645\0627\0631\0647 \0639\0636\0648\06CC\062A \062F\0648\0645'' else ''MembershipNumber2'' end MembershipNumber2 '),
' from dual'))
,p_required_role=>wwv_flow_imp.id(68231763228123033)
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37098559616997113)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'vahid seraj ------------- 1397/01/21',
'template, drag & drop---------------'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287312771892206684)
,p_query_column_id=>1
,p_column_alias=>'NO'
,p_column_display_sequence=>1
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#NO#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287313165403206684)
,p_query_column_id=>2
,p_column_alias=>'STARTDATE'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#STARTDATE#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287313579713206684)
,p_query_column_id=>3
,p_column_alias=>'ENDDATE'
,p_column_display_sequence=>3
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#ENDDATE#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287313986280206684)
,p_query_column_id=>4
,p_column_alias=>'CONTRACTDATE'
,p_column_display_sequence=>4
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#CONTRACTDATE#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287314316804206684)
,p_query_column_id=>5
,p_column_alias=>'ECONIMICNUMBER'
,p_column_display_sequence=>5
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#ECONIMICNUMBER#</div>'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287314769197206684)
,p_query_column_id=>6
,p_column_alias=>'REGISTRATIONNUMBER'
,p_column_display_sequence=>6
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#REGISTRATIONNUMBER#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287315135463206684)
,p_query_column_id=>7
,p_column_alias=>'COMPANYNAME'
,p_column_display_sequence=>7
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#COMPANYNAME#</div>'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1379074910136873
,p_default_application_id=>125
,p_default_id_offset=>0
,p_default_owner=>'FARA'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287318366033206685)
,p_query_column_id=>8
,p_column_alias=>'COMPANYTYPE'
,p_column_display_sequence=>15
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#COMPANYTYPE#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287315538987206684)
,p_query_column_id=>9
,p_column_alias=>'NATIONALID'
,p_column_display_sequence=>8
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#NATIONALID#</div>'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287315994539206685)
,p_query_column_id=>10
,p_column_alias=>'ADDRESS'
,p_column_display_sequence=>9
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#ADDRESS#</div>'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287316318015206685)
,p_query_column_id=>11
,p_column_alias=>'POSTALCODE'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#POSTALCODE#</div>'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287316715627206685)
,p_query_column_id=>12
,p_column_alias=>'PHONE'
,p_column_display_sequence=>11
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#PHONE#</div>'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287317131775206685)
,p_query_column_id=>13
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>12
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#EMAIL#</div>'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287317553813206685)
,p_query_column_id=>14
,p_column_alias=>'MONTH'
,p_column_display_sequence=>13
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#MONTH#</div>'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287317986337206685)
,p_query_column_id=>15
,p_column_alias=>'DAY'
,p_column_display_sequence=>14
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#DAY#</div>'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287318788520206687)
,p_query_column_id=>16
,p_column_alias=>'SIGNINGSWAPPINGDATE'
,p_column_display_sequence=>16
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#SIGNINGSWAPPINGDATE#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287319167461206687)
,p_query_column_id=>17
,p_column_alias=>'REGISTRATIONDATE'
,p_column_display_sequence=>17
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#REGISTRATIONDATE#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287319568930206687)
,p_query_column_id=>18
,p_column_alias=>'BANKACCOUNT'
,p_column_display_sequence=>18
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#BANKACCOUNT#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287319957603206687)
,p_query_column_id=>19
,p_column_alias=>'SIGNER1'
,p_column_display_sequence=>19
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#SIGNER1#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287320301699206687)
,p_query_column_id=>20
,p_column_alias=>'SIGNER2'
,p_column_display_sequence=>20
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#SIGNER2#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287320741893206687)
,p_query_column_id=>21
,p_column_alias=>'MEMBERSHIPNUMBER1'
,p_column_display_sequence=>21
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#MEMBERSHIPNUMBER1#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(287321189247206687)
,p_query_column_id=>22
,p_column_alias=>'MEMBERSHIPNUMBER2'
,p_column_display_sequence=>22
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<div draggable>#MEMBERSHIPNUMBER2#</div>'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(68231763228123033)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(287291546703206662)
,p_button_sequence=>10
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37125556830997125)
,p_button_image_alt=>'Cancel'
,p_button_position=>'LEGACY_ORPHAN_COMPONENTS'
,p_button_redirect_url=>'f?p=&APP_ID.:224:&SESSION.::&DEBUG.:RP::'
,p_button_condition_type=>'NEVER'
,p_security_scheme=>wwv_flow_imp.id(68231763228123033)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(287291917679206662)
,p_button_sequence=>20
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37125556830997125)
,p_button_image_alt=>'Delete'
,p_button_position=>'LEGACY_ORPHAN_COMPONENTS'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_button_condition=>'P2_ID'
,p_button_condition_type=>'NEVER'
,p_security_scheme=>wwv_flow_imp.id(68231763228123033)
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(287292359826206662)
,p_button_sequence=>30
,p_button_name=>'SAVE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37125556830997125)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'LEGACY_ORPHAN_COMPONENTS'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P2_ID'
,p_button_condition_type=>'NEVER'
,p_security_scheme=>wwv_flow_imp.id(68231763228123033)
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(287292732501206662)
,p_button_sequence=>40
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37125556830997125)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'LEGACY_ORPHAN_COMPONENTS'
,p_button_condition=>'P2_ID'
,p_button_condition_type=>'NEVER'
,p_security_scheme=>wwv_flow_imp.id(68231763228123033)
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(287327754687206696)
,p_branch_name=>'Go To 224'
,p_branch_action=>'f?p=&APP_ID.:224:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287307759574206678)
,p_name=>'P2_B5FORMREF_TITLE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(360939103872315830)
,p_display_as=>'NATIVE_HIDDEN'
,p_security_scheme=>wwv_flow_imp.id(68231763228123033)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287308185450206679)
,p_name=>'P2_B5FORMREF_APEXPAGEID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(360939103872315830)
,p_display_as=>'NATIVE_HIDDEN'
,p_security_scheme=>wwv_flow_imp.id(68231763228123033)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287308826218206681)
,p_name=>'P2_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(362926547614278651)
,p_item_source_plug_id=>wwv_flow_imp.id(362926547614278651)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_security_scheme=>wwv_flow_imp.id(68231763228123033)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287309241824206681)
,p_name=>'P2_C5GROUP_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(362926547614278651)
,p_item_source_plug_id=>wwv_flow_imp.id(362926547614278651)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Group'
,p_source=>'C5GROUP_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'PLUGIN_BE.CTB.SELECT2'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select G.code||''/''||G.name as d ,G.id as r',
'',
'from  C5GROUP  G',
'inner JOIN B5HC H ON  H.ID = G.B5HCGROUPTYPE_ID',
'where H.HCBASE_ID = (SELECT ID FROM HCBASE WHERE CODE =''SGT'') ',
'and G.B5IDREF_ID_Org = :APP_C5COMPANY_ID '))
,p_lov_display_null=>'YES'
,p_colspan=>5
,p_field_template=>wwv_flow_imp.id(37124977467997123)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_security_scheme=>wwv_flow_imp.id(68231763228123033)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'SINGLE'
,p_attribute_08=>'CIC'
,p_item_comment=>'saadat---------97/09/21------create'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287309672873206681)
,p_name=>'P2_CODE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(362926547614278651)
,p_item_source_plug_id=>wwv_flow_imp.id(362926547614278651)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Code'
,p_source=>'CODE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>20
,p_begin_on_new_line=>'N'
,p_colspan=>5
,p_field_template=>wwv_flow_imp.id(37124977467997123)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:margin-left-none'
,p_is_persistent=>'N'
,p_security_scheme=>wwv_flow_imp.id(68231763228123033)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287310062485206681)
,p_name=>'P2_SUBJECT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(362926547614278651)
,p_item_source_plug_id=>wwv_flow_imp.id(362926547614278651)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Subject'
,p_source=>'SUBJECT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>300
,p_colspan=>10
,p_field_template=>wwv_flow_imp.id(37124977467997123)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_security_scheme=>wwv_flow_imp.id(68231763228123033)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287310497297206681)
,p_name=>'P2_B5FORMREF_IDS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(362926547614278651)
,p_item_source_plug_id=>wwv_flow_imp.id(362926547614278651)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Use In'
,p_source=>'B5FORMREF_IDS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'PLUGIN_BE.CTB.SELECT2'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select title as d, id as r from b5formref_v ',
'where apexpageid = 218'))
,p_lov_display_null=>'YES'
,p_colspan=>10
,p_field_template=>wwv_flow_imp.id(37124977467997123)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_security_scheme=>wwv_flow_imp.id(68231763228123033)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'MULTI'
,p_attribute_08=>'CIC'
,p_attribute_14=>'Y'
,p_attribute_15=>'20'
,p_item_comment=>'saadat--------97/11/08'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287310869872206681)
,p_name=>'P2_USETEMPLATEBODY'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(362926547614278651)
,p_item_source_plug_id=>wwv_flow_imp.id(362926547614278651)
,p_use_cache_before_default=>'NO'
,p_item_default=>'1'
,p_prompt=>'Use Template Body?'
,p_source=>'USETEMPLATEBODY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_colspan=>10
,p_field_template=>wwv_flow_imp.id(37124977467997123)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_security_scheme=>wwv_flow_imp.id(68231763228123033)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287311227747206681)
,p_name=>'P2_B5PRINTSTYLE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(362926547614278651)
,p_item_source_plug_id=>wwv_flow_imp.id(362926547614278651)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Print Style'
,p_source=>'B5PRINTSTYLE_IDS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'PLUGIN_BE.CTB.SELECT2'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select b.filename as d,t.A5ATTACHMENT_ID as r from A5ATACHMENT_URL_IMAGE_V t',
'join A5ATTACHMENT b on t.A5ATTACHMENT_ID=b.id',
'where t.B5HCTYPE_ID in (SELECT id',
'                      FROM b5hc',
'                      WHERE   SUBSTR(code, 0, 2) IN (''PH'', ''PF''));',
''))
,p_lov_display_null=>'YES'
,p_field_template=>wwv_flow_imp.id(37124977467997123)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_security_scheme=>wwv_flow_imp.id(68231763228123033)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'MULTI'
,p_attribute_08=>'CIC'
,p_attribute_14=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287311616208206682)
,p_name=>'P2_B5HCSTATUS_ID'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(362926547614278651)
,p_item_source_plug_id=>wwv_flow_imp.id(362926547614278651)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    pRet   varchar2(50);',
'begin',
'    select ID into pRet  from b5hc where code = ''ST1'' ;',
'    return pRet ;',
'end ;',
'',
''))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Status'
,p_source=>'B5HCSTATUS_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov_language=>'PLSQL'
,p_lov=>'RETURN B5UTIL.hardcode_lov(''B'',1,''VCS'');'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(37124977467997123)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_security_scheme=>wwv_flow_imp.id(68231763228123033)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_item_comment=>'saadat--------97/11/08'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287312005109206682)
,p_name=>'P2_TEMPLATEBODY'
,p_source_data_type=>'CLOB'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(362926547614278651)
,p_item_source_plug_id=>wwv_flow_imp.id(362926547614278651)
,p_prompt=>'Template body'
,p_source=>'TEMPLATEBODY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_cMaxlength=>32767
,p_field_template=>wwv_flow_imp.id(37124977467997123)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_security_scheme=>wwv_flow_imp.id(68231763228123033)
,p_encrypt_session_state_yn=>'N'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options){',
'',
'    function findViewChild( viewElement, viewElementName, conversionApi ) {',
'        const viewChildren = Array.from( conversionApi.writer.createRangeIn( viewElement ).getItems() );',
'        return viewChildren.find( item => item.is( ''element'', viewElementName ) );',
'    } ',
'  ',
'    function AddClassToAllTable( editor ) {',
'        editor.conversion.for( ''downcast'' ).add( dispatcher => {',
'        dispatcher.on( ''insert:table'', ( evt, data, conversionApi ) => {',
'        const viewWriter = conversionApi.writer;',
'        const viewFigure = conversionApi.mapper.toViewElement( data.item );',
'        viewWriter.setAttribute( ''style'', ''margin:1em auto;'', viewFigure ); //***********test',
'        const viewElementtable = findViewChild( viewFigure, ''table'', conversionApi );',
'        viewWriter.setAttribute( ''style'', ''border-collapse:collapse;width:100%;'', viewElementtable );',
'        /*',
'          Array.from( conversionApi.writer.createRangeIn( viewFigure ).getItems(),item=> {',
'               if(item.name=="td"){',
'                    viewWriter.setAttribute( ''style'', ''border:1px solid gray;'', item ) ;',
'               }',
'                ',
'          });',
'          */',
'        }, { priority: ''low'' } );',
'    } );',
'    ',
'}',
'',
'',
'    class InsertImageByURLButton extends ClassicEditor.libraryClasses.Plugin {',
'        init(){',
'            const editor = this.editor;',
'            editor.ui.componentFactory.add(''insertImageByUrl'', locale => {',
'                const view = new ClassicEditor.libraryClasses.ButtonView(locale);',
'                view.set({',
'                    icon: ''<svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M6.91 10.54c.26-.23.64-.21.88.03l3.36 3.14 2.23-2.06a.64.64 0 0 1 .87 0l2.52 2.97V4.5H3.2v10.12l3.71-4.08zm10.27-7.51c.6 0 1.09.47 1.09 1.05v11.84c0 .59-.'
||'49 1.06-1.09 1.06H2.79c-.6 0-1.09-.47-1.09-1.06V4.08c0-.58.49-1.05 1.1-1.05h14.38zm-5.22 5.56a1.96 1.96 0 1 1 3.4-1.96 1.96 1.96 0 0 1-3.4 1.96z"/></svg>'',',
'                    label: ''Custom Button'',',
'                    withText: false,',
'                    tooltip: true',
'                });',
'                view.on(''execute'', () => {',
'                    const imageUrl = prompt( ''Image URL'' );',
'',
'                    if(imageUrl){',
'                        editor.model.change( writer => {',
'                            const imageElement = writer.createElement(''image'', {',
'                                src: imageUrl',
'                            });',
'                            editor.model.insertContent( imageElement, editor.model.document.selection );',
'                        });',
'                    }',
'                });',
'                return view;',
'            });',
'        }',
'    }',
'',
'    options.editorOptions.extraPlugins.push(InsertImageByURLButton);',
'    options.editorOptions.extraPlugins.push(AddClassToAllTable);',
'    options.editorOptions.toolbar.push(''insertImageByUrl'');',
'options.editorOptions.table = {',
'        contentToolbar: [',
'            ''tableColumn'', ''tableRow'', ''mergeTableCells'',',
'            ''tableProperties'', ''tableCellProperties''',
'        ]',
'}',
'',
'options.editorOptions.fontSize = {',
'	options: [',
'		{',
'		 	title: ''9'',',
'		 	model: ''12px''',
'		},',
'        {',
'		 	title: ''11'',',
'		 	model: ''14.5px''',
'		},{',
'            title: ''12'',',
'            model: ''16px''',
'        },',
'        {',
'		 	title: ''13'',',
'		 	model: ''17px''',
'		},',
'        {',
'		 	title: ''14'',',
'		 	model: ''18.5px''',
'		},',
'		{',
'		 	title: ''17'',',
'		 	model: ''22.5px''',
'		},',
'        {',
'		 	title: ''19'',',
'		 	model: ''25px''',
'		},',
'        {',
'		 	title: ''21'',',
'		 	model: ''28px''',
'		}',
'	]',
'}',
'    return options;',
'}'))
,p_attribute_01=>'HTML'
,p_attribute_02=>'FULL'
,p_attribute_03=>'OVERFLOW'
,p_attribute_04=>'180'
,p_attribute_07=>'N'
,p_attribute_25=>'CKEDITOR'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (o) {',
'    //o.width = $("#P218_CONTRCTBODY_TEMPLATE").closest(".t-Form-inputContainer").width() - 2;',
'   o.height = 480;  // Specify your desired item height, in pixels',
'   CKEDITOR.config.contentsCss = ''#WORKSPACE_IMAGES#FontsEditors.css'';',
'   CKEDITOR.config.font_names = ''IRANSans;BHOMA;BKOODAKO;BLOTUS;BLOTUSB;BNAZANB;BNAZANIN;BTRAFB;BTRAFFIC;BZAR;BZARBOLD;'' + CKEDITOR.config.font_names;// specify a custom font',
'   o.allowedContent = true; // force editor to dont touch the data.',
'   // o.extraPlugins = ''bidi,tableresize,lineheight''; // comment by rezaei ',
'    CKEDITOR.config.extraPlugins = ''lineheight,en'';',
'    CKEDITOR.config.line_height="1px;1.1px;1.2px;1.3px;1.4px;1.5px";',
'    o.line_height="0;0.5;1;1.1;1.2;1.3;1.4;1.5;1.6;1.7;1.8;1.9;2.0;2.4;2.6;2.8;3.0" ',
'    o.contentsLangDirection = ''rtl'';',
'    o.toolbar.push([''lineheight'', ''bidi'']);',
'    //debugger;',
'    console.log(o);',
'    return o;',
'}',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(287323149276206692)
,p_computation_sequence=>10
,p_computation_item=>'P2_B5FORMREF_TITLE'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>'return B5UTIL.GET_BC_TITLE(:P0_B5FORMREF_CODE);'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(287323537415206692)
,p_computation_sequence=>20
,p_computation_item=>'P2_B5FORMREF_APEXPAGEID'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>'return B5UTIL.GET_BC_APEXPAGEID(:P0_B5FORMREF_CODE);'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(287325885106206693)
,p_name=>'mouseDown'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'[draggable]'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mousedown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(287326389918206695)
,p_event_id=>wwv_flow_imp.id(287325885106206693)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'selectText(this.triggeringElement);'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(287326702045206695)
,p_name=>'Apply_Changes'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(287292359826206662)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(287327279925206695)
,p_event_id=>wwv_flow_imp.id(287326702045206695)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'setApexCollectionClob (apex.item(''P2_TEMPLATEBODY'').getValue(), ',
'                       function(){',
'                            console.log(''getApexCollectionClob'');',
'                            apex.submit({',
'                              request:"UPDATE",',
'                              set:{"P2_ID": apex.item(''P2_ID'').getValue()',
'                                   , "P2_C5GROUP_ID": apex.item(''P2_C5GROUP_ID'').getValue()',
'                                   , "P2_CODE": apex.item(''P2_CODE'').getValue()',
'                                   , "P2_SUBJECT": apex.item(''P2_SUBJECT'').getValue()',
'                                   , "P2_ISACTIVE": apex.item(''P2_ISACTIVE'').getValue()',
'                                   , "P2_TEMPLATEBODY": apex.item(''P2_TEMPLATEBODY'').getValue()',
'                                  }});',
'});'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(287323886591206693)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_region_id=>wwv_flow_imp.id(362926547614278651)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Fetch Row from D5CONTRACTTEMPLATEBODY'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>287323886591206693
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(287324214562206693)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(362926547614278651)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process Row of D5CONTRACTTEMPLATEBODY'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>287324214562206693
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(287324664192206693)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'insert'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    subjectClob clob := empty_clob();',
'begin ',
'select clob001 into subjectClob',
'  from apex_collections',
'  where collection_name = ''CLOB_CONTENT'';',
'',
'insert into D5CONTRACTTEMPLATEBODY(CODE, SUBJECT, B5FORMREF_IDS , USETEMPLATEBODY, TEMPLATEBODY, C5GROUP_ID , B5HCSTATUS_ID,B5PRINTSTYLE_IDS) ',
'    values(:P2_CODE, :P2_SUBJECT, :P2_B5FORMREF_IDS , :P2_USETEMPLATEBODY, subjectClob, :P2_C5GROUP_ID , :P2_B5HCSTATUS_ID, :P2_B5PRINTSTYLE);',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>287324664192206693
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(287325033244206693)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'delete'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin ',
'    delete from D5CONTRACTTEMPLATEBODY  where  ID  = :P2_ID;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>287325033244206693
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(287325480829206693)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'update'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    clobCONTRACTBODY clob := empty_clob();',
'begin ',
'',
'    select clob001 into clobCONTRACTBODY',
'      from apex_collections',
'      where collection_name = ''CLOB_CONTENT'';',
'',
'        update d5contracttemplatebody set',
'         TEMPLATEBODY =  clobCONTRACTBODY',
'        where  ID  = :P2_ID;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>287325480829206693
);
wwv_flow_imp.component_end;
end;
/
